import os, pyodbc
from datetime import datetime

server = os.environ.get('MSSQL_SERVER', '103.207.1.84')
database = os.environ.get('MSSQL_DATABASE', 'transport')
uid = os.environ.get('MSSQL_UID', 'transport')
pwd = os.environ.get('MSSQL_PWD', 'claude@3908')

drivers = [
    'ODBC Driver 18 for SQL Server',
    'ODBC Driver 17 for SQL Server',
    'SQL Server Native Client 11.0',
    'SQL Server'
]

conn = None
for driver in drivers:
    try:
        conn = pyodbc.connect(
            f'DRIVER={{{driver}}};SERVER={server};DATABASE={database};UID={uid};PWD={pwd};'
            'Encrypt=yes;TrustServerCertificate=yes;'
        )
        print(f'DRIVER_OK {driver}')
        break
    except Exception as e:
        print(f'DRIVER_FAIL {driver}: {e}')

if conn is None:
    raise SystemExit('No usable SQL Server driver found')

cur = conn.cursor()

for table in ('bus_route_sessions', 'bus_route_points'):
    print(f'\nSCHEMA {table}')
    cur.execute(
        "SELECT COLUMN_NAME, DATA_TYPE, COLUMN_DEFAULT FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = ? ORDER BY ORDINAL_POSITION",
        (table,)
    )
    for row in cur.fetchall():
        print(row)

print('\nTIME CHECK')
cur.execute('SELECT GETDATE() AS server_now, GETUTCDATE() AS utc_now')
for row in cur.fetchall():
    print(row)

print('\nTOP SESSIONS')
cur.execute(
    "SELECT TOP 5 session_id, started_at, ended_at, bus_number, student_id FROM bus_route_sessions ORDER BY session_id DESC"
)
for row in cur.fetchall():
    print(row)

print('\nTOP POINTS')
cur.execute(
    "SELECT TOP 5 session_id, point_seq, lat, lng, captured_at FROM bus_route_points ORDER BY session_id DESC, point_seq DESC"
)
for row in cur.fetchall():
    print(row)

conn.close()
