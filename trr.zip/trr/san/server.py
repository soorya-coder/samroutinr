from flask import Flask, request, jsonify, send_from_directory
import logging
from flask_cors import CORS
import pyodbc
import os

# Serve project files (index.html, style.css, script.js) from repo root
app = Flask(__name__, static_folder='.', static_url_path='')
CORS(app)

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')

# Database configuration (can be overridden with environment variables)
DB_USER = os.getenv("DB_USER", "watertank")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Flowlevel@123")
DB_SERVER = os.getenv("DB_SERVER", "103.207.1.91") 
DB_NAME = os.getenv("DB_NAME", "watertankmonitoring")
ODBC_DRIVER = os.getenv("ODBC_DRIVER", "ODBC Driver 18 for SQL Server")


def get_connection():
    conn_str = (
        f"DRIVER={{{ODBC_DRIVER}}};"
        f"SERVER={DB_SERVER};"
        f"DATABASE={DB_NAME};"
        f"UID={DB_USER};PWD={DB_PASSWORD};"
        "Encrypt=no;TrustServerCertificate=yes"
    )
    try:
        return pyodbc.connect(conn_str, timeout=5)
    except Exception as e:
        logging.error("DB connection failed: %s", e)
        raise


@app.route("/gps", methods=["POST"])
def receive_gps():
    data = request.get_json(force=True)
    lat = data.get("lat")
    lon = data.get("lon")
    sim = data.get("sim")
    gps = data.get("gps")
    # Use parameterized query to avoid injection
    query = (                                   
        "INSERT INTO gps_data (latitude, longitude, sim_status, gps_status)"
        " VALUES (?, ?, ?, ?)"
    )

    conn = None
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(query, (lat, lon, sim, gps))
        conn.commit()
        cur.close()
        logging.info("✅ DATA INSERTED INTO MSSQL: %s,%s", lat, lon)
        return "SUCCESS", 200
    except Exception as e:
        logging.error("❌ MSSQL SERVER FAILED: %s", e)
        return "-1", 500
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass

@app.route("/gps/latest", methods=["GET"])
def latest_gps():
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT TOP 1 * FROM gps_data ORDER BY id DESC")
        row = cur.fetchone()

        if not row:
            cur.close()
            conn.close()
            return jsonify({}), 204

        columns = [col[0] for col in cur.description]
        result = dict(zip(columns, row))

        cur.close()
        conn.close()

        return jsonify(result)

    except Exception as e:
        logging.error("Failed to fetch latest gps: %s", e)
        return jsonify({"error": str(e)}), 500


@app.route("/", methods=["GET"])
def index():
    # Let Flask static handler serve index.html from repo root
    return app.send_static_file('index.html')


@app.route("/favicon.ico")
def favicon():
    # Let Flask static handler serve favicon if present
    fav_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'favicon.ico')
    if os.path.exists(fav_path):
        return app.send_static_file('favicon.ico')
    return "", 204


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
