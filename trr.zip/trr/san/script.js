
// LOCAL NODE.JS API
const API_URL =
"http://10.214.66.13:8080";

console.log("Bus tracker script loaded");

// MAP
var map = L.map('map').setView([0.0, 0.0], 2);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: "© OpenStreetMap"
}).addTo(map);

// BUS ICON
var busIcon = L.icon({
  iconUrl: "bus1.png",
  iconSize: [50, 50],
  iconAnchor: [25, 25]
});

var marker = null;

const LOCAL_STORAGE_KEY = "busTrackerLastLocation";

const FALLBACK_LAT = 10.106031;
const FALLBACK_LON = 78.643106;

// ROUTE
var route = L.polyline([], {
  color: 'blue',
  weight: 4
}).addTo(map);

var stopMarkers = [];
var stopPoints = [];
var drawnRoutes = [];

// STATE
let currentLatLng = null;
let animationInterval = null;

let prevLat = null;
let prevLon = null;

let lastLat = null;
let lastLon = null;

let totalDistance = 0;
let lastUpdate = null;

let tracking = true;
let routePoints = [];

let busStatus = "STOPPED";

let speed = 0;
let lastUpdateTime = null;

// SAVE LAST LOCATION
function saveLastLocation(lat, lon) {

  localStorage.setItem(
    LOCAL_STORAGE_KEY,
    JSON.stringify({
      lat,
      lon,
      seenAt: Date.now()
    })
  );
}

// LOAD LAST LOCATION
async function loadLastLocation() {

  try {

    const response = await fetch(
      `${API_URL}/gps/latest`
    );

    const data = await response.json();

    if (!data) {
      animateMarker(FALLBACK_LAT, FALLBACK_LON);
      return;
    }

    const lat = Number(data.latitude);
    const lon = Number(data.longitude);

    animateMarker(lat, lon);

    saveLastLocation(lat, lon);

    document.getElementById("coords").innerHTML =
      `📍 Lat: ${lat.toFixed(6)} | Lon: ${lon.toFixed(6)}`;

  } catch (err) {

    console.log(err);

    animateMarker(FALLBACK_LAT, FALLBACK_LON);
  }
}

loadLastLocation();

// FETCH GPS DATA
async function fetchGPSData() {

  try {

    const response = await fetch(
      `${API_URL}/gps/latest`
    );

    const data = await response.json();

    if (!data) return;

    let lat = Number(data.latitude);
    let lon = Number(data.longitude);

    let sim = data.sim_status || "UNKNOWN";
    let net = data.network_status || "UNKNOWN";
    let gps = data.gps_status || "WAITING";

    if (!lat || !lon) return;

    let isNew = false;

    if (lastLat === null || lastLon === null) {
      isNew = true;
    }
    else if (
      Math.abs(lat - lastLat) > 0.00001 ||
      Math.abs(lon - lastLon) > 0.00001
    ) {
      isNew = true;
    }

    if (isNew) {
      lastUpdate = Date.now();
      lastLat = lat;
      lastLon = lon;
    }
    // ANIMATE BUS
    animateMarker(lat, lon);
    // DISTANCE
    let dist = 0;

    let now = Date.now();

    if (prevLat != null) {

      dist = getDistance(
        prevLat,
        prevLon,
        lat,
        lon
      );
    }

    let timeDiff = 0;

    if (lastUpdateTime != null) {
      timeDiff = (now - lastUpdateTime) / 1000;
    }

    if (timeDiff > 0.5) {
      speed = (dist / timeDiff) * 3600;
    }

    lastUpdateTime = now;

    // ROUTE
    if (tracking && dist > 0.003) {

      route.addLatLng([lat, lon]);

      routePoints.push({
        lat,
        lon
      });
    }

    if (prevLat != null) {

      totalDistance += dist;

      document.getElementById("speed").innerHTML =
        "🚀 Speed: " + speed.toFixed(2) + " km/h";
    }

    prevLat = lat;
    prevLon = lon;
    // UI
    document.getElementById("coords").innerHTML =
      `📍 Lat: ${lat.toFixed(6)} | Lon: ${lon.toFixed(6)}`;

    document.getElementById("distance").innerHTML =
      "📏 Distance: " + totalDistance.toFixed(3) + " km";

    updateEta(lat, lon, speed);
    // STATUS
    document.getElementById("statusPanel").innerHTML =
      "🟢 ONLINE";

    document.getElementById("statusPanel").style.color =
      "lime";

    document.getElementById("simStatus").style.color =
      sim === "OK" ? "lime" : "red";

    document.getElementById("netStatus").style.color =
      net === "OK" ? "lime" : "red";

    document.getElementById("gpsStatus").style.color =
      gps === "RECEIVED" ? "lime" : "orange";

  } catch (err) {

    console.log(err);

    document.getElementById("statusPanel").innerHTML =
      "🔴 OFFLINE";

    document.getElementById("statusPanel").style.color =
      "red";
  }
}
// AUTO FETCH
setInterval(fetchGPSData, 3000);

// ================================
// ANIMATE MARKER
// ================================

function animateMarker(newLat, newLon) {

  if (!marker) {

    currentLatLng = [newLat, newLon];

    marker = L.marker(currentLatLng, {
      icon: busIcon
    }).addTo(map);

    map.setView(currentLatLng, 16);

    return;
  }

  let steps = 20;

  let i = 0;

  let lat1 = currentLatLng[0];
  let lon1 = currentLatLng[1];

  let latStep = (newLat - lat1) / steps;
  let lonStep = (newLon - lon1) / steps;

  if (animationInterval)
    clearInterval(animationInterval);

  animationInterval = setInterval(() => {

    i++;

    let lat = lat1 + latStep * i;
    let lon = lon1 + lonStep * i;

    marker.setLatLng([lat, lon]);

    map.panTo([lat, lon]);

    if (i >= steps) {

      clearInterval(animationInterval);

      currentLatLng = [newLat, newLon];
    }

  }, 50);
}

// ================================
// DISTANCE
// ================================

function getDistance(lat1, lon1, lat2, lon2) {

  let R = 6371;

  let dLat = (lat2 - lat1) * Math.PI / 180;
  let dLon = (lon2 - lon1) * Math.PI / 180;

  let a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) *
    Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) ** 2;

  return R * (
    2 * Math.atan2(
      Math.sqrt(a),
      Math.sqrt(1 - a)
    )
  );
}

// ================================
// ETA
// ================================

function getClosestStop(lat, lon) {

  if (stopPoints.length === 0)
    return null;

  let closest = null;

  let closestDist = Infinity;

  for (const pt of stopPoints) {

    const d = getDistance(
      lat,
      lon,
      pt.lat,
      pt.lon
    );

    if (d < closestDist) {

      closestDist = d;

      closest = pt;
    }
  }

  return closest
    ? {
        lat: closest.lat,
        lon: closest.lon,
        distanceKm: closestDist
      }
    : null;
}

function updateEta(lat, lon, speedKmh) {

  const etaEl =
    document.getElementById("eta");

  const nextStop =
    getClosestStop(lat, lon);

  if (!nextStop || speedKmh < 0.5) {

    etaEl.innerHTML = "ETA: --";

    return;
  }

  const minutes =
    (nextStop.distanceKm / speedKmh) * 60;

  etaEl.innerHTML =
    `⏱ ETA: ${minutes.toFixed(1)} min`;
}

// ================================
// BUTTONS
// ================================

function startTracking() {

  tracking = true;

  routePoints = [];

  route.setLatLngs([]);

  totalDistance = 0;

  alert("▶️ Tracking Started");
}

function stopTracking() {

  tracking = false;

  alert("⏹ Tracking Stopped");
}

// ================================
// ADD STOP
// ================================

async function addStop() {

  const location =
    currentLatLng || [FALLBACK_LAT, FALLBACK_LON];

  const [lat, lon] = location;

  const stopMarker = L.circleMarker([lat, lon], {

    color: "orange",
    fillColor: "#f39c12",
    fillOpacity: 0.8,
    radius: 8,
    weight: 2

  }).addTo(map);

  stopMarkers.push(stopMarker);

  stopPoints.push({
    lat,
    lon
  });

  try {

    await fetch(`${API_URL}/points`, {

      method: "POST",

      headers: {
        "Content-Type": "application/json"
      },

      body: JSON.stringify({
        lat,
        lon,
        message: "Stop added"
      })
    });

    alert("📍 Stop Saved");

  } catch (err) {

    console.log(err);

    alert("Error saving stop");
  }
}

// ================================
// SAVE ROUTE
// ================================

async function saveRoute() {

  if (routePoints.length === 0) {

    alert("⚠️ No route to save");

    return;
  }

  try {

    await fetch(`${API_URL}/routes`, {

      method: "POST",

      headers: {
        "Content-Type": "application/json"
      },

      body: JSON.stringify({
        route: routePoints
      })
    });

    alert("💾 Route Saved");

  } catch (err) {

    console.log(err);

    alert("Error saving route");
  }
}

// ================================
// LOAD ROUTES
// ================================

async function loadRoutes() {

  try {

    const response = await fetch(
      `${API_URL}/routes`
    );

    const routes = await response.json();

    routes.forEach((r) => {

      let path = JSON.parse(r.route_data);

      const poly = L.polyline(

        path.map(p => [p.lat, p.lon]),

        { color: "red" }

      ).addTo(map);

      drawnRoutes.push(poly);
    });

    alert("📂 Routes Loaded");

  } catch (err) {

    console.log(err);

    alert("Error loading routes");
  }
}

// ================================
// CLEAR ROUTE
// ================================

function clearRoute() {

  route.setLatLngs([]);

  routePoints = [];

  totalDistance = 0;

  drawnRoutes.forEach(r => {

    if (map.hasLayer(r))
      map.removeLayer(r);
  });

  stopMarkers.forEach(m => {

    if (map.hasLayer(m))
      map.removeLayer(m);
  });

  drawnRoutes = [];
  stopMarkers = [];
  stopPoints = [];

  alert("🧹 Cleared");
}