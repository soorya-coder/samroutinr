"""Unified application config — edit PORT to change the listening port."""


class Config:
    SCHOOL_NAME = "Mount Zion Schools"

    # Single port for the unified app (driver + student under one Flask process)
    PORT = 5000

    # Session signing key. Change in production.
    SECRET_KEY = "dev-only-not-secret-change-me"
    DEBUG = True

    # Make browser sessions behave more consistently on mobile and local networks.
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = False
    SESSION_PERMANENT = True
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 24 * 7  # 7 days

    # Used when student dashboard is reached without an active student session
    # (e.g. running the legacy student_app/app.py standalone).
    DEFAULT_STUDENT_ID = 1
