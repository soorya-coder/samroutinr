from datetime import datetime

from flask import Blueprint, render_template, abort, session, jsonify, request

from shared.db.database import get_db
from shared.db import queries as q
from shared.geo import haversine_km, eta_minutes, nearest_location_name

dashboard_bp = Blueprint("dashboard", __name__, template_folder="../../templates")


def _serialize_datetime(value):
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M:%S")
    return value


@dashboard_bp.route("/")
def index():
    # Require logged-in student
    user = session.get("user") if session else None
    if not user or user.get("role") != "student":
        abort(401)

    sid = user["id"]

    with get_db() as conn:
        student = q.get_student(conn, sid)
        if not student:
            abort(404)

        bus = None
        if student.get("bus_id") is not None:
            bus = q.get_bus(conn, student["bus_id"])

        if not bus and student.get("bus_number"):
            bus = q.get_bus_by_number(conn, student["bus_number"])

        if not bus and student.get("bus_id") is not None:
            bus = q.get_bus_by_number(conn, str(student["bus_id"]))

        if not bus:
            abort(404)

        school = q.get_school(conn)

    bus_to_pickup_km = haversine_km(
        bus["lat"], bus["lng"], student["pickup_lat"], student["pickup_lng"]
    )
    bus_to_school_km = haversine_km(
        bus["lat"], bus["lng"], school["lat"], school["lng"]
    )
    metrics = {
        "bus_to_pickup_km": round(bus_to_pickup_km, 2),
        "bus_to_pickup_min": eta_minutes(bus_to_pickup_km),
        "bus_to_school_km": round(bus_to_school_km, 2),
        "bus_to_school_min": eta_minutes(bus_to_school_km),
    }

    return render_template(
        "dashboard.html",
        student=student,
        bus=bus,
        school=school,
        metrics=metrics,
    )


@dashboard_bp.route("/api/tracking/<bus_number>")
def get_bus_tracking(bus_number):
    try:
        with get_db() as conn:
            tracking = q.get_latest_tracking(conn, bus_number)
            if tracking:
                timestamp = tracking.get("timestamp")
                if timestamp is not None and not isinstance(timestamp, str):
                    timestamp = timestamp.isoformat() if hasattr(timestamp, "isoformat") else str(timestamp)

                return jsonify({
                    "status": "success",
                    "data": {
                        "bus_number": tracking.get("bus_number"),
                        "lat": tracking.get("lat"),
                        "lon": tracking.get("long"),
                        "speed": tracking.get("speed"),
                        "eta": tracking.get("eta"),
                        "status": tracking.get("status"),
                        "timestamp": timestamp,
                    },
                }), 200
            return jsonify({"status": "error", "message": "No tracking data found"}), 404
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@dashboard_bp.route("/api/bus/<bus_number>")
def get_bus_info(bus_number):
    """Return current bus record (lat/lng) from the `bus` table.
    Accepts either the bus_number string or numeric id as path param.
    """
    try:
        with get_db() as conn:
            # Try lookup by bus_number first, then by id
            bus = q.get_bus_by_number(conn, bus_number)
            if not bus:
                # attempt numeric id lookup
                try:
                    bus = q.get_bus(conn, int(bus_number))
                except Exception:
                    bus = None

            if bus:
                location_name = nearest_location_name(
                    bus.get("lat"),
                    bus.get("lng"),
                    q.get_all_bus_points(conn),
                    max_distance_km=0.8,
                )
                return jsonify({
                    "status": "success",
                    "data": {
                        "number": bus.get("number"),
                        "lat": bus.get("lat"),
                        "lng": bus.get("lng"),
                        "route": bus.get("route"),
                        "location_name": location_name or "Unknown location",
                    },
                }), 200

            return jsonify({"status": "error", "message": "Bus not found"}), 404
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@dashboard_bp.route("/api/route/session", methods=["POST"])
def create_route_session():
    payload = request.get_json(silent=True) or {}
    bus_number = payload.get("bus_number")
    if not bus_number:
        return jsonify({"status": "error", "message": "bus_number is required"}), 400

    student = session.get("user") if session else None
    student_id = payload.get("student_id")
    if student_id is None and student and student.get("role") == "student":
        student_id = student.get("id")

    try:
        with get_db() as conn:
            session_id = q.insert_route_session(conn, bus_number, student_id)
            if session_id is None:
                return jsonify({"status": "error", "message": "Could not create route session"}), 500
            return jsonify({
                "status": "success",
                "data": {
                    "session_id": session_id,
                    "bus_number": bus_number,
                },
            }), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@dashboard_bp.route("/api/route/session/<int:session_id>/end", methods=["POST"])
def end_route_session(session_id):
    try:
        with get_db() as conn:
            q.end_route_session(conn, session_id)
            return jsonify({"status": "success", "data": {"session_id": session_id}}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@dashboard_bp.route("/api/route/session/<int:session_id>/point", methods=["POST"])
def add_route_point(session_id):
    payload = request.get_json(silent=True) or {}
    lat = payload.get("lat")
    lng = payload.get("lng")

    if lat is None or lng is None:
        return jsonify({"status": "error", "message": "lat and lng are required"}), 400

    try:
        with get_db() as conn:
            point_seq = q.get_next_route_point_seq(conn, session_id)
            q.insert_route_point(conn, session_id, point_seq, lat, lng)
            return jsonify({
                "status": "success",
                "data": {
                    "session_id": session_id,
                    "point_seq": point_seq,
                },
            }), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@dashboard_bp.route("/api/route/sessions/<bus_number>")
def get_available_route_sessions(bus_number):
    try:
        with get_db() as conn:
            sessions = q.get_available_route_sessions(conn, bus_number)
            if not sessions:
                return jsonify({"status": "error", "message": "No saved routes found"}), 404

            serialized_sessions = [
                {
                    **session,
                    "started_at": _serialize_datetime(session.get("started_at")),
                    "ended_at": _serialize_datetime(session.get("ended_at")),
                }
                for session in sessions
            ]

            return jsonify({
                "status": "success",
                "data": serialized_sessions,
            }), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@dashboard_bp.route("/api/route/session/<int:session_id>")
def get_route_by_session(session_id):
    try:
        with get_db() as conn:
            route_session = q.get_route_session(conn, session_id)
            if not route_session:
                return jsonify({"status": "error", "message": "Route session not found"}), 404

            points = q.get_route_points(conn, session_id)
            return jsonify({
                "status": "success",
                "data": {
                    "session_id": route_session["session_id"],
                    "started_at": _serialize_datetime(route_session.get("started_at")),
                    "ended_at": _serialize_datetime(route_session.get("ended_at")),
                    "points": points,
                },
            }), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@dashboard_bp.route("/api/route/last/<bus_number>")
def get_last_route(bus_number):
    try:
        with get_db() as conn:
            route_session = q.get_last_route_session(conn, bus_number)
            if not route_session:
                return jsonify({"status": "error", "message": "No saved route found"}), 404

            points = q.get_route_points(conn, route_session["session_id"])
            return jsonify({
                "status": "success",
                "data": {
                    "session_id": route_session["session_id"],
                    "started_at": _serialize_datetime(route_session.get("started_at")),
                    "ended_at": _serialize_datetime(route_session.get("ended_at")),
                    "points": points,
                },
            }), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
