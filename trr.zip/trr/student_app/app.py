import os
import sys
from datetime import date

# Make `shared/` importable
_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from flask import Flask, render_template, request, redirect, url_for, session

from config import Config
from shared.db.database import ensure_db_ready, get_db
from shared.db import queries as q
from modules.dashboard.routes import dashboard_bp

def create_app():
    ensure_db_ready()  # create + seed DB on first run 

    app = Flask(__name__)
    app.config.from_object(Config)

    app.register_blueprint(dashboard_bp, url_prefix="/")

    @app.context_processor
    def inject_globals():
        return {
            "school_name": app.config["SCHOOL_NAME"],
            "today": date.today().strftime("%A, %d %B %Y"),
            "current_user": session.get("user"),
        }

    OPEN_ENDPOINTS = {"login", "logout"}

    @app.before_request
    def guard():
        ep = request.endpoint or ""
        if ep == "static" or ep.endswith(".static") or ep in OPEN_ENDPOINTS:
            return None

        user = session.get("user")
        if not user or user.get("role") != "student":
            return redirect(url_for("login"))

    @app.route("/login", methods=["GET", "POST"])
    def login():
        error = None
        if request.method == "POST":
            spr = (request.form.get("spr") or "").strip()
            dob = (request.form.get("dob") or "").strip()
            with get_db() as conn:
                student = q.find_student_by_spr_dob(conn, spr, dob)
                if student:
                    session["user"] = {
                        "role": "student",
                        "id": student["id"],
                        "spr_no": student["spr_no"],
                        "name": student["name"],
                    }
                    return redirect(url_for("dashboard.index"))
            error = "Invalid SPR number or date of birth."

        return render_template("login.html", role="student", error=error)

    @app.route("/logout")
    def logout():
        session.pop("user", None)
        return redirect(url_for("login"))

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=4014, debug=True, use_reloader=False)
