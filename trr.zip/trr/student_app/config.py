class Config:
    SCHOOL_NAME = "Mount Zion Schools"
    SECRET_KEY = "dev-only-not-secret"
    DEBUG = True
    PORT = 5001

    # Improve session reliability on mobile browsers/local networks.
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = False
    SESSION_PERMANENT = True
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 24 * 7  # 7 days

    # Hard-coded "logged-in" student until auth is added
    DEFAULT_STUDENT_ID = 1
