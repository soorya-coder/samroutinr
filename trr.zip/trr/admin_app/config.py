class Config:
    SCHOOL_NAME = "Mount Zion Schools"
    SECRET_KEY = "dev-only-not-secret"
    DEBUG = True

    # Improve session reliability on mobile browsers/local networks.
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = False
    SESSION_PERMANENT = True
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 24 * 7  # 7 days
