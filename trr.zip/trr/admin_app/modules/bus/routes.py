from flask import Blueprint, render_template, request, abort

from shared.db.database import get_db
from shared.db import queries as q
from modules.reports.generator import build_report

bus_bp = Blueprint("bus", __name__, template_folder="../../templates")


@bus_bp.route("/")
def list_buses():
    with get_db() as conn:
        buses = q.all_buses(conn)
        bus_stats = q.bus_summary(conn)
        bus_overview = q.bus_overview_totals(conn)
    return render_template("bus/list.html",
                           buses=buses,
                           bus_stats=bus_stats,
                           bus_overview=bus_overview,
                           active_tab="bus")


@bus_bp.route("/<int:bus_id>")
def detail(bus_id):
    with get_db() as conn:
        bus = q.get_bus(conn, bus_id)
        if not bus:
            abort(404)
        students = q.students_for_bus(conn, bus_id)
    return render_template("bus/detail.html", bus=bus, students=students, active_tab="bus")


@bus_bp.route("/report")
def report():
    fmt = request.args.get("fmt", "pdf")
    with get_db() as conn:
        bus_stats = q.bus_summary(conn)
        bus_overview = q.bus_overview_totals(conn)
    headers = ["Bus No.", "Plate", "Start Location", "Route", "Admin", "Status",
               "Assigned", "Present", "Boarded", "Not Boarded", "Absent"]
    rows = [[b["bus_number"], b["number_plate"], b["starting_location"], b["route_name"],
             b["driver_name"], b["departure_status"],
             b["assigned"], b["present"], b["boarded"], b["not_boarded"], b["absent"]]
            for b in bus_stats]
    rows.append(["ALL BUSES", "", "", "", "", "",
                 bus_overview["assigned"], bus_overview["present"],
                 bus_overview["boarded"], bus_overview["not_boarded"], bus_overview["absent"]])
    return build_report("Bus Day Wise Report", headers, rows, fmt)


@bus_bp.route("/<int:bus_id>/report")
def detail_report(bus_id):
    fmt = request.args.get("fmt", "pdf")
    with get_db() as conn:
        bus = q.get_bus(conn, bus_id)
        if not bus:
            abort(404)
        students = q.students_for_bus(conn, bus_id)
    headers = ["Student Name", "SPR No", "Class", "Gender", "Boarding Status"]
    rows = [[s["name"], s["spr_no"], s["class_name"], s["gender"], s["boarding_status"]]
            for s in students]
    return build_report(f"{bus['number']} Student Report", headers, rows, fmt)
