import json
import time

from flask import Blueprint, render_template, request, jsonify, Response, stream_with_context

from shared.db.database import get_db
from shared.db import queries as q
from modules.reports.generator import build_report

live_bp = Blueprint("live", __name__, template_folder="../../templates")


@live_bp.route("/")
def index():
    with get_db() as conn:
        stats = q.live_stats(conn)
        all_buses = q.all_buses(conn)
    return render_template("live.html", stats=stats, all_buses=all_buses, active_tab="live")


@live_bp.route("/api/tracking/<bus_number>")
def get_bus_tracking(bus_number):
    """Fetch latest tracking data for a specific bus (API endpoint)."""
    try:
        with get_db() as conn:
            tracking = q.get_latest_tracking(conn, bus_number)
            if tracking:
                timestamp = tracking.get("timestamp")
                if timestamp is not None and not isinstance(timestamp, str):
                    timestamp = timestamp.isoformat() if hasattr(timestamp, "isoformat") else str(timestamp)

                return jsonify({
                    "status": "success",
                    "data": {
                        "bus_number": tracking.get("bus_number"),
                        "lat": tracking.get("lat"),
                        "lon": tracking.get("long"),
                        "speed": tracking.get("speed"),
                        "eta": tracking.get("eta"),
                        "status": tracking.get("status"),
                        "timestamp": timestamp
                    }
                }), 200
            else:
                return jsonify({
                    "status": "error",
                    "message": "No tracking data found for this bus"
                }), 404

    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500


@live_bp.route("/api/tracking/stream/<bus_number>")
def stream_bus_tracking(bus_number):
    """Stream latest tracking updates for a bus using SSE."""
    def event_stream():
        last_timestamp = None

        while True:
            try:
                with get_db() as conn:
                    tracking = q.get_latest_tracking(conn, bus_number)
            except Exception:
                tracking = None

            if tracking:
                timestamp = tracking.get("timestamp")
                if timestamp is not None and not isinstance(timestamp, str):
                    timestamp = timestamp.isoformat() if hasattr(timestamp, "isoformat") else str(timestamp)

                if timestamp != last_timestamp:
                    last_timestamp = timestamp
                    payload = {
                        "bus_number": tracking.get("bus_number"),
                        "lat": tracking.get("lat"),
                        "lon": tracking.get("long"),
                        "speed": tracking.get("speed"),
                        "eta": tracking.get("eta"),
                        "status": tracking.get("status"),
                        "timestamp": timestamp
                    }
                    data = json.dumps(payload)
                    yield f"event: update\ndata: {data}\n\n"
            else:
                yield "event: update\ndata: {\"speed\": null, \"eta\": null, \"status\": \"No data\", \"timestamp\": null}\n\n"

            time.sleep(1)

    return Response(stream_with_context(event_stream()), mimetype="text/event-stream")


@live_bp.route("/api/school")
def get_school_location():
    """Fetch school location (API endpoint)."""
    try:
        with get_db() as conn:
            school = q.get_school(conn)
            if school:
                return jsonify({
                    "status": "success",
                    "data": {
                        "name": school.get("name"),
                        "lat": school.get("lat"),
                        "lng": school.get("lng")
                    }
                }), 200
            else:
                return jsonify({
                    "status": "error",
                    "message": "School not found"
                }), 404
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500


@live_bp.route("/api/bus/<bus_number>")
def get_bus_info(bus_number):
    """Fetch current bus location from the bus table."""
    try:
        with get_db() as conn:
            bus = q.get_bus_by_number(conn, bus_number)
            if not bus:
                try:
                    bus = q.get_bus(conn, int(bus_number))
                except Exception:
                    bus = None

            if bus:
                return jsonify({
                    "status": "success",
                    "data": {
                        "number": bus.get("number"),
                        "lat": bus.get("lat"),
                        "lng": bus.get("lng"),
                        "route": bus.get("route")
                    }
                }), 200

            return jsonify({"status": "error", "message": "Bus not found"}), 404
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@live_bp.route("/api/bus-points")
def get_bus_points():
    """Fetch all bus stop points (API endpoint)."""
    try:
        with get_db() as conn:
            points = q.get_all_bus_points(conn)
            if points:
                return jsonify({
                    "status": "success",
                    "data": [
                        {
                            "id": p.get("id"),
                            "stop_name": p.get("stop_name"),
                            "lat": p.get("latitude"),
                            "lng": p.get("longitude")
                        }
                        for p in points
                    ]
                }), 200
            else:
                return jsonify({
                    "status": "success",
                    "data": []
                }), 200
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500


@live_bp.route("/report")
def report():
    fmt = request.args.get("fmt", "pdf")
    with get_db() as conn:
        buses = q.all_buses(conn)
    headers = ["Bus", "Plate", "Route", "Driver", "Status", "Lat", "Lng"]
    rows = [[b["number"], b["plate"], b["route"], b["driver"],
             b["status"], b["lat"], b["lng"]] for b in buses]
    return build_report("Live Day Wise Report", headers, rows, fmt)
