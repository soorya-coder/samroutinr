import os
import sys
from datetime import date, datetime

# Make `shared/` importable
_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from flask import Flask, redirect, url_for, render_template, request, session, jsonify

from config import Config
from shared.db.database import ensure_db_ready, get_db
from shared.db import queries as q
from shared.db.connection import MSSQL_SERVER, MSSQL_DATABASE
from modules.live.routes import live_bp
from modules.bus.routes import bus_bp      
from modules.classes.routes import classes_bp
from modules.alerts.routes import alerts_bp

def create_app():
    ensure_db_ready()  # create + seed DB on first run

    # Print database connection info
    print("\n" + "="*30)
    print("🗄️  MSSQL DATABASE CONNECTED")
    print("="*30)
    print(f"SERVER   : {MSSQL_SERVER}")
    print(f"DATABASE : {MSSQL_DATABASE}")
    print("="*30 + "\n")

    app = Flask(__name__)
    app.config.from_object(Config)

    app.register_blueprint(live_bp, url_prefix="/live")
    app.register_blueprint(bus_bp, url_prefix="/bus")
    app.register_blueprint(classes_bp, url_prefix="/classes")
    app.register_blueprint(alerts_bp, url_prefix="/alerts")

    @app.context_processor
    def inject_globals():
        return {
            "school_name": app.config["SCHOOL_NAME"],
            "today": date.today().strftime("%A, %d %B %Y"),
            "current_user": session.get("user"),
        }

    OPEN_ENDPOINTS = {"login", "logout", "index", "tracking"}

    @app.before_request
    def guard():
        ep = request.endpoint or ""
        if ep == "static" or ep.endswith(".static") or ep in OPEN_ENDPOINTS:
            return None

        user = session.get("user")
        if not user:
            return redirect(url_for("login"))

    @app.route("/")
    def index():
        if session.get("user"):
            return redirect(url_for("live.index"))
        return redirect(url_for("login"))

    @app.route("/login", methods=["GET", "POST"])
    def login():
        error = None
        if request.method == "POST":
            username = (request.form.get("username") or "").strip()
            password = request.form.get("password") or ""
            with get_db() as conn:
                user = q.find_admin_user(conn, username, password)
                if user:
                    session["user"] = {
                        "id": user["id"],
                        "username": user["username"],
                        "name": user["full_name"],
                        "bus_id": user["bus_id"],
                    }
                    return redirect(url_for("live.index"))
            error = "Invalid admin credentials."

        return render_template("login.html", error=error)

    @app.route("/logout")
    def logout():
        session.pop("user", None)
        return redirect(url_for("login"))

    @app.route("/tracking", methods=["POST"])
    def tracking():
        """Receive GPS tracking data from ESP32-S3 and store in database."""
        try:
            data = request.get_json()

            if not data:
                return jsonify({
                    "status": "error",
                    "message": "No JSON received"
                }), 400

            bus_number = data.get("bus_number")
            latitude = data.get("lat")
            longitude = data.get("lon")
            speed = data.get("speed")
            eta = data.get("eta")

            card_uid = data.get("card_uid")
            sprno = data.get("sprno")
            status = data.get("status")

            # Validate required fields
            if not bus_number or latitude is None or longitude is None:
                return jsonify({
                    "status": "error",
                    "message": "Missing required fields: bus_number, lat, lon"
                }), 400

            # Log the received data
            print("\n================================")
            print(f"Time      : {datetime.now()}")
            print(f"Bus Number: {bus_number}")
            print(f"Latitude  : {latitude}")
            print(f"Longitude : {longitude}")
            print(f"Speed     : {speed}")
            print(f"ETA       : {eta}")
            print(f"Card UID  : {card_uid}")
            print(f"SPR No    : {sprno}")
            print(f"Status    : {status}")
            print("================================")

            # Insert tracking data into database
            with get_db() as conn:
                q.insert_tracking_data(
                    conn,
                    bus_number=bus_number,
                    latitude=latitude,
                    longitude=longitude,
                    speed=speed,
                    eta=eta
                )

                q.insert_student_entry(
                    conn,
                    bus_number=bus_number,
                    card_uid=card_uid,
                    sprno=sprno,
                    status=status
                )
                
                # Update bus current location
                q.update_bus_location(conn, bus_number, latitude, longitude)

            return jsonify({
                "status": "success",
                "message": "Tracking data received and stored"
            }), 200

        except Exception as e:
            print("ERROR:", e)
            return jsonify({
                "status": "error",
                "message": str(e)
            }), 500

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=4013, debug=True, use_reloader=False)
