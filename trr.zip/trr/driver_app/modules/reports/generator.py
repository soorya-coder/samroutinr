"""Shared PDF + Excel generators. Pages call build_report(title, headers, rows, fmt)."""
import io
from flask import send_file

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer


def _excel(title, headers, rows):
    wb = Workbook()
    ws = wb.active
    ws.title = title[:30] or "Report"
    ws.append([title])
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=max(len(headers), 1))
    ws.cell(1, 1).font = Font(size=16, bold=True, color="FFFFFF")
    ws.cell(1, 1).fill = PatternFill("solid", fgColor="C96442")
    ws.cell(1, 1).alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 28

    ws.append(headers)
    for col_idx, _ in enumerate(headers, 1):
        c = ws.cell(2, col_idx)
        c.font = Font(bold=True, color="1D1D1F")
        c.fill = PatternFill("solid", fgColor="F5F4EE")
        c.alignment = Alignment(horizontal="left")

    for r in rows:
        ws.append([str(x) for x in r])

    from openpyxl.utils import get_column_letter
    for idx in range(1, len(headers) + 1):
        letter = get_column_letter(idx)
        max_len = 12
        for row in ws.iter_rows(min_row=2, min_col=idx, max_col=idx):
            v = row[0].value
            if v is not None:
                max_len = max(max_len, len(str(v)) + 2)
        ws.column_dimensions[letter].width = min(max_len, 40)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, as_attachment=True,
                     download_name=f"{title.replace(' ', '_')}.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


def _pdf(title, headers, rows):
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4),
                            leftMargin=24, rightMargin=24, topMargin=24, bottomMargin=24)
    styles = getSampleStyleSheet()
    story = [Paragraph(f"<b>{title}</b>", styles["Title"]), Spacer(1, 12)]

    data = [headers] + [[str(x) for x in r] for r in rows]
    if not rows:
        data.append(["No data"] + [""] * (len(headers) - 1))

    tbl = Table(data, repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#C96442")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 8),
        ("TOPPADDING", (0, 0), (-1, 0), 8),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#E8E6DF")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1),
         [colors.HexColor("#FFFFFF"), colors.HexColor("#FAFAF7")]),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story.append(tbl)
    doc.build(story)
    buf.seek(0)
    return send_file(buf, as_attachment=True,
                     download_name=f"{title.replace(' ', '_')}.pdf",
                     mimetype="application/pdf")


def build_report(title, headers, rows, fmt):
    fmt = (fmt or "pdf").lower()
    if fmt == "excel" or fmt == "xlsx":
        return _excel(title, headers, rows)
    return _pdf(title, headers, rows)
