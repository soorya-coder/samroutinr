from flask import Blueprint, render_template, request
from data.dummy_data import ALERTS
from modules.reports.generator import build_report

alerts_bp = Blueprint("alerts", __name__, template_folder="../../templates")


@alerts_bp.route("/")
def index():
    return render_template("alerts.html", alerts=ALERTS, active_tab="alerts")


@alerts_bp.route("/report")
def report():
    fmt = request.args.get("fmt", "pdf")
    headers = ["Severity", "Title", "Context", "Timestamp"]
    rows = [[a["severity"].title(), a["title"], a["context"], a["timestamp"]]
            for a in ALERTS]
    return build_report("Alerts Day Wise Report", headers, rows, fmt)
