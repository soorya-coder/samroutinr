from flask import Blueprint, render_template, request, abort
from data.dummy_data import BUSES, get_bus, students_for_bus
from modules.reports.generator import build_report

bus_bp = Blueprint("bus", __name__, template_folder="../../templates")


@bus_bp.route("/")
def list_buses():
    return render_template("bus/list.html", buses=BUSES, active_tab="bus")


@bus_bp.route("/<int:bus_id>")
def detail(bus_id):
    bus = get_bus(bus_id)
    if not bus:
        abort(404)
    students = students_for_bus(bus_id)
    return render_template("bus/detail.html", bus=bus, students=students, active_tab="bus")


@bus_bp.route("/report")
def report():
    fmt = request.args.get("fmt", "pdf")
    headers = ["Bus No.", "Plate", "Start Location", "Route", "Driver", "Status"]
    rows = [[b["number"], b["plate"], b["start_location"], b["route"],
             b["driver"], b["status"]] for b in BUSES]
    return build_report("Bus Day Wise Report", headers, rows, fmt)


@bus_bp.route("/<int:bus_id>/report")
def detail_report(bus_id):
    bus = get_bus(bus_id)
    if not bus:
        abort(404)
    fmt = request.args.get("fmt", "pdf")
    headers = ["Student Name", "SPR No", "Class", "Gender", "Boarding Status"]
    rows = [[s["name"], s["spr_no"], s["class_name"], s["gender"], s["boarding_status"]]
            for s in students_for_bus(bus_id)]
    return build_report(f"{bus['number']} Student Report", headers, rows, fmt)
