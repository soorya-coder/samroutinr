from flask import Blueprint, render_template, request
from data.dummy_data import BUSES, live_stats
from modules.reports.generator import build_report

live_bp = Blueprint("live", __name__, template_folder="../../templates")


@live_bp.route("/")
def index():
    return render_template("live.html", buses=BUSES, stats=live_stats(), active_tab="live")


@live_bp.route("/report")
def report():
    fmt = request.args.get("fmt", "pdf")
    headers = ["Bus", "Plate", "Route", "Driver", "Status", "Lat", "Lng"]
    rows = [[b["number"], b["plate"], b["route"], b["driver"],
             b["status"], b["lat"], b["lng"]] for b in BUSES]
    return build_report("Live Day Wise Report", headers, rows, fmt)
