from flask import Blueprint, render_template, request, abort
from data.dummy_data import class_summary, get_class, students_for_class
from modules.reports.generator import build_report

classes_bp = Blueprint("classes", __name__, template_folder="../../templates")


@classes_bp.route("/")
def index():
    return render_template("classes.html", classes=class_summary(), active_tab="classes")


@classes_bp.route("/<class_id>")
def detail(class_id):
    cls = get_class(class_id)
    if not cls:
        abort(404)
    students = students_for_class(class_id)
    return render_template("class_detail.html", cls=cls, students=students,
                           active_tab="classes")


@classes_bp.route("/report")
def report():
    fmt = request.args.get("fmt", "pdf")
    headers = ["Class", "Teacher", "Total", "Boarded", "Absent"]
    rows = [[c["name"], c["teacher"], c["total"], c["boarded"], c["absent"]]
            for c in class_summary()]
    return build_report("Class Day Wise Report", headers, rows, fmt)


@classes_bp.route("/<class_id>/report")
def detail_report(class_id):
    cls = get_class(class_id)
    if not cls:
        abort(404)
    fmt = request.args.get("fmt", "pdf")
    headers = ["Student Name", "SPR No", "Gender", "Bus", "Boarding Status"]
    rows = [[s["name"], s["spr_no"], s["gender"], s["bus_number"], s["boarding_status"]]
            for s in students_for_class(class_id)]
    return build_report(f"{cls['name']} Report", headers, rows, fmt)
