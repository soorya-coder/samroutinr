from datetime import date
from flask import Flask, redirect, url_for

from config import Config
from modules.live.routes import live_bp
from modules.bus.routes import bus_bp
from modules.classes.routes import classes_bp
from modules.alerts.routes import alerts_bp


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    app.register_blueprint(live_bp, url_prefix="/live")
    app.register_blueprint(bus_bp, url_prefix="/bus")
    app.register_blueprint(classes_bp, url_prefix="/classes")
    app.register_blueprint(alerts_bp, url_prefix="/alerts")

    @app.route("/")
    def index():
        return redirect(url_for("live.index"))

    @app.context_processor
    def inject_globals():
        return {
            "school_name": app.config["SCHOOL_NAME"],
            "today": date.today().strftime("%A, %d %B %Y"),
        }

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(host="127.0.0.1", port=5000, debug=True)
