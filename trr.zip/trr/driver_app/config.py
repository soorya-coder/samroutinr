class Config:
    SCHOOL_NAME = "XYZ School"
    SECRET_KEY = "dev-only-not-secret"
    DEBUG = True
