"""Pure geo helpers — used by route handlers without touching dummy data."""
import math

AVG_BUS_SPEED_KMH = 25.0


def haversine_km(lat1, lng1, lat2, lng2):
    R = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))


def eta_minutes(distance_km, speed_kmh=AVG_BUS_SPEED_KMH):
    if speed_kmh <= 0:
        return 0
    return int(round((distance_km / speed_kmh) * 60))


def nearest_location_name(lat, lng, points, max_distance_km=None):
    """Return the nearest stop name for the given lat/lng from a list of points."""
    if lat is None or lng is None or not points:
        return None

    best = None
    best_distance = None
    for point in points:
        try:
            point_lat = float(point.get("latitude"))
            point_lng = float(point.get("longitude"))
        except (TypeError, ValueError):
            continue

        dist = haversine_km(lat, lng, point_lat, point_lng)
        if best_distance is None or dist < best_distance:
            best_distance = dist
            best = point

    if best is None:
        return None
    if max_distance_km is not None and best_distance is not None and best_distance > max_distance_km:
        return None
    return best.get("stop_name")
