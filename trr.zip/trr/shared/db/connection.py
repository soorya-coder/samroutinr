"""
=====================================================================
DATABASE CONNECTION — single editable file
=====================================================================
This is the ONLY file you need to edit to change the database backend.

Current backend: MSSQL (pyodbc)
Connection string is configured via environment variables.

Required environment variables:
- MSSQL_SERVER
- MSSQL_DATABASE
- MSSQL_UID
- MSSQL_PWD
- MSSQL_DRIVER (optional, default: ODBC Driver 17 for SQL Server)

Example:
  set MSSQL_SERVER=103.207.1.91
  set MSSQL_DATABASE=cse9244
  set MSSQL_UID=myuser
  set MSSQL_PWD=mypassword

Note: `shared/db/schema.py` and `shared/db/seed.py` are now MSSQL-compatible.
=====================================================================
"""
import os

import pyodbc

# Prefer environment variables but fall back to local dev credentials.
# NOTE: Hardcoding credentials is convenient for local development only.
# Remove these defaults in production and use secure secret storage.
MSSQL_SERVER = os.environ.get("MSSQL_SERVER", "103.207.1.84")
MSSQL_DATABASE = os.environ.get("MSSQL_DATABASE", "transport")
MSSQL_UID = os.environ.get("MSSQL_UID", "transport")
MSSQL_PWD = os.environ.get("MSSQL_PWD", "claude@3908")
MSSQL_DRIVER = os.environ.get("MSSQL_DRIVER")

PREFERRED_DRIVERS = [
    "ODBC Driver 18 for SQL Server",
    "ODBC Driver 17 for SQL Server",
    "SQL Server Native Client 11.0",
    "SQL Server",
]


def _choose_mssql_driver():
    available = [d for d in pyodbc.drivers() if d]
    if MSSQL_DRIVER:
        if MSSQL_DRIVER in available:
            return MSSQL_DRIVER
        raise RuntimeError(
            f"Configured MSSQL_DRIVER '{MSSQL_DRIVER}' is not installed. "
            f"Available drivers: {available}"
        )

    for driver in PREFERRED_DRIVERS:
        if driver in available:
            return driver

    raise RuntimeError(
        "No supported MSSQL ODBC driver found. "
        f"Installed drivers: {available}. "
        "Install 'ODBC Driver 17 for SQL Server' or set MSSQL_DRIVER to a valid driver name."
    )


def _build_conn_str():
    driver = _choose_mssql_driver()
    parts = [
        f"DRIVER={{{driver}}}",
        f"SERVER={MSSQL_SERVER}",
        f"DATABASE={MSSQL_DATABASE}",
        f"UID={MSSQL_UID}",
        f"PWD={MSSQL_PWD}",
    ]
    if "ODBC Driver" in driver or "Native Client" in driver:
        parts.extend([
            "Encrypt=yes",
            "TrustServerCertificate=yes",
        ])
    return ";".join(parts) + ";"


def get_connection():
    """Return a fresh MSSQL connection."""
    conn = pyodbc.connect(_build_conn_str())
    conn.autocommit = False
    return conn


def db_exists():
    try:
        with get_connection() as conn:
            conn.execute("SELECT 1")
        return True
    except pyodbc.Error:
        return False
