"""Reusable SELECTs. Columns are aliased to match existing template field names
so templates keep working without changes.
"""

BUS_COLS = """
  id,
  bus_number        AS number,
  number_plate      AS plate,
  route_name        AS route,
  starting_location AS start_location,
  driver_name       AS driver,
  current_lat       AS lat,
  current_lng       AS lng,
  departure_status  AS status
"""

STUDENT_COLS = """
  s.id              AS id,
  s.name            AS name,
  s.spr_number      AS spr_no,
  s.class_id        AS class_id,
  c.class_id        AS class_name,
  s.gender          AS gender,
  s.bus_id          AS bus_id,
  b.bus_number      AS bus_number,
  s.boarding_status AS boarding_status,
  s.pickup_lat      AS pickup_lat,
  s.pickup_lng      AS pickup_lng,
  s.fees_balance    AS fees_balance,
  s.fees_status     AS fees_status,
  s.is_present      AS is_present,
  s.section         AS section
"""


def rows(cur):
    """Return current cursor's results as a list of plain dicts."""
    cols = [col[0] for col in cur.description]
    return [dict(zip(cols, row)) for row in cur.fetchall()]


def one(cur):
    r = cur.fetchone()
    if not r:
        return None
    if hasattr(r, "keys"):
        return dict(r)
    cols = [col[0] for col in cur.description]
    return dict(zip(cols, r))


# ---------- bus ----------

def all_buses(conn):
    return rows(conn.execute(f"SELECT {BUS_COLS} FROM bus ORDER BY id"))


def get_bus(conn, bus_id):
    return one(conn.execute(f"SELECT {BUS_COLS} FROM bus WHERE id = ?", (bus_id,)))


def get_bus_by_number(conn, bus_number):
    """Fetch a bus record by its bus_number (string)."""
    return one(conn.execute(f"SELECT {BUS_COLS} FROM bus WHERE bus_number = ?", (bus_number,)))


def bus_summary(conn):
    """Per-bus aggregated student stats — mirrors class_summary."""
    return rows(conn.execute(
        """SELECT
             b.id,
             b.bus_number,
             b.number_plate,
             b.route_name,
             b.driver_name,
             b.departure_status,
             b.starting_location,
             COUNT(s.id) AS assigned,
             COALESCE(SUM(CASE WHEN s.is_present = 1                                                THEN 1 ELSE 0 END), 0) AS present,
             COALESCE(SUM(CASE WHEN s.is_present = 1 AND s.boarding_status = 'Boarded'              THEN 1 ELSE 0 END), 0) AS boarded,
             COALESCE(SUM(CASE WHEN s.is_present = 1 AND s.boarding_status != 'Boarded'             THEN 1 ELSE 0 END), 0) AS not_boarded,
             COALESCE(SUM(CASE WHEN s.is_present = 0                                                THEN 1 ELSE 0 END), 0) AS absent
           FROM bus b
           LEFT JOIN student s ON s.bus_id = b.id
           GROUP BY b.id, b.bus_number, b.number_plate, b.route_name, b.driver_name, b.departure_status, b.starting_location
           ORDER BY b.id"""
    ))


def bus_overview_totals(conn):
    """Fleet-wide rollup — mirrors class_overview_totals."""
    return one(conn.execute(
        """SELECT
             (SELECT COUNT(*) FROM bus) AS total_buses,
             (SELECT COUNT(*) FROM bus WHERE departure_status != 'Not Departed') AS active,
             (SELECT COUNT(*) FROM student WHERE bus_id IS NOT NULL) AS assigned,
             (SELECT COUNT(*) FROM student WHERE bus_id IS NOT NULL AND is_present = 1) AS present,
             (SELECT COUNT(*) FROM student WHERE bus_id IS NOT NULL AND is_present = 1
                                            AND boarding_status = 'Boarded') AS boarded,
             (SELECT COUNT(*) FROM student WHERE bus_id IS NOT NULL AND is_present = 1
                                            AND boarding_status != 'Boarded') AS not_boarded,
             (SELECT COUNT(*) FROM student WHERE bus_id IS NOT NULL AND is_present = 0) AS absent"""
    ))


def students_for_bus(conn, bus_id):
    return rows(conn.execute(
        f"""SELECT {STUDENT_COLS}
            FROM student s
            JOIN school_class c ON s.class_id = c.id
            LEFT JOIN bus b ON s.bus_id = b.id
            WHERE s.bus_id = ?
            ORDER BY s.id""",
        (bus_id,),
    ))


# ---------- student ----------

def all_students(conn):
    return rows(conn.execute(
        f"""SELECT {STUDENT_COLS}
            FROM student s
            JOIN school_class c ON s.class_id = c.id
            LEFT JOIN bus b ON s.bus_id = b.id
            ORDER BY s.id"""
    ))


def get_student(conn, student_id):
    return one(conn.execute(
        f"""SELECT {STUDENT_COLS}
            FROM student s
            JOIN school_class c ON s.class_id = c.id
            LEFT JOIN bus b ON s.bus_id = b.id
            WHERE s.id = ?""",
        (student_id,),
    ))


def student_roster(conn, bus_only=False):
    sql = "SELECT id, name, spr_number AS spr_no FROM student"
    if bus_only:
        sql += " WHERE bus_id IS NOT NULL"
    sql += " ORDER BY id"
    return rows(conn.execute(sql))


def class_summary(conn):
    return rows(conn.execute(
        """SELECT
             c.id,
             c.class_id AS name,
             c.teacher,
             COUNT(s.id) AS total,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL                                                   THEN 1 ELSE 0 END), 0) AS bus_users,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1                              THEN 1 ELSE 0 END), 0) AS present,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1
                                AND s.boarding_status = 'Boarded'                                         THEN 1 ELSE 0 END), 0) AS boarded,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1
                                AND s.boarding_status != 'Boarded'                                        THEN 1 ELSE 0 END), 0) AS not_boarded,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 0                             THEN 1 ELSE 0 END), 0) AS absent
           FROM school_class c
           LEFT JOIN student s ON s.class_id = c.id
           GROUP BY c.id, c.class_id, c.teacher
           ORDER BY c.id"""
    ))


def class_overview_totals(conn):
    """Aggregated totals across all classes for the Classes-page header strip."""
    return one(conn.execute(
        """SELECT
             COUNT(s.id) AS total,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL                                                   THEN 1 ELSE 0 END), 0) AS bus_users,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1                              THEN 1 ELSE 0 END), 0) AS present,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1
                                AND s.boarding_status = 'Boarded'                                         THEN 1 ELSE 0 END), 0) AS boarded,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1
                                AND s.boarding_status != 'Boarded'                                        THEN 1 ELSE 0 END), 0) AS not_boarded,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 0                             THEN 1 ELSE 0 END), 0) AS absent
           FROM student s"""
    ))

def absent_students_today(conn):
    return rows(conn.execute(
        """SELECT s.id, s.name, s.section,
                  c.class_id   AS class_name,
                  b.bus_number AS bus_number
           FROM student s
           JOIN school_class c ON s.class_id = c.id
           LEFT JOIN bus b ON s.bus_id = b.id
           WHERE s.is_present = 0
           ORDER BY c.id, s.name"""
    ))


def get_class(conn, class_id):
    return one(conn.execute(
        "SELECT id, class_id AS name, teacher FROM school_class WHERE id = ?", (class_id,)
    ))


def students_for_class(conn, class_id):
    return rows(conn.execute(
        f"""SELECT {STUDENT_COLS}
            FROM student s
            JOIN school_class c ON s.class_id = c.id
            LEFT JOIN bus b ON s.bus_id = b.id
            WHERE s.class_id = ?
            ORDER BY s.id""",
        (class_id,),
    ))


# ---------- alerts ----------

def all_alerts(conn):
    return rows(conn.execute(
        """SELECT a.id,
                  a.message     AS title,
                  a.description AS description,
                  a.severity    AS severity,
                  a.timestamp   AS timestamp,
                  CASE
                    WHEN b.bus_number IS NULL AND b.route_name IS NULL THEN ''
                    ELSE CONCAT(b.bus_number, ' — ', b.route_name)
                  END AS context
           FROM alert a
           LEFT JOIN bus b ON a.bus_id = b.id
           ORDER BY a.timestamp DESC"""
    ))


# ---------- live stats ----------

def live_stats(conn):
    return one(conn.execute(
        """SELECT
             (SELECT COUNT(*) FROM bus     WHERE departure_status != 'Not Departed') AS active_buses,
             (SELECT COUNT(*) FROM student WHERE boarding_status   = 'Boarded')      AS boarded,
             (SELECT COUNT(*) FROM student WHERE boarding_status   = 'Not Boarded')  AS absent"""
    ))


# ---------- school ----------

def get_school(conn):
    return one(conn.execute("SELECT TOP 1 id, name, lat, lng FROM school"))


# ---------- auth ----------

def find_admin_user(conn, username, password):
    """Plain-equality credential check. Replace with hashed compare for prod."""
    if not username or password is None:
        return None
    return one(conn.execute(
        """SELECT id, username, password, full_name, bus_id
           FROM admin_user
           WHERE username = ? AND password = ?""",
        (username, password),
    ))


def find_student_by_spr_dob(conn, spr_number, dob):
    """Look up a student by SPR + date of birth (YYYY-MM-DD)."""
    if not spr_number or not dob:
        return None
    return one(conn.execute(
        f"""SELECT {STUDENT_COLS}
            FROM student s
            JOIN school_class c ON s.class_id = c.id
            LEFT JOIN bus b ON s.bus_id = b.id
            WHERE s.spr_number = ? AND s.dob = ?""",
        (spr_number, dob),
    ))


# ---------- tracking (ESP32) ----------

def insert_tracking_data(conn, bus_number, latitude, longitude, speed=None, eta=None):
    """Insert GPS tracking data from ESP32-S3."""
    print("bus_number =", bus_number, type(bus_number))
    conn.execute(
        """INSERT INTO tracking_data (bus_number, lat, long, speed, eta)
           VALUES (?, ?, ?, ?, ?)""",
        (bus_number, latitude, longitude, speed, eta),
    )
    conn.commit()


def insert_student_entry(conn, bus_number, card_uid=None, sprno=None, status=None):
    """Insert RFID/student entry data from the tracking payload."""
    conn.execute(
        """INSERT INTO student_entry (bus_number, card_uid, sprno, status)
           VALUES (?, ?, ?, ?)""",
        (bus_number, card_uid, sprno, status),
    )
    conn.commit()


def update_bus_location(conn, bus_number, latitude, longitude):
    """Update current bus location from tracking data."""
    conn.execute(
        """UPDATE bus
           SET current_lat = ?, current_lng = ?
           WHERE bus_number = ?""",
        (latitude, longitude, bus_number),
    )
    conn.commit()


def get_latest_tracking(conn, bus_number):
    """Fetch the latest tracking data for a specific bus."""
    return one(conn.execute(
        """SELECT TOP 1 bus_number, lat, long, speed, eta, timestamp
           FROM tracking_data
           WHERE bus_number = ?
           ORDER BY timestamp DESC""",
        (bus_number,),
    ))


def get_all_bus_points(conn):
    """Fetch all bus stop points."""
    return rows(conn.execute(
        """SELECT id, stop_name, latitude, longitude
           FROM bus_points
           ORDER BY id"""
    ))


# ---------- route tracking history ----------

def insert_route_session(conn, bus_number, student_id=None):
    """Create a fresh route session and return its new session_id."""
    conn.execute(
        """INSERT INTO bus_route_sessions (bus_number, student_id, started_at, created_at)
VALUES (?, ?, GETDATE(), GETDATE())""",
        (bus_number, student_id),
    )
    conn.commit()
    row = one(conn.execute("SELECT CAST(@@IDENTITY AS INT) AS session_id"))
    return row["session_id"] if row else None


def end_route_session(conn, session_id):
    """Mark a route session as ended."""
    conn.execute(
        """UPDATE bus_route_sessions
           SET ended_at = GETDATE()
           WHERE session_id = ?""",
        (session_id,),
    )
    conn.commit()


def get_next_route_point_seq(conn, session_id):
    """Return the next point sequence for a route session."""
    row = one(conn.execute(
        """SELECT COALESCE(MAX(point_seq), 0) + 1 AS next_seq
           FROM bus_route_points
           WHERE session_id = ?""",
        (session_id,),
    ))
    return row["next_seq"] if row else 1


def insert_route_point(conn, session_id, point_seq, lat, lng):
    """Insert one point into the route history table."""
    conn.execute(
        """INSERT INTO bus_route_points (session_id, point_seq, lat, lng, captured_at)
           VALUES (?, ?, ?, ?, GETDATE())""",
        (session_id, point_seq, lat, lng),
    )
    conn.commit()


def get_last_route_session(conn, bus_number):
    """Fetch the most recent route session for a bus."""
    return one(conn.execute(
        """SELECT TOP 1
                session_id,
                bus_number,
                student_id,
                started_at,
                ended_at
           FROM bus_route_sessions
           WHERE bus_number = ?
           ORDER BY started_at DESC""",
        (bus_number,),
    ))


def get_available_route_sessions(conn, bus_number):
    """Fetch all saved route sessions that have recorded points for a bus."""
    return rows(conn.execute(
        """SELECT DISTINCT
                s.session_id,
                s.bus_number,
                s.student_id,
                s.started_at,
                s.ended_at
           FROM bus_route_sessions s
           INNER JOIN bus_route_points p ON p.session_id = s.session_id
           WHERE s.bus_number = ?
           ORDER BY s.started_at DESC, s.session_id DESC""",
        (bus_number,),
    ))


def get_route_session(conn, session_id):
    """Fetch a route session by its id."""
    return one(conn.execute(
        """SELECT
                session_id,
                bus_number,
                student_id,
                started_at,
                ended_at
           FROM bus_route_sessions
           WHERE session_id = ?""",
        (session_id,),
    ))


def get_route_points(conn, session_id):
    """Fetch all points for a route session."""
    return rows(conn.execute(
        """SELECT
                point_seq,
                lat,
                lng,
                captured_at
           FROM bus_route_points
           WHERE session_id = ?
           ORDER BY point_seq""",
        (session_id,),
    ))
