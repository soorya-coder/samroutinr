"""Schema DDL. Plain SQL — no ORM."""

SCHEMA_SQL = """
IF OBJECT_ID(N'dbo.school', N'U') IS NULL
CREATE TABLE dbo.school (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    lat FLOAT NOT NULL,
    long FLOAT NOT NULL
);

IF OBJECT_ID(N'dbo.school_class', N'U') IS NULL
CREATE TABLE dbo.school_class (
    id INT IDENTITY(1,1) PRIMARY KEY,
    class_id NVARCHAR(255) NOT NULL,
    teacher NVARCHAR(255)
);

IF OBJECT_ID(N'dbo.bus', N'U') IS NULL
CREATE TABLE dbo.bus (
    id INT PRIMARY KEY,
    bus_number NVARCHAR(255) NOT NULL,
    number_plate NVARCHAR(255) NOT NULL,
    route_name NVARCHAR(255) NOT NULL,
    starting_location NVARCHAR(255) NOT NULL,
    current_lat FLOAT NOT NULL,
    current_lng FLOAT NOT NULL,
    departure_status NVARCHAR(255) NOT NULL,
    driver_name NVARCHAR(255) NOT NULL
);

IF OBJECT_ID(N'dbo.student', N'U') IS NULL
CREATE TABLE dbo.student (
    id INT PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    spr_number NVARCHAR(255) NOT NULL UNIQUE,
    class_id INT NOT NULL REFERENCES dbo.school_class(id),
    bus_id INT REFERENCES dbo.bus(id),
    gender NVARCHAR(50) NOT NULL,
    boarding_status NVARCHAR(255) NOT NULL,
    pickup_lat FLOAT NOT NULL,
    pickup_lng FLOAT NOT NULL,
    fees_balance FLOAT NOT NULL DEFAULT 0,
    fees_status NVARCHAR(50) NOT NULL,
    is_present BIT NOT NULL DEFAULT 1,
    section NVARCHAR(10),
    dob NVARCHAR(20)
);

IF OBJECT_ID(N'dbo.admin_user', N'U') IS NULL
CREATE TABLE dbo.admin_user (
    id INT IDENTITY(1,1) PRIMARY KEY,
    username NVARCHAR(255) NOT NULL UNIQUE,
    password NVARCHAR(255) NOT NULL,
    full_name NVARCHAR(255),
    bus_id INT REFERENCES dbo.bus(id)
);

IF OBJECT_ID(N'dbo.alert', N'U') IS NULL
CREATE TABLE dbo.alert (
    id INT PRIMARY KEY,
    message NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX),
    severity NVARCHAR(50) NOT NULL,
    timestamp NVARCHAR(50) NOT NULL,
    bus_id INT REFERENCES dbo.bus(id),
    student_id INT REFERENCES dbo.student(id)
);

IF OBJECT_ID(N'dbo.tracking_data', N'U') IS NULL
CREATE TABLE dbo.tracking_data (
    id INT IDENTITY(1,1) PRIMARY KEY,
    bus_number VARCHAR(50),
    lat FLOAT NOT NULL,
    long FLOAT NOT NULL,
    speed FLOAT,
    eta VARCHAR(50),
    timestamp DATETIME DEFAULT GETDATE()
);

IF OBJECT_ID(N'dbo.student_entry', N'U') IS NULL
CREATE TABLE dbo.student_entry (
    id INT IDENTITY(1,1) PRIMARY KEY,
    bus_number VARCHAR(50),
    card_uid VARCHAR(50),
    sprno VARCHAR(50),
    status VARCHAR(20),
    timestamp DATETIME DEFAULT GETDATE()
);

IF OBJECT_ID(N'dbo.bus_points', N'U') IS NULL
CREATE TABLE dbo.bus_points (
    id INT IDENTITY(1,1) PRIMARY KEY,
    stop_name NVARCHAR(255) NOT NULL,
    latitude FLOAT NOT NULL,
    longitude FLOAT NOT NULL
);

IF OBJECT_ID(N'dbo.TEST', N'U') IS NULL
CREATE TABLE dbo.TEST (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX),
    value INT,
    created_at DATETIME DEFAULT GETDATE()
);
"""

DROP_SQL = """
DROP TABLE IF EXISTS dbo.TEST;
DROP TABLE IF EXISTS dbo.student_entry;
DROP TABLE IF EXISTS dbo.bus_points;
DROP TABLE IF EXISTS dbo.tracking_data;
DROP TABLE IF EXISTS dbo.alert;
DROP TABLE IF EXISTS dbo.admin_user;
DROP TABLE IF EXISTS dbo.student;
DROP TABLE IF EXISTS dbo.bus;
DROP TABLE IF EXISTS dbo.school_class;
DROP TABLE IF EXISTS dbo.school;
"""
