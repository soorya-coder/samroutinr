"""Drop, recreate, and seed the MSSQL DB from shared/data/dummy_data.py.
Run with:  python -m shared.db.seed
"""
import os
import re
import sys

_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from shared.db.connection import get_connection
from shared.db.schema import SCHEMA_SQL, DROP_SQL
from shared.data import dummy_data as dd


def _execute_sql_script(cur, sql):
    for statement in (s.strip() for s in sql.split(";") if s.strip()):
        cur.execute(statement)

def _insert_returning_id(cur, sql, params):
    cur.execute(sql, params)
    row = cur.fetchone()
    return int(row[0]) if row else None


def seed():
    with get_connection() as conn:
        cur = conn.cursor()
        _execute_sql_script(cur, DROP_SQL)
        _execute_sql_script(cur, SCHEMA_SQL)

        # School
        cur.execute(
            "INSERT INTO dbo.school (name, lat, lng) VALUES (?, ?, ?)",
            (dd.SCHOOL["name"], dd.SCHOOL["lat"], dd.SCHOOL["lng"]),
        )

        # Classes — preserve string id ("5A") -> int pk mapping for students
        class_id_map = {}
        for c in dd.CLASSES:
            class_id = _insert_returning_id(
                cur,
                "INSERT INTO dbo.school_class (class_id, teacher) OUTPUT INSERTED.id VALUES (?, ?)",
                (c["name"], c.get("teacher")),
            )
            class_id_map[c["id"]] = class_id

        # Buses — keep dummy ids aligned with PKs
        bus_by_number = {}
        for b in dd.BUSES:
            cur.execute(
                """INSERT INTO dbo.bus
                   (id, bus_number, number_plate, route_name, starting_location,
                    current_lat, current_lng, departure_status, driver_name)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (b["id"], b["number"], b["plate"], b["route"], b["start_location"],
                 b["lat"], b["lng"], b["status"], b["driver"]),
            )
            bus_by_number[b["number"]] = b["id"]

        # Students
        for s in dd.STUDENTS:
            cur.execute(
                """INSERT INTO dbo.student
                   (id, name, spr_number, class_id, bus_id, gender, boarding_status,
                    pickup_lat, pickup_lng, fees_balance, fees_status,
                    is_present, section, dob)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (s["id"], s["name"], s["spr_no"], class_id_map[s["class_id"]],
                 s["bus_id"], s["gender"], s["boarding_status"],
                 s["pickup_lat"], s["pickup_lng"],
                 float(s.get("fees_balance", 0) or 0),
                 s.get("fees_status", "Paid"),
                 1 if s.get("is_present", True) else 0,
                 s.get("section", "A"),
                 s.get("dob")),
            )

        # Driver login accounts
        for d in dd.ADMIN_USERS:
            cur.execute(
                """INSERT INTO dbo.admin_user (username, password, full_name, bus_id)
                   VALUES (?,?,?,?)""",
                (d["username"], d["password"], d["full_name"], d["bus_id"]),
            )

        # Alerts — try to backfill bus_id from "Bus N" in the original context string
        for a in dd.ALERTS:
            ctx = a.get("context", "")
            m = re.search(r"(Bus\s+\d+)", ctx)
            bus_pk = bus_by_number.get(m.group(1)) if m else None
            cur.execute(
                """INSERT INTO dbo.alert
                   (id, message, description, severity, timestamp, bus_id, student_id)
                   VALUES (?,?,?,?,?,?,?)""",
                (a["id"], a.get("title"), a.get("description"), a["severity"],
                 a["timestamp"], bus_pk, None),
            )

        # Bus Points (stops)
        for p in dd.BUS_POINTS:
            cur.execute(
                """INSERT INTO dbo.bus_points (stop_name, latitude, longitude)
                   VALUES (?,?,?)""",
                (p["stop_name"], p["lat"], p["lng"]),
            )

        conn.commit()

        counts = {
            t: cur.execute(f"SELECT COUNT(*) FROM dbo.{t}").fetchone()[0]
            for t in ("bus", "student", "school_class", "alert", "school", "admin_user", "bus_points")
        }
        print(
            f"Seeded {counts['bus']} buses, {counts['student']} students, "
            f"{counts['school_class']} classes, {counts['alert']} alerts, "
            f"{counts['school']} school, {counts['admin_user']} admin users, "
            f"{counts['bus_points']} bus points."
        )


if __name__ == "__main__":
    seed()
