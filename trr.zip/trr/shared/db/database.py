"""Session helpers + lifecycle. Connection details live in connection.py."""
from contextlib import contextmanager

from shared.db.connection import get_connection, db_exists


@contextmanager
def get_db():
    """Yield a connection with dict-like row access. Auto-closes."""
    conn = get_connection()
    try:
        yield conn
    finally:
        conn.close()


def _execute_sql_script(conn, sql):
    for statement in (s.strip() for s in sql.split(";") if s.strip()):
        conn.execute(statement)


def init_db():
    """Create tables if they don't exist (no data)."""
    from shared.db.schema import SCHEMA_SQL
    with get_connection() as conn:
        _execute_sql_script(conn, SCHEMA_SQL)
        conn.commit()


def _table_exists(conn, table_name):
    cur = conn.execute(
        "SELECT 1 FROM INFORMATION_SCHEMA.TABLES "
        "WHERE TABLE_NAME = ? AND TABLE_SCHEMA = 'dbo'",
        (table_name,),
    )
    return cur.fetchone() is not None


def ensure_db_ready():
    """Ensure all required tables exist. Create missing tables on startup."""
    REQUIRED_TABLES = [
        "school",
        "school_class",
        "bus",
        "student",
        "admin_user",
        "alert",
        "tracking_data",
        "bus_points",
        "TEST",
    ]
    
    if not db_exists():
        from shared.db.seed import seed
        seed()
        return

    with get_connection() as conn:
        # Check if any required table is missing
        missing_tables = [t for t in REQUIRED_TABLES if not _table_exists(conn, t)]
        
        if missing_tables:
            # If any required table is missing, create all tables from schema
            print(f"⚠️  Missing tables detected: {', '.join(missing_tables)}")
            print("📋 Creating missing tables from schema...")
            from shared.db.schema import SCHEMA_SQL
            _execute_sql_script(conn, SCHEMA_SQL)
            conn.commit()
            print("✅ Tables created successfully!")
        
        # If school table exists but is empty, seed the database
        if _table_exists(conn, "school"):
            cur = conn.execute("SELECT COUNT(*) FROM school")
            school_count = cur.fetchone()[0]
            if school_count == 0:
                from shared.db.seed import seed
                seed()
        else:
            # Fallback: if school table doesn't exist, do full seed
            from shared.db.seed import seed
            seed()
