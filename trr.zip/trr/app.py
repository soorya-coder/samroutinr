"""
Unified Mount Zion Schools transport app.
Runs driver + student under one Flask process on a single configurable port.

Run:    python app.py
Edit:   config.py  (PORT, SCHOOL_NAME, SECRET_KEY)
Reseed: python -m shared.db.seed
"""
import os
import sys
from datetime import date

BASE = os.path.dirname(os.path.abspath(__file__))
DRIVER_DIR = os.path.join(BASE, "driver_app")
# Forcibly remove any prior entries so we control the order regardless of how
# Python was invoked (`python app.py` puts BASE on sys.path automatically).
# Final order must be [BASE, DRIVER_DIR, ...] so:
#   - `from config import Config`  resolves to the ROOT config.py (has PORT)
#   - `from modules.reports...`    inside driver blueprints still resolves
# We intentionally do NOT add student_app/ — its `modules` package would
# collide with driver_app's, and student blueprints use only absolute imports.
for p in (BASE, DRIVER_DIR):
    while p in sys.path:
        sys.path.remove(p)
sys.path.insert(0, DRIVER_DIR)
sys.path.insert(0, BASE)

from flask import Flask, render_template, request, redirect, url_for, session

from config import Config
from shared.db.database import ensure_db_ready, get_db
from shared.db import queries as q
from shared.db.connection import MSSQL_SERVER, MSSQL_DATABASE

# Blueprints
from driver_app.modules.live.routes import live_bp
from driver_app.modules.bus.routes import bus_bp
from driver_app.modules.classes.routes import classes_bp
from driver_app.modules.alerts.routes import alerts_bp
from student_app.modules.dashboard.routes import dashboard_bp


def create_app():
    ensure_db_ready()

    # Print database connection info
    print("\n" + "="*60)
    print("🗄️  MSSQL DATABASE CONNECTED")
    print("="*60)
    print(f"📍 Server   : {MSSQL_SERVER}")
    print(f"📚 Database : {MSSQL_DATABASE}")
    print("="*60 + "\n")

    app = Flask(
        __name__,
        static_folder=os.path.join(BASE, "static"),
        template_folder=os.path.join(BASE, "templates"),
    )
    app.config.from_object(Config)

    # Mount blueprints — driver under /driver, student under /student
    app.register_blueprint(live_bp,      url_prefix="/driver/live")
    app.register_blueprint(bus_bp,       url_prefix="/driver/bus")
    app.register_blueprint(classes_bp,   url_prefix="/driver/classes")
    app.register_blueprint(alerts_bp,    url_prefix="/driver/alerts")
    app.register_blueprint(dashboard_bp, url_prefix="/student")

    @app.context_processor
    def inject_globals():
        return {
            "school_name": app.config["SCHOOL_NAME"],
            "today": date.today().strftime("%A, %d %B %Y"),
            "current_user": session.get("user"),
        }

    # ---------- Auth guard ----------
    OPEN_ENDPOINTS = {"login", "logout", "index"}

    @app.before_request
    def guard():
        ep = request.endpoint or ""
        # static file requests (any blueprint's static endpoint ends with ".static")
        if ep == "static" or ep.endswith(".static") or ep in OPEN_ENDPOINTS:
            return None

        user = session.get("user")
        path = request.path
        if path.startswith("/driver"):
            if not user or user.get("role") != "driver":
                return redirect(url_for("login", role="driver"))
        elif path.startswith("/student"):
            if not user or user.get("role") != "student":
                return redirect(url_for("login", role="student"))

    # ---------- Routes ----------
    @app.route("/")
    def index():
        user = session.get("user")
        if user and user.get("role") == "driver":
            return redirect(url_for("live.index"))
        if user and user.get("role") == "student":
            return redirect(url_for("dashboard.index"))
        return redirect(url_for("login"))

    @app.route("/login", methods=["GET", "POST"])
    def login():
        error = None
        role = (request.values.get("role") or "driver").lower()
        if role not in ("driver", "student"):
            role = "driver"

        if request.method == "POST":
            with get_db() as conn:
                if role == "driver":
                    username = (request.form.get("username") or "").strip()
                    password = request.form.get("password") or ""
                    user = q.find_admin_user(conn, username, password)
                    if user:
                        session["user"] = {
                            "role": "driver",
                            "id": user["id"],
                            "username": user["username"],
                            "name": user["full_name"],
                            "bus_id": user["bus_id"],
                        }
                        return redirect(url_for("live.index"))
                    error = "Invalid driver credentials."
                else:
                    spr = (request.form.get("spr") or "").strip()
                    dob = (request.form.get("dob") or "").strip()
                    student = q.find_student_by_spr_dob(conn, spr, dob)
                    if student:
                        session["user"] = {
                            "role": "student",
                            "id": student["id"],
                            "spr_no": student["spr_no"],
                            "name": student["name"],
                        }
                        return redirect(url_for("dashboard.index"))
                    error = "Invalid SPR number or date of birth."

        return render_template("login.html", role=role, error=error)

    @app.route("/logout")
    def logout():
        session.pop("user", None)
        return redirect(url_for("login"))

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(
        host="127.0.0.1",
        port=app.config["PORT"],
        debug=app.config["DEBUG"],
        use_reloader=False,
    )
