"use strict";
// Pure geo helpers — used by route handlers without touching dummy data.

const AVG_BUS_SPEED_KMH = 25.0;

function haversineKm(lat1, lng1, lat2, lng2) {
  const R = 6371.0;
  const p1 = (lat1 * Math.PI) / 180;
  const p2 = (lat2 * Math.PI) / 180;
  const dp = ((lat2 - lat1) * Math.PI) / 180;
  const dl = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dp / 2) ** 2 +
    Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

function etaMinutes(distanceKm, speedKmh = AVG_BUS_SPEED_KMH) {
  if (speedKmh <= 0) return 0;
  return Math.round((distanceKm / speedKmh) * 60);
}

function nearestLocationName(lat, lng, points, maxDistanceKm = null) {
  // Return the nearest stop name for the given lat/lng from a list of points.
  if (lat === null || lat === undefined || lng === null || lng === undefined || !points || !points.length) {
    return null;
  }

  let best = null;
  let bestDistance = null;
  for (const point of points) {
    let pointLat, pointLng;
    try {
      pointLat = parseFloat(point.latitude);
      pointLng = parseFloat(point.longitude);
      if (Number.isNaN(pointLat) || Number.isNaN(pointLng)) continue;
    } catch (e) {
      continue;
    }

    const dist = haversineKm(lat, lng, pointLat, pointLng);
    if (bestDistance === null || dist < bestDistance) {
      bestDistance = dist;
      best = point;
    }
  }

  if (best === null) return null;
  if (maxDistanceKm !== null && bestDistance !== null && bestDistance > maxDistanceKm) {
    return null;
  }
  return best.stop_name;
}

module.exports = { AVG_BUS_SPEED_KMH, haversineKm, etaMinutes, nearestLocationName };
