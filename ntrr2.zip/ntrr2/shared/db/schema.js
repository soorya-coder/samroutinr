"use strict";
// Schema DDL — SQLite dialect. Plain SQL, no ORM.
// Ported from the original MSSQL `shared/db/schema.py`. Notes on the port:
//   * IDENTITY(1,1)        -> INTEGER PRIMARY KEY AUTOINCREMENT
//   * BIT                  -> INTEGER (0/1)
//   * NVARCHAR/VARCHAR     -> TEXT
//   * FLOAT                -> REAL
//   * GETDATE() defaults   -> CURRENT_TIMESTAMP
//   * `school.lng` is used (the Python queries/seed read/write `lng`, not `long`).
//   * bus_route_sessions / bus_route_points are added here — the Python queries
//     referenced them but they were created out-of-band in the live MSSQL DB.

const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS school (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    lat REAL NOT NULL,
    lng REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS school_class (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    class_id TEXT NOT NULL,
    teacher TEXT
);

CREATE TABLE IF NOT EXISTS bus (
    id INTEGER PRIMARY KEY,
    bus_number TEXT NOT NULL,
    number_plate TEXT NOT NULL,
    route_name TEXT NOT NULL,
    starting_location TEXT NOT NULL,
    current_lat REAL NOT NULL,
    current_lng REAL NOT NULL,
    departure_status TEXT NOT NULL,
    driver_name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS student (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    spr_number TEXT NOT NULL UNIQUE,
    class_id INTEGER NOT NULL REFERENCES school_class(id),
    bus_id INTEGER REFERENCES bus(id),
    gender TEXT NOT NULL,
    boarding_status TEXT NOT NULL,
    pickup_lat REAL NOT NULL,
    pickup_lng REAL NOT NULL,
    fees_balance REAL NOT NULL DEFAULT 0,
    fees_status TEXT NOT NULL,
    is_present INTEGER NOT NULL DEFAULT 1,
    section TEXT,
    dob TEXT
);

CREATE TABLE IF NOT EXISTS admin_user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    full_name TEXT,
    bus_id INTEGER REFERENCES bus(id)
);

CREATE TABLE IF NOT EXISTS alert (
    id INTEGER PRIMARY KEY,
    message TEXT NOT NULL,
    description TEXT,
    severity TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    bus_id INTEGER REFERENCES bus(id),
    student_id INTEGER REFERENCES student(id)
);

CREATE TABLE IF NOT EXISTS tracking_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bus_number TEXT,
    lat REAL NOT NULL,
    long REAL NOT NULL,
    speed REAL,
    eta TEXT,
    timestamp TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS student_entry (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bus_number TEXT,
    card_uid TEXT,
    sprno TEXT,
    status TEXT,
    timestamp TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bus_points (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    stop_name TEXT NOT NULL,
    latitude REAL NOT NULL,
    longitude REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS TEST (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    value INTEGER,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bus_route_sessions (
    session_id INTEGER PRIMARY KEY AUTOINCREMENT,
    bus_number TEXT,
    student_id INTEGER,
    started_at TEXT,
    ended_at TEXT,
    created_at TEXT
);

CREATE TABLE IF NOT EXISTS bus_route_points (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER REFERENCES bus_route_sessions(session_id),
    point_seq INTEGER NOT NULL,
    lat REAL NOT NULL,
    lng REAL NOT NULL,
    captured_at TEXT
);
`;

const DROP_SQL = `
DROP TABLE IF EXISTS bus_route_points;
DROP TABLE IF EXISTS bus_route_sessions;
DROP TABLE IF EXISTS TEST;
DROP TABLE IF EXISTS student_entry;
DROP TABLE IF EXISTS bus_points;
DROP TABLE IF EXISTS tracking_data;
DROP TABLE IF EXISTS alert;
DROP TABLE IF EXISTS admin_user;
DROP TABLE IF EXISTS student;
DROP TABLE IF EXISTS bus;
DROP TABLE IF EXISTS school_class;
DROP TABLE IF EXISTS school;
`;

const REQUIRED_TABLES = [
  "school",
  "school_class",
  "bus",
  "student",
  "admin_user",
  "alert",
  "tracking_data",
  "bus_points",
  "TEST",
];

module.exports = { SCHEMA_SQL, DROP_SQL, REQUIRED_TABLES };
