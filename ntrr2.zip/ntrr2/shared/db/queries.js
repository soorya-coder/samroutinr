"use strict";
// Reusable SELECTs. Columns are aliased to match the template field names so
// templates keep working without changes. Ported from `shared/db/queries.py`
// to the SQLite dialect (TOP n -> LIMIT n, CONCAT -> ||, GETDATE() ->
// datetime('now'), @@IDENTITY -> last_insert_rowid()).

const BUS_COLS = `
  id,
  bus_number        AS number,
  number_plate      AS plate,
  route_name        AS route,
  starting_location AS start_location,
  driver_name       AS driver,
  current_lat       AS lat,
  current_lng       AS lng,
  departure_status  AS status
`;

const STUDENT_COLS = `
  s.id              AS id,
  s.name            AS name,
  s.spr_number      AS spr_no,
  s.class_id        AS class_id,
  c.class_id        AS class_name,
  s.gender          AS gender,
  s.bus_id          AS bus_id,
  b.bus_number      AS bus_number,
  s.boarding_status AS boarding_status,
  s.pickup_lat      AS pickup_lat,
  s.pickup_lng      AS pickup_lng,
  s.fees_balance    AS fees_balance,
  s.fees_status     AS fees_status,
  s.is_present      AS is_present,
  s.section         AS section
`;

// Helpers — `one` returns null (not undefined) when there is no row.
function one(stmtResult) {
  return stmtResult === undefined || stmtResult === null ? null : stmtResult;
}

// ---------- bus ----------

function allBuses(conn) {
  return conn.prepare(`SELECT ${BUS_COLS} FROM bus ORDER BY id`).all();
}

function getBus(conn, busId) {
  return one(conn.prepare(`SELECT ${BUS_COLS} FROM bus WHERE id = ?`).get(busId));
}

function getBusByNumber(conn, busNumber) {
  return one(conn.prepare(`SELECT ${BUS_COLS} FROM bus WHERE bus_number = ?`).get(busNumber));
}

function busSummary(conn) {
  return conn
    .prepare(
      `SELECT
         b.id,
         b.bus_number,
         b.number_plate,
         b.route_name,
         b.driver_name,
         b.departure_status,
         b.starting_location,
         COUNT(s.id) AS assigned,
         COALESCE(SUM(CASE WHEN s.is_present = 1                                          THEN 1 ELSE 0 END), 0) AS present,
         COALESCE(SUM(CASE WHEN s.is_present = 1 AND s.boarding_status = 'Boarded'        THEN 1 ELSE 0 END), 0) AS boarded,
         COALESCE(SUM(CASE WHEN s.is_present = 1 AND s.boarding_status != 'Boarded'       THEN 1 ELSE 0 END), 0) AS not_boarded,
         COALESCE(SUM(CASE WHEN s.is_present = 0                                          THEN 1 ELSE 0 END), 0) AS absent
       FROM bus b
       LEFT JOIN student s ON s.bus_id = b.id
       GROUP BY b.id, b.bus_number, b.number_plate, b.route_name, b.driver_name, b.departure_status, b.starting_location
       ORDER BY b.id`
    )
    .all();
}

function busOverviewTotals(conn) {
  return one(
    conn
      .prepare(
        `SELECT
           (SELECT COUNT(*) FROM bus) AS total_buses,
           (SELECT COUNT(*) FROM bus WHERE departure_status != 'Not Departed') AS active,
           (SELECT COUNT(*) FROM student WHERE bus_id IS NOT NULL) AS assigned,
           (SELECT COUNT(*) FROM student WHERE bus_id IS NOT NULL AND is_present = 1) AS present,
           (SELECT COUNT(*) FROM student WHERE bus_id IS NOT NULL AND is_present = 1
                                          AND boarding_status = 'Boarded') AS boarded,
           (SELECT COUNT(*) FROM student WHERE bus_id IS NOT NULL AND is_present = 1
                                          AND boarding_status != 'Boarded') AS not_boarded,
           (SELECT COUNT(*) FROM student WHERE bus_id IS NOT NULL AND is_present = 0) AS absent`
      )
      .get()
  );
}

function studentsForBus(conn, busId) {
  return conn
    .prepare(
      `SELECT ${STUDENT_COLS}
       FROM student s
       JOIN school_class c ON s.class_id = c.id
       LEFT JOIN bus b ON s.bus_id = b.id
       WHERE s.bus_id = ?
       ORDER BY s.id`
    )
    .all(busId);
}

// ---------- student ----------

function allStudents(conn) {
  return conn
    .prepare(
      `SELECT ${STUDENT_COLS}
       FROM student s
       JOIN school_class c ON s.class_id = c.id
       LEFT JOIN bus b ON s.bus_id = b.id
       ORDER BY s.id`
    )
    .all();
}

function getStudent(conn, studentId) {
  return one(
    conn
      .prepare(
        `SELECT ${STUDENT_COLS}
         FROM student s
         JOIN school_class c ON s.class_id = c.id
         LEFT JOIN bus b ON s.bus_id = b.id
         WHERE s.id = ?`
      )
      .get(studentId)
  );
}

function studentRoster(conn, busOnly = false) {
  let sql = "SELECT id, name, spr_number AS spr_no FROM student";
  if (busOnly) sql += " WHERE bus_id IS NOT NULL";
  sql += " ORDER BY id";
  return conn.prepare(sql).all();
}

function classSummary(conn) {
  return conn
    .prepare(
      `SELECT
         c.id,
         c.class_id AS name,
         c.teacher,
         COUNT(s.id) AS total,
         COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL                                            THEN 1 ELSE 0 END), 0) AS bus_users,
         COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1                       THEN 1 ELSE 0 END), 0) AS present,
         COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1
                            AND s.boarding_status = 'Boarded'                                   THEN 1 ELSE 0 END), 0) AS boarded,
         COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1
                            AND s.boarding_status != 'Boarded'                                  THEN 1 ELSE 0 END), 0) AS not_boarded,
         COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 0                       THEN 1 ELSE 0 END), 0) AS absent
       FROM school_class c
       LEFT JOIN student s ON s.class_id = c.id
       GROUP BY c.id, c.class_id, c.teacher
       ORDER BY c.id`
    )
    .all();
}

function classOverviewTotals(conn) {
  return one(
    conn
      .prepare(
        `SELECT
           COUNT(s.id) AS total,
           COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL                                            THEN 1 ELSE 0 END), 0) AS bus_users,
           COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1                       THEN 1 ELSE 0 END), 0) AS present,
           COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1
                              AND s.boarding_status = 'Boarded'                                   THEN 1 ELSE 0 END), 0) AS boarded,
           COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1
                              AND s.boarding_status != 'Boarded'                                  THEN 1 ELSE 0 END), 0) AS not_boarded,
           COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 0                       THEN 1 ELSE 0 END), 0) AS absent
         FROM student s`
      )
      .get()
  );
}

function absentStudentsToday(conn) {
  return conn
    .prepare(
      `SELECT s.id, s.name, s.section,
              c.class_id   AS class_name,
              b.bus_number AS bus_number
       FROM student s
       JOIN school_class c ON s.class_id = c.id
       LEFT JOIN bus b ON s.bus_id = b.id
       WHERE s.is_present = 0
       ORDER BY c.id, s.name`
    )
    .all();
}

function getClass(conn, classId) {
  return one(
    conn
      .prepare("SELECT id, class_id AS name, teacher FROM school_class WHERE id = ?")
      .get(classId)
  );
}

function studentsForClass(conn, classId) {
  return conn
    .prepare(
      `SELECT ${STUDENT_COLS}
       FROM student s
       JOIN school_class c ON s.class_id = c.id
       LEFT JOIN bus b ON s.bus_id = b.id
       WHERE s.class_id = ?
       ORDER BY s.id`
    )
    .all(classId);
}

// ---------- alerts ----------

function allAlerts(conn) {
  return conn
    .prepare(
      `SELECT a.id,
              a.message     AS title,
              a.description AS description,
              a.severity    AS severity,
              a.timestamp   AS timestamp,
              CASE
                WHEN b.bus_number IS NULL AND b.route_name IS NULL THEN ''
                ELSE b.bus_number || ' — ' || b.route_name
              END AS context
       FROM alert a
       LEFT JOIN bus b ON a.bus_id = b.id
       ORDER BY a.timestamp DESC`
    )
    .all();
}

// ---------- live stats ----------

function liveStats(conn) {
  return one(
    conn
      .prepare(
        `SELECT
           (SELECT COUNT(*) FROM bus     WHERE departure_status != 'Not Departed') AS active_buses,
           (SELECT COUNT(*) FROM student WHERE boarding_status   = 'Boarded')      AS boarded,
           (SELECT COUNT(*) FROM student WHERE boarding_status   = 'Not Boarded')  AS absent`
      )
      .get()
  );
}

// ---------- school ----------

function getSchool(conn) {
  return one(conn.prepare("SELECT id, name, lat, lng FROM school LIMIT 1").get());
}

// ---------- auth ----------

function findAdminUser(conn, username, password) {
  if (!username || password === null || password === undefined) return null;
  return one(
    conn
      .prepare(
        `SELECT id, username, password, full_name, bus_id
         FROM admin_user
         WHERE username = ? AND password = ?`
      )
      .get(username, password)
  );
}

function findStudentBySprDob(conn, sprNumber, dob) {
  if (!sprNumber || !dob) return null;
  return one(
    conn
      .prepare(
        `SELECT ${STUDENT_COLS}
         FROM student s
         JOIN school_class c ON s.class_id = c.id
         LEFT JOIN bus b ON s.bus_id = b.id
         WHERE s.spr_number = ? AND s.dob = ?`
      )
      .get(sprNumber, dob)
  );
}

// ---------- tracking (ESP32) ----------

function insertTrackingData(conn, busNumber, latitude, longitude, speed = null, eta = null) {
  conn
    .prepare(
      `INSERT INTO tracking_data (bus_number, lat, long, speed, eta)
       VALUES (?, ?, ?, ?, ?)`
    )
    .run(busNumber, latitude, longitude, speed, eta);
}

function insertStudentEntry(conn, busNumber, cardUid = null, sprno = null, status = null) {
  conn
    .prepare(
      `INSERT INTO student_entry (bus_number, card_uid, sprno, status)
       VALUES (?, ?, ?, ?)`
    )
    .run(busNumber, cardUid, sprno, status);
}

function updateBusLocation(conn, busNumber, latitude, longitude) {
  conn
    .prepare(
      `UPDATE bus SET current_lat = ?, current_lng = ? WHERE bus_number = ?`
    )
    .run(latitude, longitude, busNumber);
}

function getLatestTracking(conn, busNumber) {
  return one(
    conn
      .prepare(
        `SELECT bus_number, lat, long, speed, eta, timestamp
         FROM tracking_data
         WHERE bus_number = ?
         ORDER BY timestamp DESC
         LIMIT 1`
      )
      .get(busNumber)
  );
}

function getAllBusPoints(conn) {
  return conn
    .prepare("SELECT id, stop_name, latitude, longitude FROM bus_points ORDER BY id")
    .all();
}

// ---------- route tracking history ----------

function insertRouteSession(conn, busNumber, studentId = null) {
  const info = conn
    .prepare(
      `INSERT INTO bus_route_sessions (bus_number, student_id, started_at, created_at)
       VALUES (?, ?, datetime('now'), datetime('now'))`
    )
    .run(busNumber, studentId);
  return info.lastInsertRowid ? Number(info.lastInsertRowid) : null;
}

function endRouteSession(conn, sessionId) {
  conn
    .prepare("UPDATE bus_route_sessions SET ended_at = datetime('now') WHERE session_id = ?")
    .run(sessionId);
}

function getNextRoutePointSeq(conn, sessionId) {
  const row = one(
    conn
      .prepare(
        "SELECT COALESCE(MAX(point_seq), 0) + 1 AS next_seq FROM bus_route_points WHERE session_id = ?"
      )
      .get(sessionId)
  );
  return row ? row.next_seq : 1;
}

function insertRoutePoint(conn, sessionId, pointSeq, lat, lng) {
  conn
    .prepare(
      `INSERT INTO bus_route_points (session_id, point_seq, lat, lng, captured_at)
       VALUES (?, ?, ?, ?, datetime('now'))`
    )
    .run(sessionId, pointSeq, lat, lng);
}

function getLastRouteSession(conn, busNumber) {
  return one(
    conn
      .prepare(
        `SELECT session_id, bus_number, student_id, started_at, ended_at
         FROM bus_route_sessions
         WHERE bus_number = ?
         ORDER BY started_at DESC
         LIMIT 1`
      )
      .get(busNumber)
  );
}

function getAvailableRouteSessions(conn, busNumber) {
  return conn
    .prepare(
      `SELECT DISTINCT
              s.session_id,
              s.bus_number,
              s.student_id,
              s.started_at,
              s.ended_at
       FROM bus_route_sessions s
       INNER JOIN bus_route_points p ON p.session_id = s.session_id
       WHERE s.bus_number = ?
       ORDER BY s.started_at DESC, s.session_id DESC`
    )
    .all(busNumber);
}

function getRouteSession(conn, sessionId) {
  return one(
    conn
      .prepare(
        `SELECT session_id, bus_number, student_id, started_at, ended_at
         FROM bus_route_sessions
         WHERE session_id = ?`
      )
      .get(sessionId)
  );
}

function getRoutePoints(conn, sessionId) {
  return conn
    .prepare(
      `SELECT point_seq, lat, lng, captured_at
       FROM bus_route_points
       WHERE session_id = ?
       ORDER BY point_seq`
    )
    .all(sessionId);
}

module.exports = {
  allBuses,
  getBus,
  getBusByNumber,
  busSummary,
  busOverviewTotals,
  studentsForBus,
  allStudents,
  getStudent,
  studentRoster,
  classSummary,
  classOverviewTotals,
  absentStudentsToday,
  getClass,
  studentsForClass,
  allAlerts,
  liveStats,
  getSchool,
  findAdminUser,
  findStudentBySprDob,
  insertTrackingData,
  insertStudentEntry,
  updateBusLocation,
  getLatestTracking,
  getAllBusPoints,
  insertRouteSession,
  endRouteSession,
  getNextRoutePointSeq,
  insertRoutePoint,
  getLastRouteSession,
  getAvailableRouteSessions,
  getRouteSession,
  getRoutePoints,
};
