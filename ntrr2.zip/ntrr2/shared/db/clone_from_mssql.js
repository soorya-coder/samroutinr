"use strict";
/*
=====================================================================
CLONE MSSQL  ->  SQLite
=====================================================================
Reads every table from the live MSSQL database (the one the Python project
used) and copies the rows into the local SQLite file `shared/db/transport.db`.
After this runs, the Node apps read the real production data instead of the
seeded dummy data.

---------------------------------------------------------------------
HOW TO RUN
---------------------------------------------------------------------
1. Prerequisites (one time):
       npm install                 # installs the `mssql` driver (pure JS)
       # You must have network access to the MSSQL host (default port 1433).
       # If the host is unreachable this script fails at the connect step;
       # use `npm run seed` for the offline dummy-data fallback instead.

2. Run the clone (from the project root, C:\...\ntrr):
       npm run clone
   or directly:
       node shared/db/clone_from_mssql.js

3. (Optional) point it at a different server / DB / output file by setting
   environment variables before the command.

   Windows PowerShell:
       $env:MSSQL_SERVER="103.207.1.84"; $env:MSSQL_DATABASE="transport";
       $env:MSSQL_UID="transport"; $env:MSSQL_PWD="claude@3908";
       npm run clone

   Windows cmd.exe:
       set MSSQL_SERVER=103.207.1.84&& set MSSQL_PWD=claude@3908&& npm run clone

   Linux / macOS / Git Bash:
       MSSQL_SERVER=103.207.1.84 MSSQL_PWD='claude@3908' npm run clone

4. Start the apps as usual — they now serve the cloned data:
       npm start            # admin :4013  +  student :4014

   To go back to the dummy data later, just re-run:  npm run seed

---------------------------------------------------------------------
CONNECTION SETTINGS  (env var -> default, same as Python connection.py)
---------------------------------------------------------------------
    MSSQL_SERVER    103.207.1.84
    MSSQL_DATABASE  transport
    MSSQL_UID       transport
    MSSQL_PWD       claude@3908
    MSSQL_PORT      1433
    SQLITE_PATH     shared/db/transport.db   (the SQLite file that gets written)

---------------------------------------------------------------------
WHAT IT DOES  (and important notes)
---------------------------------------------------------------------
  1. DROPS and recreates the SQLite schema from schema.js (DROP_SQL + SCHEMA_SQL).
     => This OVERWRITES everything currently in transport.db. Back it up first
        if you care about the existing contents.
  2. For each table that exists in MSSQL: SELECT * and bulk-insert into SQLite
     inside a single transaction (rolls back that table on any error).
  3. Maps columns case-insensitively, with the one known quirk handled:
     `school.long` (MSSQL) -> `school.lng` (SQLite).
  4. Copies primary-key ids verbatim so foreign-key relationships are preserved.
  5. Coerces types for SQLite: DATETIME -> 'YYYY-MM-DD HH:MM:SS' text,
     BIT -> 0/1, undefined/null -> NULL.
  6. Tables missing in MSSQL (e.g. the route-session tables, if never created
     there) are logged and skipped — they are not treated as errors.
=====================================================================
*/
const sql = require("mssql");
const { getConnection } = require("./connection");
const { SCHEMA_SQL, DROP_SQL } = require("./schema");

// Parent tables first so referential order is natural (FKs are not enforced in
// SQLite by default, but this keeps the copy tidy).
const TABLES = [
  "school",
  "school_class",
  "bus",
  "student",
  "admin_user",
  "alert",
  "tracking_data",
  "student_entry",
  "bus_points",
  "TEST",
  "bus_route_sessions",
  "bus_route_points",
];

const mssqlConfig = {
  server: process.env.MSSQL_SERVER || "103.207.1.84",
  database: process.env.MSSQL_DATABASE || "transport",
  user: process.env.MSSQL_UID || "transport",
  password: process.env.MSSQL_PWD || "claude@3908",
  port: parseInt(process.env.MSSQL_PORT || "1433", 10),
  options: {
    encrypt: true,
    trustServerCertificate: true,
    enableArithAbort: true,
  },
  connectionTimeout: 30000,
  requestTimeout: 120000,
};

function pad2(n) {
  return String(n).padStart(2, "0");
}

// MSSQL DATETIME -> 'YYYY-MM-DD HH:MM:SS' (UTC) for SQLite TEXT storage.
function formatDate(d) {
  return (
    `${d.getUTCFullYear()}-${pad2(d.getUTCMonth() + 1)}-${pad2(d.getUTCDate())} ` +
    `${pad2(d.getUTCHours())}:${pad2(d.getUTCMinutes())}:${pad2(d.getUTCSeconds())}`
  );
}

function coerce(v) {
  if (v === undefined || v === null) return null;
  if (v instanceof Date) return formatDate(v);
  if (typeof v === "boolean") return v ? 1 : 0;
  if (Buffer.isBuffer(v)) return v;
  if (typeof v === "number" || typeof v === "string" || typeof v === "bigint") return v;
  return String(v);
}

// Pair each SQLite column with its source column in the MSSQL recordset.
function buildMapping(mssqlCols, sqliteCols) {
  const byLower = {};
  for (const m of mssqlCols) byLower[m.toLowerCase()] = m;

  const mapping = [];
  for (const sc of sqliteCols) {
    let src = byLower[sc.toLowerCase()];
    if (!src && sc.toLowerCase() === "lng") {
      src = byLower["long"] || byLower["longitude"]; // school.long -> lng
    }
    if (src) mapping.push({ sqliteCol: sc, mssqlCol: src });
  }
  return mapping;
}

async function mssqlTableExists(pool, table) {
  const r = await pool
    .request()
    .input("t", sql.NVarChar, table)
    .query(
      "SELECT 1 AS ok FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = @t AND TABLE_SCHEMA = 'dbo'"
    );
  return r.recordset.length > 0;
}

async function main() {
  console.log("Connecting to MSSQL %s/%s ...", mssqlConfig.server, mssqlConfig.database);
  const pool = await sql.connect(mssqlConfig);
  console.log("Connected.\n");

  const lite = getConnection();
  console.log("Rebuilding SQLite schema ...");
  lite.exec(DROP_SQL);
  lite.exec(SCHEMA_SQL);

  const summary = [];

  for (const table of TABLES) {
    if (!(await mssqlTableExists(pool, table))) {
      console.log(`- ${table}: not found in MSSQL, skipped`);
      summary.push([table, "skipped"]);
      continue;
    }

    const result = await pool.request().query(`SELECT * FROM dbo.[${table}]`);
    const rows = result.recordset;

    // SQLite columns for this table.
    const sqliteCols = lite
      .prepare(`PRAGMA table_info(${table})`)
      .all()
      .map((c) => c.name);

    // MSSQL columns (from the result metadata, robust even for an empty table).
    const mssqlCols = Object.keys(result.recordset.columns || {});
    const sourceCols = mssqlCols.length
      ? mssqlCols
      : rows.length
      ? Object.keys(rows[0])
      : [];

    const mapping = buildMapping(sourceCols, sqliteCols);
    if (!mapping.length) {
      console.log(`- ${table}: no overlapping columns, skipped`);
      summary.push([table, "no columns"]);
      continue;
    }

    const cols = mapping.map((m) => m.sqliteCol);
    const placeholders = cols.map(() => "?").join(", ");
    const insert = lite.prepare(
      `INSERT INTO ${table} (${cols.join(", ")}) VALUES (${placeholders})`
    );

    lite.exec("BEGIN");
    try {
      for (const row of rows) {
        const values = mapping.map((m) => coerce(row[m.mssqlCol]));
        insert.run(...values);
      }
      lite.exec("COMMIT");
    } catch (e) {
      lite.exec("ROLLBACK");
      throw new Error(`Failed copying table '${table}': ${e.message}`);
    }

    console.log(`- ${table}: ${rows.length} rows`);
    summary.push([table, `${rows.length} rows`]);
  }

  await pool.close();

  console.log("\n=== Clone complete ===");
  for (const [t, info] of summary) {
    console.log(`  ${t.padEnd(22)} ${info}`);
  }
  console.log("\nSQLite file: " + (process.env.SQLITE_PATH || "shared/db/transport.db"));
}

main().catch((err) => {
  console.error("\nClone failed:", err.message || err);
  process.exit(1);
});
