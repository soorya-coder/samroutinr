"use strict";
// Drop, recreate, and seed the SQLite DB from shared/data/dummyData.js.
// Run with:  node shared/db/seed.js   (or: npm run seed)
const { getConnection } = require("./connection");
const { SCHEMA_SQL, DROP_SQL } = require("./schema");
const dd = require("../data/dummyData");

function seed() {
  const conn = getConnection();

  conn.exec(DROP_SQL);
  conn.exec(SCHEMA_SQL);

  // School
  conn
    .prepare("INSERT INTO school (name, lat, lng) VALUES (?, ?, ?)")
    .run(dd.SCHOOL.name, dd.SCHOOL.lat, dd.SCHOOL.lng);

  // Classes — preserve string id ("5A") -> int pk mapping for students
  const classIdMap = {};
  const insClass = conn.prepare(
    "INSERT INTO school_class (class_id, teacher) VALUES (?, ?)"
  );
  for (const c of dd.CLASSES) {
    const info = insClass.run(c.name, c.teacher ?? null);
    classIdMap[c.id] = Number(info.lastInsertRowid);
  }

  // Buses — keep dummy ids aligned with PKs
  const busByNumber = {};
  const insBus = conn.prepare(
    `INSERT INTO bus
       (id, bus_number, number_plate, route_name, starting_location,
        current_lat, current_lng, departure_status, driver_name)
       VALUES (?,?,?,?,?,?,?,?,?)`
  );
  for (const b of dd.BUSES) {
    insBus.run(
      b.id, b.number, b.plate, b.route, b.start_location,
      b.lat, b.lng, b.status, b.driver
    );
    busByNumber[b.number] = b.id;
  }

  // Students
  const insStudent = conn.prepare(
    `INSERT INTO student
       (id, name, spr_number, class_id, bus_id, gender, boarding_status,
        pickup_lat, pickup_lng, fees_balance, fees_status,
        is_present, section, dob)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
  );
  for (const s of dd.STUDENTS) {
    insStudent.run(
      s.id, s.name, s.spr_no, classIdMap[s.class_id],
      s.bus_id ?? null, s.gender, s.boarding_status,
      s.pickup_lat, s.pickup_lng,
      Number(s.fees_balance || 0),
      s.fees_status || "Paid",
      s.is_present === undefined ? 1 : (s.is_present ? 1 : 0),
      s.section || "A",
      s.dob ?? null
    );
  }

  // Driver login accounts
  const insAdmin = conn.prepare(
    "INSERT INTO admin_user (username, password, full_name, bus_id) VALUES (?,?,?,?)"
  );
  for (const d of dd.ADMIN_USERS) {
    insAdmin.run(d.username, d.password, d.full_name, d.bus_id);
  }

  // Alerts — backfill bus_id from "Bus N" in the original context string
  const insAlert = conn.prepare(
    `INSERT INTO alert
       (id, message, description, severity, timestamp, bus_id, student_id)
       VALUES (?,?,?,?,?,?,?)`
  );
  for (const a of dd.ALERTS) {
    const ctx = a.context || "";
    const m = ctx.match(/(Bus\s+\d+)/);
    const busPk = m ? (busByNumber[m[1]] ?? null) : null;
    insAlert.run(
      a.id, a.title ?? null, a.description ?? null, a.severity,
      a.timestamp, busPk, null
    );
  }

  // Bus Points (stops)
  const insPoint = conn.prepare(
    "INSERT INTO bus_points (stop_name, latitude, longitude) VALUES (?,?,?)"
  );
  for (const p of dd.BUS_POINTS) {
    insPoint.run(p.stop_name, p.lat, p.lng);
  }

  const tables = ["bus", "student", "school_class", "alert", "school", "admin_user", "bus_points"];
  const counts = {};
  for (const t of tables) {
    counts[t] = conn.prepare(`SELECT COUNT(*) AS c FROM ${t}`).get().c;
  }
  console.log(
    `Seeded ${counts.bus} buses, ${counts.student} students, ` +
      `${counts.school_class} classes, ${counts.alert} alerts, ` +
      `${counts.school} school, ${counts.admin_user} admin users, ` +
      `${counts.bus_points} bus points.`
  );
}

module.exports = { seed };

if (require.main === module) {
  seed();
}
