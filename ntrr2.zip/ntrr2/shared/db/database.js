"use strict";
// Session helpers + lifecycle. Connection details live in connection.js.
const { getConnection, dbExists } = require("./connection");
const { SCHEMA_SQL, REQUIRED_TABLES } = require("./schema");

/**
 * Yield the shared connection. Mirrors the Python `get_db()` context manager;
 * with SQLite the connection is a long-lived singleton, so there is nothing to
 * close per request.
 */
function getDb() {
  return getConnection();
}

function initDb() {
  // Create tables if they don't exist (no data).
  const conn = getConnection();
  conn.exec(SCHEMA_SQL);
}

function tableExists(conn, tableName) {
  const row = conn
    .prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name = ?")
    .get(tableName);
  return row !== undefined && row !== null;
}

/** Ensure all required tables exist. Create missing tables + seed on startup. */
function ensureDbReady() {
  if (!dbExists()) {
    const { seed } = require("./seed");
    seed();
    return;
  }

  const conn = getConnection();
  const missing = REQUIRED_TABLES.filter((t) => !tableExists(conn, t));
  if (missing.length) {
    console.log(`⚠️  Missing tables detected: ${missing.join(", ")}`);
    console.log("📋 Creating missing tables from schema...");
    conn.exec(SCHEMA_SQL);
    console.log("✅ Tables created successfully!");
  }

  if (tableExists(conn, "school")) {
    const { c } = conn.prepare("SELECT COUNT(*) AS c FROM school").get();
    if (c === 0) {
      const { seed } = require("./seed");
      seed();
    }
  } else {
    const { seed } = require("./seed");
    seed();
  }
}

module.exports = { getDb, initDb, ensureDbReady, tableExists };
