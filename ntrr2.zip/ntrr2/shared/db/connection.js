"use strict";
/*
=====================================================================
DATABASE CONNECTION — single editable file
=====================================================================
This is the ONLY file you need to edit to change the database backend.

Current backend: SQLite (Node's built-in `node:sqlite`).

The original Python project targeted MSSQL (pyodbc). This Node.js port uses a
local SQLite database file seeded from `shared/data/dummy_data.json`, so it runs
with no external database server. The data and schema mirror the original.

Database file: shared/db/transport.db  (override with env SQLITE_PATH)
=====================================================================
*/
const path = require("path");
const fs = require("fs");
const { DatabaseSync } = require("node:sqlite");

const DB_PATH = process.env.SQLITE_PATH || path.join(__dirname, "transport.db");

// Display labels (mirror the MSSQL banner the Python apps printed on boot).
const DB_BACKEND = "SQLite";
const DB_FILE = DB_PATH;

let _conn = null;

/** Return the shared SQLite connection (opened lazily). */
function getConnection() {
  if (!_conn) {
    _conn = new DatabaseSync(DB_PATH);
  }
  return _conn;
}

/** True if the database file exists and contains the seeded `school` table with data. */
function dbExists() {
  try {
    if (!fs.existsSync(DB_PATH)) return false;
    const conn = getConnection();
    const row = conn
      .prepare(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='school'"
      )
      .get();
    if (!row) return false;
    const count = conn.prepare("SELECT COUNT(*) AS c FROM school").get();
    return count && count.c > 0;
  } catch (e) {
    return false;
  }
}

module.exports = { DB_PATH, DB_BACKEND, DB_FILE, getConnection, dbExists };
