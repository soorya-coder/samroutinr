"use strict";
// Mock data shared by admin_app and student_app.
// The dataset is captured verbatim from the original Python `shared/data/dummy_data.py`
// (random.Random(42) output) so the seeded database is byte-for-byte identical.
const fs = require("fs");
const path = require("path");

const raw = fs.readFileSync(path.join(__dirname, "dummy_data.json"), "utf-8");
const data = JSON.parse(raw);

module.exports = {
  SCHOOL: data.SCHOOL,
  CLASSES: data.CLASSES,
  BUSES: data.BUSES,
  BUS_POINTS: data.BUS_POINTS,
  STUDENTS: data.STUDENTS,
  ADMIN_USERS: data.ADMIN_USERS,
  ALERTS: data.ALERTS,
};
