"use strict";
// Nunjucks filter installation + date helpers shared by both apps.
// Nunjucks is Jinja2-compatible enough that the original templates render almost
// verbatim; these filters fill the few Python-specific gaps (printf `format`,
// thousands grouping, `title`).

const WEEKDAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const MONTHS = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"];
const MONTHS_ABBR = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function pad2(n) {
  return String(n).padStart(2, "0");
}

// Python: date.today().strftime("%A, %d %B %Y")  ->  "Sunday, 21 June 2026"
function formatToday(d = new Date()) {
  return `${WEEKDAYS[d.getDay()]}, ${pad2(d.getDate())} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

// Python: date.today().strftime("%d %b").upper()  ->  "21 JUN"
function todayShort(d = new Date()) {
  return `${pad2(d.getDate())} ${MONTHS_ABBR[d.getMonth()]}`.toUpperCase();
}

// Minimal printf supporting the patterns used in templates (e.g. "%.4f").
function sprintf(fmt, ...args) {
  let i = 0;
  return String(fmt).replace(
    /%([-+ 0]*)(\d+)?(?:\.(\d+))?([dfsx%])/g,
    (match, flags, width, precision, type) => {
      if (type === "%") return "%";
      let value = args[i++];
      let out;
      if (type === "d") {
        out = String(Math.trunc(Number(value)));
      } else if (type === "f") {
        const p = precision !== undefined ? parseInt(precision, 10) : 6;
        out = Number(value).toFixed(p);
      } else if (type === "x") {
        out = Math.trunc(Number(value)).toString(16);
      } else {
        out = String(value);
        if (precision !== undefined) out = out.slice(0, parseInt(precision, 10));
      }
      if (width) {
        const w = parseInt(width, 10);
        const padChar = flags.includes("0") && type !== "s" ? "0" : " ";
        if (flags.includes("-")) out = out.padEnd(w, " ");
        else out = out.padStart(w, padChar);
      }
      return out;
    }
  );
}

// Python: "{:,}".format(value) on a float -> grouped digits with at least ".0".
function intcomma(value) {
  const num = Number(value);
  if (Number.isNaN(num)) return String(value);
  if (Number.isInteger(num)) {
    return num.toLocaleString("en-US") + ".0";
  }
  const [intPart, fracPart] = String(num).split(".");
  return Number(intPart).toLocaleString("en-US") + "." + fracPart;
}

function titleCase(value) {
  return String(value).replace(/\w\S*/g, (w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
}

function installFilters(env) {
  // Jinja's `format` filter: "%.4f"|format(x)  -> sprintf applied to the string.
  env.addFilter("format", (fmt, ...args) => sprintf(fmt, ...args));
  env.addFilter("intcomma", intcomma);
  env.addFilter("title", titleCase);
  return env;
}

module.exports = { formatToday, todayShort, sprintf, intcomma, titleCase, installFilters };
