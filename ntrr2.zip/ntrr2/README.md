# Mount Zion Schools — Transport Tracker (Node.js)

Node.js / Express port of the Python (Flask) `ttr2` project. Behaviour, routes,
templates and dummy data are kept the same; the only intentional change is the
**database backend: SQLite instead of MSSQL**, seeded from the original dummy
data so the app runs with no external database server.

There are **two independent apps** (matching the two original Flask apps):

| App        | Folder        | Port | What it is                                            |
|------------|---------------|------|-------------------------------------------------------|
| Admin/Driver | `admin_app/` | 4013 | Live map, Bus fleet, Classes, Alerts, report exports, `/tracking` ESP32 ingest |
| Student      | `student_app/` | 4014 | Student dashboard with live bus map, distance/ETA, route history |

Both apps share the same code under `shared/` and the same SQLite database file
(`shared/db/transport.db`).

## Requirements

- **Node.js ≥ 22.5** — uses the built-in `node:sqlite` module.
  (The original plan was `better-sqlite3`, but it needs a native compile and no
  Visual Studio build tools are present on this machine, so the port uses Node's
  built-in SQLite, which has the same synchronous `prepare().get()/.all()/.run()`
  API. Swapping back to `better-sqlite3` later only requires editing
  `shared/db/connection.js`.)

## Setup

```bash
npm install
npm run seed     # creates + seeds shared/db/transport.db from the dummy data
```

The database is also auto-created and seeded on first server start if missing.

## Run

```bash
npm run admin     # admin/driver app  -> http://localhost:4013
npm run student   # student app       -> http://localhost:4014
npm start         # run both together (via concurrently)
```

## Demo credentials

- **Driver/Admin:** username `driver1` … `driver8`, password `pass123`
- **Student:** sign in with a student's SPR number + date of birth. Look one up:
  ```bash
  node -e "const c=require('./shared/db/connection').getConnection(); console.log(c.prepare('SELECT spr_number,dob,name FROM student LIMIT 5').all())"
  ```

## Project layout

```
shared/
  data/dummy_data.json   # dummy dataset captured verbatim from the Python module
  data/dummyData.js      # loads the JSON
  db/connection.js       # SQLite connection (the one file to edit to change backend)
  db/schema.js           # SQLite DDL
  db/seed.js             # drop/create/seed   (npm run seed)
  db/database.js         # getDb() + ensureDbReady()
  db/queries.js          # all SQL queries (ported from queries.py)
  geo.js                 # haversine / ETA / nearest-stop helpers
  web/templating.js      # Nunjucks filters + date formatting (Jinja2 parity)
admin_app/
  server.js  config.js  lib/urlFor.js
  modules/{live,bus,classes,alerts}/routes.js
  modules/reports/generator.js   # PDF (pdfkit) + Excel (exceljs) exports
  templates/  static/
student_app/
  server.js  config.js  lib/urlFor.js
  modules/dashboard/routes.js
  templates/  static/
```

## Notes on the port

- **Flask blueprints → Express routers**, mounted under the same URL prefixes.
- **Jinja2 templates → Nunjucks**, rendered nearly verbatim. A `url_for` global
  and `format`/`intcomma`/`title` filters fill the Python-specific gaps.
- **MSSQL SQL → SQLite SQL**: `TOP n`→`LIMIT n`, `CONCAT`→`||`,
  `GETDATE()`→`datetime('now')`, `@@IDENTITY`→`last_insert_rowid()`.
- `bus_route_sessions` / `bus_route_points` are now defined in the schema (the
  Python code referenced them but created them out-of-band in the live DB).
