"use strict";
// Admin (driver) app config — edit PORT to change the listening port.
module.exports = {
  SCHOOL_NAME: "Mount Zion Schools",
  PORT: 4013,
  HOST: "0.0.0.0",
  // Session signing key. Change in production.
  SECRET_KEY: "dev-only-not-secret-change-me",
  DEBUG: true,
};
