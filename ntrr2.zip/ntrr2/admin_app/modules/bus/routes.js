"use strict";
const express = require("express");
const { getDb } = require("../../../shared/db/database");
const q = require("../../../shared/db/queries");
const { buildReport } = require("../reports/generator");
const { urlFor } = require("../../lib/urlFor");

const router = express.Router();

router.get("/", (req, res) => {
  const conn = getDb();
  const buses = q.allBuses(conn);
  const busStats = q.busSummary(conn);
  const busOverview = q.busOverviewTotals(conn);
  res.render("bus/list.html", {
    buses,
    bus_stats: busStats,
    bus_overview: busOverview,
    active_tab: "bus",
    report_url: urlFor("bus.report"),
  });
});

router.get("/report", (req, res) => {
  const fmt = req.query.fmt || "pdf";
  const conn = getDb();
  const busStats = q.busSummary(conn);
  const busOverview = q.busOverviewTotals(conn);
  const headers = ["Bus No.", "Plate", "Start Location", "Route", "Admin", "Status",
    "Assigned", "Present", "Boarded", "Not Boarded", "Absent"];
  const rows = busStats.map((b) => [
    b.bus_number, b.number_plate, b.starting_location, b.route_name,
    b.driver_name, b.departure_status,
    b.assigned, b.present, b.boarded, b.not_boarded, b.absent,
  ]);
  rows.push(["ALL BUSES", "", "", "", "", "",
    busOverview.assigned, busOverview.present,
    busOverview.boarded, busOverview.not_boarded, busOverview.absent]);
  return buildReport(res, "Bus Day Wise Report", headers, rows, fmt);
});

router.get("/:bus_id/report", (req, res) => {
  const fmt = req.query.fmt || "pdf";
  const busId = parseInt(req.params.bus_id, 10);
  const conn = getDb();
  const bus = q.getBus(conn, busId);
  if (!bus) return res.status(404).send("Not Found");
  const students = q.studentsForBus(conn, busId);
  const headers = ["Student Name", "SPR No", "Class", "Gender", "Boarding Status"];
  const rows = students.map((s) => [s.name, s.spr_no, s.class_name, s.gender, s.boarding_status]);
  return buildReport(res, `${bus.number} Student Report`, headers, rows, fmt);
});

router.get("/:bus_id", (req, res) => {
  const busId = parseInt(req.params.bus_id, 10);
  if (Number.isNaN(busId)) return res.status(404).send("Not Found");
  const conn = getDb();
  const bus = q.getBus(conn, busId);
  if (!bus) return res.status(404).send("Not Found");
  const students = q.studentsForBus(conn, busId);
  res.render("bus/detail.html", {
    bus,
    students,
    active_tab: "bus",
    report_url: urlFor("bus.detail_report", { bus_id: bus.id }),
  });
});

module.exports = router;
