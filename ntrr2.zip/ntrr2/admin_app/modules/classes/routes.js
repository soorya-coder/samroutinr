"use strict";
const express = require("express");
const { getDb } = require("../../../shared/db/database");
const q = require("../../../shared/db/queries");
const { buildReport } = require("../reports/generator");
const { urlFor } = require("../../lib/urlFor");
const { todayShort } = require("../../../shared/web/templating");

const router = express.Router();

router.get("/", (req, res) => {
  const conn = getDb();
  const classes = q.classSummary(conn);
  const overview = q.classOverviewTotals(conn);
  const absentees = q.absentStudentsToday(conn);
  res.render("classes.html", {
    classes,
    overview,
    absentees,
    today_short: todayShort(),
    active_tab: "classes",
    report_url: urlFor("classes.report"),
  });
});

router.get("/report", (req, res) => {
  const fmt = req.query.fmt || "pdf";
  const conn = getDb();
  const classes = q.classSummary(conn);
  const overview = q.classOverviewTotals(conn);
  const headers = ["Class", "Teacher", "Total", "Bus Users", "Present",
    "Boarded", "Not Boarded", "Absent"];
  const rows = classes.map((c) => [c.name, c.teacher, c.total, c.bus_users,
    c.present, c.boarded, c.not_boarded, c.absent]);
  rows.push(["ALL CLASSES", "", overview.total, overview.bus_users,
    overview.present, overview.boarded, overview.not_boarded, overview.absent]);
  return buildReport(res, "Class Day Wise Report", headers, rows, fmt);
});

router.get("/:class_id/report", (req, res) => {
  const fmt = req.query.fmt || "pdf";
  const classId = parseInt(req.params.class_id, 10);
  const conn = getDb();
  const cls = q.getClass(conn, classId);
  if (!cls) return res.status(404).send("Not Found");
  const students = q.studentsForClass(conn, classId);
  const headers = ["Student Name", "SPR No", "Section", "Gender", "Bus", "Boarding Status"];
  const rows = students.map((s) => [s.name, s.spr_no, s.section || "", s.gender,
    s.bus_number || "—", s.boarding_status]);
  return buildReport(res, `${cls.name} Report`, headers, rows, fmt);
});

router.get("/:class_id", (req, res) => {
  const classId = parseInt(req.params.class_id, 10);
  if (Number.isNaN(classId)) return res.status(404).send("Not Found");
  const conn = getDb();
  const cls = q.getClass(conn, classId);
  if (!cls) return res.status(404).send("Not Found");
  const students = q.studentsForClass(conn, classId);
  res.render("class_detail.html", {
    cls,
    students,
    active_tab: "classes",
    report_url: urlFor("classes.detail_report", { class_id: cls.id }),
  });
});

module.exports = router;
