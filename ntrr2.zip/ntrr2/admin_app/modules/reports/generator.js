"use strict";
// Shared PDF + Excel generators. Routes call buildReport(res, title, headers, rows, fmt).
// Ported from `admin_app/modules/reports/generator.py` (reportlab + openpyxl).
const PDFDocument = require("pdfkit");
const ExcelJS = require("exceljs");

async function excelReport(res, title, headers, rows) {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet((title || "Report").slice(0, 30) || "Report");

  const colCount = Math.max(headers.length, 1);

  // Title row (merged across all columns).
  ws.addRow([title]);
  ws.mergeCells(1, 1, 1, colCount);
  const titleCell = ws.getCell(1, 1);
  titleCell.font = { size: 16, bold: true, color: { argb: "FFFFFFFF" } };
  titleCell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1E40AF" } };
  titleCell.alignment = { horizontal: "center", vertical: "middle" };
  ws.getRow(1).height = 28;

  // Header row.
  ws.addRow(headers);
  headers.forEach((_, idx) => {
    const c = ws.getCell(2, idx + 1);
    c.font = { bold: true, color: { argb: "FF1F2937" } };
    c.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFF4EFE2" } };
    c.alignment = { horizontal: "left" };
  });

  // Data rows.
  for (const r of rows) {
    ws.addRow(r.map((x) => (x === null || x === undefined ? "" : String(x))));
  }

  // Column widths.
  for (let idx = 1; idx <= headers.length; idx++) {
    let maxLen = 12;
    ws.getColumn(idx).eachCell({ includeEmpty: false }, (cell, rowNumber) => {
      if (rowNumber < 2) return; // skip the merged title row
      const v = cell.value;
      if (v !== null && v !== undefined) {
        maxLen = Math.max(maxLen, String(v).length + 2);
      }
    });
    ws.getColumn(idx).width = Math.min(maxLen, 40);
  }

  const fileName = `${(title || "Report").replace(/ /g, "_")}.xlsx`;
  res.setHeader(
    "Content-Type",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  );
  res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
  await wb.xlsx.write(res);
  res.end();
}

function pdfReport(res, title, headers, rows) {
  const fileName = `${(title || "Report").replace(/ /g, "_")}.pdf`;
  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);

  const margin = 24;
  const doc = new PDFDocument({ size: "A4", layout: "landscape", margin });
  doc.pipe(res);

  // Title
  doc.font("Helvetica-Bold").fontSize(18).fillColor("#000000").text(title, { align: "left" });
  doc.moveDown(0.6);

  const data = [headers, ...rows.map((r) => r.map((x) => (x === null || x === undefined ? "" : String(x))))];
  if (!rows.length) {
    data.push(["No data", ...Array(Math.max(headers.length - 1, 0)).fill("")]);
  }

  const pageWidth = doc.page.width - margin * 2;
  const fontSize = 9;
  const cellPadX = 4;
  const cellPadY = 5;

  // Column widths proportional to longest cell per column, then scaled to fit.
  doc.font("Helvetica").fontSize(fontSize);
  const rawWidths = headers.map((_, col) => {
    let max = 0;
    for (const row of data) {
      const text = row[col] !== undefined ? String(row[col]) : "";
      max = Math.max(max, doc.widthOfString(text));
    }
    return max + cellPadX * 2;
  });
  const totalRaw = rawWidths.reduce((a, b) => a + b, 0) || 1;
  const colWidths = rawWidths.map((w) => (w / totalRaw) * pageWidth);

  const lineHeight = fontSize + 2;

  function rowHeight(row) {
    let maxLines = 1;
    row.forEach((cell, col) => {
      const text = cell !== undefined ? String(cell) : "";
      const w = colWidths[col] - cellPadX * 2;
      const h = doc.heightOfString(text, { width: w, lineGap: 0 });
      maxLines = Math.max(maxLines, Math.ceil(h / lineHeight));
    });
    return maxLines * lineHeight + cellPadY * 2;
  }

  function drawRow(row, y, { header = false, zebra = false } = {}) {
    const h = rowHeight(row);
    let x = margin;

    // Backgrounds
    if (header) {
      doc.save().rect(margin, y, pageWidth, h).fill("#1E40AF").restore();
    } else if (zebra) {
      doc.save().rect(margin, y, pageWidth, h).fill("#FCFAF5").restore();
    }

    // Cell text + vertical grid lines
    row.forEach((cell, col) => {
      const w = colWidths[col];
      doc
        .font(header ? "Helvetica-Bold" : "Helvetica")
        .fontSize(fontSize)
        .fillColor(header ? "#FFFFFF" : "#1F2937")
        .text(cell !== undefined ? String(cell) : "", x + cellPadX, y + cellPadY, {
          width: w - cellPadX * 2,
        });
      x += w;
    });

    // Grid (light)
    doc.save().lineWidth(0.25).strokeColor("#E4DDC6");
    doc.rect(margin, y, pageWidth, h).stroke();
    x = margin;
    for (let col = 0; col < colWidths.length - 1; col++) {
      x += colWidths[col];
      doc.moveTo(x, y).lineTo(x, y + h).stroke();
    }
    doc.restore();

    return h;
  }

  const bottomLimit = doc.page.height - margin;
  let y = doc.y;

  // Header row
  y += drawRow(data[0], y, { header: true });

  // Data rows
  for (let i = 1; i < data.length; i++) {
    const h = rowHeight(data[i]);
    if (y + h > bottomLimit) {
      doc.addPage();
      y = margin;
      y += drawRow(data[0], y, { header: true });
    }
    y += drawRow(data[i], y, { zebra: (i - 1) % 2 === 1 });
  }

  doc.end();
}

function buildReport(res, title, headers, rows, fmt) {
  fmt = (fmt || "pdf").toLowerCase();
  if (fmt === "excel" || fmt === "xlsx") {
    return excelReport(res, title, headers, rows);
  }
  return pdfReport(res, title, headers, rows);
}

module.exports = { buildReport };
