"use strict";
const express = require("express");
const { getDb } = require("../../../shared/db/database");
const q = require("../../../shared/db/queries");
const { buildReport } = require("../reports/generator");
const { urlFor } = require("../../lib/urlFor");
const { titleCase } = require("../../../shared/web/templating");

const router = express.Router();

// Mirror Python: datetime.strptime(ts, "%Y-%m-%d %H:%M").strftime("%I:%M %p").lstrip("0")
function shortTime(ts) {
  const m = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})$/.exec(String(ts || ""));
  if (!m) return ts;
  let hour = parseInt(m[4], 10);
  const minute = m[5];
  const ampm = hour >= 12 ? "PM" : "AM";
  let h12 = hour % 12;
  if (h12 === 0) h12 = 12;
  // "%I:%M %p" zero-pads hour, then lstrip("0") removes a leading zero.
  let out = `${String(h12).padStart(2, "0")}:${minute} ${ampm}`;
  return out.replace(/^0+/, "");
}

function decorate(alerts) {
  for (const a of alerts) a.timestamp_short = shortTime(a.timestamp);
  return alerts;
}

router.get("/", (req, res) => {
  const alerts = decorate(q.allAlerts(getDb()));
  res.render("alerts.html", {
    alerts,
    active_tab: "alerts",
    report_url: urlFor("alerts.report"),
  });
});

router.get("/report", (req, res) => {
  const fmt = req.query.fmt || "pdf";
  const alerts = q.allAlerts(getDb());
  const headers = ["Severity", "Title", "Description", "Context", "Timestamp"];
  const rows = alerts.map((a) => [titleCase(a.severity), a.title, a.description || "",
    a.context, a.timestamp]);
  return buildReport(res, "Alerts Day Wise Report", headers, rows, fmt);
});

module.exports = router;
