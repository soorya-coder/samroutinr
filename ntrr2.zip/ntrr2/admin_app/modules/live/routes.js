"use strict";
const express = require("express");
const { getDb } = require("../../../shared/db/database");
const q = require("../../../shared/db/queries");
const { buildReport } = require("../reports/generator");
const { urlFor } = require("../../lib/urlFor");

const router = express.Router();

router.get("/", (req, res) => {
  const conn = getDb();
  const stats = q.liveStats(conn);
  const allBuses = q.allBuses(conn);
  res.render("live.html", {
    stats,
    all_buses: allBuses,
    active_tab: "live",
    report_url: urlFor("live.report"),
  });
});

// Stream must be registered before the single-segment tracking route.
router.get("/api/tracking/stream/:bus_number", (req, res) => {
  const busNumber = req.params.bus_number;
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders?.();

  let lastTimestamp = null;
  const tick = () => {
    let tracking = null;
    try {
      tracking = q.getLatestTracking(getDb(), busNumber);
    } catch (e) {
      tracking = null;
    }
    if (tracking) {
      const timestamp = tracking.timestamp != null ? String(tracking.timestamp) : null;
      if (timestamp !== lastTimestamp) {
        lastTimestamp = timestamp;
        const payload = {
          bus_number: tracking.bus_number,
          lat: tracking.lat,
          lon: tracking.long,
          speed: tracking.speed,
          eta: tracking.eta,
          status: tracking.status,
          timestamp,
        };
        res.write(`event: update\ndata: ${JSON.stringify(payload)}\n\n`);
      }
    } else {
      res.write(
        'event: update\ndata: {"speed": null, "eta": null, "status": "No data", "timestamp": null}\n\n'
      );
    }
  };

  const interval = setInterval(tick, 1000);
  tick();
  req.on("close", () => clearInterval(interval));
});

router.get("/api/tracking/:bus_number", (req, res) => {
  try {
    const tracking = q.getLatestTracking(getDb(), req.params.bus_number);
    if (tracking) {
      const timestamp = tracking.timestamp != null ? String(tracking.timestamp) : null;
      return res.status(200).json({
        status: "success",
        data: {
          bus_number: tracking.bus_number,
          lat: tracking.lat,
          lon: tracking.long,
          speed: tracking.speed,
          eta: tracking.eta,
          status: tracking.status,
          timestamp,
        },
      });
    }
    return res.status(404).json({ status: "error", message: "No tracking data found for this bus" });
  } catch (e) {
    return res.status(500).json({ status: "error", message: String(e.message || e) });
  }
});

router.get("/api/school", (req, res) => {
  try {
    const school = q.getSchool(getDb());
    if (school) {
      return res.status(200).json({
        status: "success",
        data: { name: school.name, lat: school.lat, lng: school.lng },
      });
    }
    return res.status(404).json({ status: "error", message: "School not found" });
  } catch (e) {
    return res.status(500).json({ status: "error", message: String(e.message || e) });
  }
});

router.get("/api/bus-points", (req, res) => {
  try {
    const points = q.getAllBusPoints(getDb());
    return res.status(200).json({
      status: "success",
      data: (points || []).map((p) => ({
        id: p.id,
        stop_name: p.stop_name,
        lat: p.latitude,
        lng: p.longitude,
      })),
    });
  } catch (e) {
    return res.status(500).json({ status: "error", message: String(e.message || e) });
  }
});

router.get("/api/bus/:bus_number", (req, res) => {
  try {
    const conn = getDb();
    const busNumber = req.params.bus_number;
    let bus = q.getBusByNumber(conn, busNumber);
    if (!bus) {
      const asInt = parseInt(busNumber, 10);
      if (!Number.isNaN(asInt)) bus = q.getBus(conn, asInt);
    }
    if (bus) {
      return res.status(200).json({
        status: "success",
        data: { number: bus.number, lat: bus.lat, lng: bus.lng, route: bus.route },
      });
    }
    return res.status(404).json({ status: "error", message: "Bus not found" });
  } catch (e) {
    return res.status(500).json({ status: "error", message: String(e.message || e) });
  }
});

router.get("/report", (req, res) => {
  const fmt = req.query.fmt || "pdf";
  const buses = q.allBuses(getDb());
  const headers = ["Bus", "Plate", "Route", "Driver", "Status", "Lat", "Lng"];
  const rows = buses.map((b) => [b.number, b.plate, b.route, b.driver, b.status, b.lat, b.lng]);
  return buildReport(res, "Live Day Wise Report", headers, rows, fmt);
});

module.exports = router;
