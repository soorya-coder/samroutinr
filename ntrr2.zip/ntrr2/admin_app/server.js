"use strict";
const path = require("path");
const express = require("express");
const session = require("express-session");
const nunjucks = require("nunjucks");

const config = require("./config");
const { ensureDbReady, getDb } = require("../shared/db/database");
const q = require("../shared/db/queries");
const { DB_BACKEND, DB_FILE } = require("../shared/db/connection");
const { formatToday, installFilters } = require("../shared/web/templating");
const { urlFor } = require("./lib/urlFor");

const liveRouter = require("./modules/live/routes");
const busRouter = require("./modules/bus/routes");
const classesRouter = require("./modules/classes/routes");
const alertsRouter = require("./modules/alerts/routes");

function createApp() {
  ensureDbReady(); // create + seed DB on first run

  console.log("\n" + "=".repeat(30));
  console.log("🗄️  SQLITE DATABASE CONNECTED");
  console.log("=".repeat(30));
  console.log(`BACKEND  : ${DB_BACKEND}`);
  console.log(`DATABASE : ${DB_FILE}`);
  console.log("=".repeat(30) + "\n");

  const app = express();

  // Templating (Nunjucks — Jinja2-compatible).
  const env = nunjucks.configure(path.join(__dirname, "templates"), {
    autoescape: true,
    express: app,
    watch: false,
  });
  installFilters(env);
  env.addGlobal("url_for", (endpoint, kwargs) => urlFor(endpoint, kwargs));

  app.use(express.urlencoded({ extended: false }));
  app.use(express.json());
  app.use("/static", express.static(path.join(__dirname, "static")));

  app.use(
    session({
      secret: config.SECRET_KEY,
      resave: false,
      saveUninitialized: false,
      cookie: {
        httpOnly: true,
        sameSite: "lax",
        secure: false,
        maxAge: 1000 * 60 * 60 * 24 * 7, // 7 days
      },
    })
  );

  // Context processor (Flask inject_globals equivalent).
  app.use((req, res, next) => {
    res.locals.school_name = config.SCHOOL_NAME;
    res.locals.today = formatToday();
    res.locals.current_user = req.session.user || null;
    next();
  });

  // Auth guard (Flask before_request equivalent).
  const OPEN_PATHS = new Set(["/", "/login", "/logout", "/tracking"]);
  app.use((req, res, next) => {
    if (req.path.startsWith("/static") || OPEN_PATHS.has(req.path)) return next();
    if (!req.session.user) return res.redirect(urlFor("login"));
    next();
  });

  // ---------- Routes ----------
  app.get("/", (req, res) => {
    if (req.session.user) return res.redirect(urlFor("live.index"));
    return res.redirect(urlFor("login"));
  });

  app.route("/login")
    .get((req, res) => res.render("login.html", { error: null }))
    .post((req, res) => {
      const username = (req.body.username || "").trim();
      const password = req.body.password || "";
      const user = q.findAdminUser(getDb(), username, password);
      if (user) {
        req.session.user = {
          id: user.id,
          username: user.username,
          name: user.full_name,
          bus_id: user.bus_id,
        };
        return res.redirect(urlFor("live.index"));
      }
      return res.render("login.html", { error: "Invalid admin credentials." });
    });

  app.get("/logout", (req, res) => {
    req.session.user = null;
    return res.redirect(urlFor("login"));
  });

  // Receive GPS tracking data from ESP32-S3 and store in database.
  app.post("/tracking", (req, res) => {
    try {
      const data = req.body;
      if (!data || Object.keys(data).length === 0) {
        return res.status(400).json({ status: "error", message: "No JSON received" });
      }

      const busNumber = data.bus_number;
      const latitude = data.lat;
      const longitude = data.lon;
      const speed = data.speed;
      const eta = data.eta;
      const cardUid = data.card_uid;
      const sprno = data.sprno;
      const status = data.status;

      if (!busNumber || latitude === undefined || latitude === null ||
          longitude === undefined || longitude === null) {
        return res.status(400).json({
          status: "error",
          message: "Missing required fields: bus_number, lat, lon",
        });
      }

      console.log("\n================================");
      console.log(`Time      : ${new Date().toISOString()}`);
      console.log(`Bus Number: ${busNumber}`);
      console.log(`Latitude  : ${latitude}`);
      console.log(`Longitude : ${longitude}`);
      console.log(`Speed     : ${speed}`);
      console.log(`ETA       : ${eta}`);
      console.log(`Card UID  : ${cardUid}`);
      console.log(`SPR No    : ${sprno}`);
      console.log(`Status    : ${status}`);
      console.log("================================");

      const conn = getDb();
      q.insertTrackingData(conn, busNumber, latitude, longitude, speed ?? null, eta ?? null);
      q.insertStudentEntry(conn, busNumber, cardUid ?? null, sprno ?? null, status ?? null);
      q.updateBusLocation(conn, busNumber, latitude, longitude);

      return res.status(200).json({
        status: "success",
        message: "Tracking data received and stored",
      });
    } catch (e) {
      console.error("ERROR:", e);
      return res.status(500).json({ status: "error", message: String(e.message || e) });
    }
  });

  // Blueprints
  app.use("/live", liveRouter);
  app.use("/bus", busRouter);
  app.use("/classes", classesRouter);
  app.use("/alerts", alertsRouter);

  return app;
}

if (require.main === module) {
  const app = createApp();
  app.listen(config.PORT, config.HOST, () => {
    console.log(`Admin (driver) app listening on http://${config.HOST}:${config.PORT}`);
  });
}

module.exports = { createApp };
