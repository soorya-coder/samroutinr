"use strict";
const path = require("path");
const express = require("express");
const session = require("express-session");
const nunjucks = require("nunjucks");

const config = require("./config");
const { ensureDbReady, getDb } = require("../shared/db/database");
const q = require("../shared/db/queries");
const { formatToday, installFilters } = require("../shared/web/templating");
const { urlFor } = require("./lib/urlFor");

const dashboardRouter = require("./modules/dashboard/routes");

function createApp() {
  ensureDbReady(); // create + seed DB on first run

  const app = express();

  const env = nunjucks.configure(path.join(__dirname, "templates"), {
    autoescape: true,
    express: app,
    watch: false,
  });
  installFilters(env);
  env.addGlobal("url_for", (endpoint, kwargs) => urlFor(endpoint, kwargs));

  app.use(express.urlencoded({ extended: false }));
  app.use(express.json());
  app.use("/static", express.static(path.join(__dirname, "static")));

  app.use(
    session({
      secret: config.SECRET_KEY,
      resave: false,
      saveUninitialized: false,
      cookie: {
        httpOnly: true,
        sameSite: "lax",
        secure: false,
        maxAge: 1000 * 60 * 60 * 24 * 7,
      },
    })
  );

  app.use((req, res, next) => {
    res.locals.school_name = config.SCHOOL_NAME;
    res.locals.today = formatToday();
    res.locals.current_user = req.session.user || null;
    next();
  });

  // Auth guard — everything except login/logout/static requires a student session.
  const OPEN_PATHS = new Set(["/login", "/logout"]);
  app.use((req, res, next) => {
    if (req.path.startsWith("/static") || OPEN_PATHS.has(req.path)) return next();
    const user = req.session.user;
    if (!user || user.role !== "student") return res.redirect(urlFor("login"));
    next();
  });

  app.route("/login")
    .get((req, res) => res.render("login.html", { role: "student", error: null }))
    .post((req, res) => {
      const spr = (req.body.spr || "").trim();
      const dob = (req.body.dob || "").trim();
      const student = q.findStudentBySprDob(getDb(), spr, dob);
      if (student) {
        req.session.user = {
          role: "student",
          id: student.id,
          spr_no: student.spr_no,
          name: student.name,
        };
        return res.redirect(urlFor("dashboard.index"));
      }
      return res.render("login.html", {
        role: "student",
        error: "Invalid SPR number or date of birth.",
      });
    });

  app.get("/logout", (req, res) => {
    req.session.user = null;
    return res.redirect(urlFor("login"));
  });

  app.use("/", dashboardRouter);

  return app;
}

if (require.main === module) {
  const app = createApp();
  app.listen(config.PORT, config.HOST, () => {
    console.log(`Student app listening on http://${config.HOST}:${config.PORT}`);
  });
}

module.exports = { createApp };
