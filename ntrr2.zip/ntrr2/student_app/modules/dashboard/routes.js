"use strict";
const express = require("express");
const { getDb } = require("../../../shared/db/database");
const q = require("../../../shared/db/queries");
const { haversineKm, etaMinutes, nearestLocationName } = require("../../../shared/geo");

const router = express.Router();

function round2(x) {
  return Math.round(x * 100) / 100;
}

function serializeDatetime(value) {
  // SQLite stores these as text already; pass through.
  return value === undefined ? null : value;
}

router.get("/", (req, res) => {
  const user = req.session.user || null;
  if (!user || user.role !== "student") return res.status(401).send("Unauthorized");

  const sid = user.id;
  const conn = getDb();
  const student = q.getStudent(conn, sid);
  if (!student) return res.status(404).send("Not Found");

  let bus = null;
  if (student.bus_id !== null && student.bus_id !== undefined) {
    bus = q.getBus(conn, student.bus_id);
  }
  if (!bus && student.bus_number) {
    bus = q.getBusByNumber(conn, student.bus_number);
  }
  if (!bus && student.bus_id !== null && student.bus_id !== undefined) {
    bus = q.getBusByNumber(conn, String(student.bus_id));
  }
  if (!bus) return res.status(404).send("Not Found");

  const school = q.getSchool(conn);

  const busToPickupKm = haversineKm(bus.lat, bus.lng, student.pickup_lat, student.pickup_lng);
  const busToSchoolKm = haversineKm(bus.lat, bus.lng, school.lat, school.lng);
  const metrics = {
    bus_to_pickup_km: round2(busToPickupKm),
    bus_to_pickup_min: etaMinutes(busToPickupKm),
    bus_to_school_km: round2(busToSchoolKm),
    bus_to_school_min: etaMinutes(busToSchoolKm),
  };

  res.render("dashboard.html", { student, bus, school, metrics });
});

router.get("/api/tracking/:bus_number", (req, res) => {
  try {
    const tracking = q.getLatestTracking(getDb(), req.params.bus_number);
    if (tracking) {
      const timestamp = tracking.timestamp != null ? String(tracking.timestamp) : null;
      return res.status(200).json({
        status: "success",
        data: {
          bus_number: tracking.bus_number,
          lat: tracking.lat,
          lon: tracking.long,
          speed: tracking.speed,
          eta: tracking.eta,
          status: tracking.status,
          timestamp,
        },
      });
    }
    return res.status(404).json({ status: "error", message: "No tracking data found" });
  } catch (e) {
    return res.status(500).json({ status: "error", message: String(e.message || e) });
  }
});

router.get("/api/bus/:bus_number", (req, res) => {
  try {
    const conn = getDb();
    const busNumber = req.params.bus_number;
    let bus = q.getBusByNumber(conn, busNumber);
    if (!bus) {
      const asInt = parseInt(busNumber, 10);
      if (!Number.isNaN(asInt)) bus = q.getBus(conn, asInt);
    }
    if (bus) {
      const locationName = nearestLocationName(
        bus.lat,
        bus.lng,
        q.getAllBusPoints(conn),
        0.8
      );
      return res.status(200).json({
        status: "success",
        data: {
          number: bus.number,
          lat: bus.lat,
          lng: bus.lng,
          route: bus.route,
          location_name: locationName || "Unknown location",
        },
      });
    }
    return res.status(404).json({ status: "error", message: "Bus not found" });
  } catch (e) {
    return res.status(500).json({ status: "error", message: String(e.message || e) });
  }
});

router.post("/api/route/session", (req, res) => {
  const payload = req.body || {};
  const busNumber = payload.bus_number;
  if (!busNumber) {
    return res.status(400).json({ status: "error", message: "bus_number is required" });
  }

  const sessUser = req.session.user || null;
  let studentId = payload.student_id;
  if ((studentId === undefined || studentId === null) && sessUser && sessUser.role === "student") {
    studentId = sessUser.id;
  }

  try {
    const sessionId = q.insertRouteSession(getDb(), busNumber, studentId ?? null);
    if (sessionId === null) {
      return res.status(500).json({ status: "error", message: "Could not create route session" });
    }
    return res.status(200).json({
      status: "success",
      data: { session_id: sessionId, bus_number: busNumber },
    });
  } catch (e) {
    return res.status(500).json({ status: "error", message: String(e.message || e) });
  }
});

router.post("/api/route/session/:session_id/end", (req, res) => {
  try {
    const sessionId = parseInt(req.params.session_id, 10);
    q.endRouteSession(getDb(), sessionId);
    return res.status(200).json({ status: "success", data: { session_id: sessionId } });
  } catch (e) {
    return res.status(500).json({ status: "error", message: String(e.message || e) });
  }
});

router.post("/api/route/session/:session_id/point", (req, res) => {
  const payload = req.body || {};
  const lat = payload.lat;
  const lng = payload.lng;
  if (lat === undefined || lat === null || lng === undefined || lng === null) {
    return res.status(400).json({ status: "error", message: "lat and lng are required" });
  }
  try {
    const sessionId = parseInt(req.params.session_id, 10);
    const conn = getDb();
    const pointSeq = q.getNextRoutePointSeq(conn, sessionId);
    q.insertRoutePoint(conn, sessionId, pointSeq, lat, lng);
    return res.status(200).json({
      status: "success",
      data: { session_id: sessionId, point_seq: pointSeq },
    });
  } catch (e) {
    return res.status(500).json({ status: "error", message: String(e.message || e) });
  }
});

router.get("/api/route/sessions/:bus_number", (req, res) => {
  try {
    const sessions = q.getAvailableRouteSessions(getDb(), req.params.bus_number);
    if (!sessions || !sessions.length) {
      return res.status(404).json({ status: "error", message: "No saved routes found" });
    }
    const serialized = sessions.map((s) => ({
      ...s,
      started_at: serializeDatetime(s.started_at),
      ended_at: serializeDatetime(s.ended_at),
    }));
    return res.status(200).json({ status: "success", data: serialized });
  } catch (e) {
    return res.status(500).json({ status: "error", message: String(e.message || e) });
  }
});

router.get("/api/route/session/:session_id", (req, res) => {
  try {
    const conn = getDb();
    const sessionId = parseInt(req.params.session_id, 10);
    const routeSession = q.getRouteSession(conn, sessionId);
    if (!routeSession) {
      return res.status(404).json({ status: "error", message: "Route session not found" });
    }
    const points = q.getRoutePoints(conn, sessionId);
    return res.status(200).json({
      status: "success",
      data: {
        session_id: routeSession.session_id,
        started_at: serializeDatetime(routeSession.started_at),
        ended_at: serializeDatetime(routeSession.ended_at),
        points,
      },
    });
  } catch (e) {
    return res.status(500).json({ status: "error", message: String(e.message || e) });
  }
});

router.get("/api/route/last/:bus_number", (req, res) => {
  try {
    const conn = getDb();
    const routeSession = q.getLastRouteSession(conn, req.params.bus_number);
    if (!routeSession) {
      return res.status(404).json({ status: "error", message: "No saved route found" });
    }
    const points = q.getRoutePoints(conn, routeSession.session_id);
    return res.status(200).json({
      status: "success",
      data: {
        session_id: routeSession.session_id,
        started_at: serializeDatetime(routeSession.started_at),
        ended_at: serializeDatetime(routeSession.ended_at),
        points,
      },
    });
  } catch (e) {
    return res.status(500).json({ status: "error", message: String(e.message || e) });
  }
});

module.exports = router;
