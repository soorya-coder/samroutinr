"use strict";
// Student app config — edit PORT to change the listening port.
module.exports = {
  SCHOOL_NAME: "Mount Zion Schools",
  PORT: 4014,
  HOST: "0.0.0.0",
  SECRET_KEY: "dev-only-not-secret-change-me",
  DEBUG: true,
  DEFAULT_STUDENT_ID: 1,
};
