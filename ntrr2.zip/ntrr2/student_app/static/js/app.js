// Student switcher: auto-submit form on change
// document.addEventListener('DOMContentLoaded', () => {
//   const sel = document.getElementById('student-select');
//   if (sel) {
//     sel.addEventListener('change', (e) => e.target.form.submit());
//   }
// });
