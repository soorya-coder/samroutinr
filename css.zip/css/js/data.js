/* =========================================================
   ELECTRO HUB — Product catalogue (sample data, INR)
   Each product carries 4 perspective images: front, back, side, angle.
   Images are sourced from Unsplash and are illustrative.
   ========================================================= */

const CATEGORIES = [
  { id: "audio",       name: "Audio",          tag: "Sound & Listening" },
  { id: "wearables",   name: "Wearables",      tag: "Watches & Bands" },
  { id: "computing",   name: "Computing",      tag: "Laptops & Tablets" },
  { id: "mobile",      name: "Mobile",         tag: "Phones & Accessories" },
  { id: "imaging",     name: "Imaging",        tag: "Cameras & Optics" },
  { id: "home",        name: "Smart Home",     tag: "Living & Comfort" },
  { id: "appliances",  name: "Home Appliances",tag: "Kitchen & Living" }
];

/* =========================================================
   Installation & Configuration services
   Tagline: "The piece arrives. We do the rest."
   ========================================================= */
const SERVICES = {
  install: {
    key: "install",
    name: "White-glove installation",
    short: "Complimentary installation",
    free: true,
    price: 0,
    description: "Our two-person team carries the piece in, levels and plumbs where needed, tests every cycle, and walks you through the controls."
  },
  concierge: {
    key: "concierge",
    name: "Concierge setup",
    short: "Complimentary setup",
    free: true,
    price: 0,
    description: "An engineer comes by, pairs and calibrates your piece for the room, and stays until everything sings."
  },
  migration: {
    key: "migration",
    name: "Data migration & setup",
    short: "Optional setup · ₹999",
    free: false,
    price: 999,
    description: "Full data transfer, app installation, and account migration on laptops and tablets. Booked at checkout or by appointment."
  },
  device: {
    key: "device",
    name: "Device setup",
    short: "Optional setup · ₹499",
    free: false,
    price: 499,
    description: "Account setup, app installation, and SIM transfer on new phones."
  }
};

const PRODUCTS = [
  /* ---------- Audio ---------- */
  {
    id: "p01",
    service: "concierge",
    name: "Aurelius Studio Headphones",
    cat: "audio",
    brand: "Aurelius",
    price: 44990,
    old: 56990,
    rating: 4.8,
    reviews: 214,
    badge: "New",
    stock: 24,
    seller: "Aurelius Atelier",
    desc: "Hand-finished over-ear headphones with lambskin cushions and a milled aluminium yoke. Designed for the considered listener.",
    features: ["40mm beryllium drivers","Adaptive noise cancellation","36-hour battery","Bluetooth 5.3 / Multipoint","Foldable travel form"],
    images: [
      "https://images.unsplash.com/photo-1583394838336-acd977736f90?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1577174881658-0f30ed549adc?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p02",
    name: "Marchetti Wireless Earbuds",
    cat: "audio",
    brand: "Marchetti",
    price: 23990,
    old: 27990,
    rating: 4.6,
    reviews: 158,
    badge: "",
    stock: 41,
    seller: "Marchetti Sound",
    desc: "Pearl-finish earbuds tuned by a chamber orchestra engineer. Compact and unwaveringly precise.",
    features: ["Active noise cancellation","Spatial audio","8h + 24h case","IPX5 water resistant","Wireless charging"],
    images: [
      "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1572569511254-d8f925fe2cbb?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1608156639585-b3a032ef9689?auto=format&fit=crop&w=900&q=80"
    ]
  },
  /* ---------- Wearables ---------- */
  {
    id: "p03",
    service: "concierge",
    name: "Heritage Smart Watch Noir",
    cat: "wearables",
    brand: "Holloway",
    price: 56990,
    old: 62990,
    rating: 4.7,
    reviews: 312,
    badge: "Featured",
    stock: 18,
    seller: "Holloway & Sons",
    desc: "A timepiece in the truest tradition — sapphire crystal, brushed steel, and a discreet OLED face.",
    features: ["1.45in AMOLED","Sapphire crystal","ECG & SpO2","14-day battery","Steel & leather straps"],
    images: [
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1434056886845-dac89ffe9b56?auto=format&fit=crop&w=900&q=80"
    ]
  },
  /* ---------- Computing ---------- */
  {
    id: "p04",
    service: "migration",
    name: "Vesta Slim Laptop 14",
    cat: "computing",
    brand: "Vesta",
    price: 154990,
    old: 169990,
    rating: 4.9,
    reviews: 96,
    badge: "Editor's choice",
    stock: 11,
    seller: "Vesta Works",
    desc: "An impossibly thin laptop carved from a single aluminium block. Quiet, exact, and confident.",
    features: ["14in 3K OLED","M-series silicon","16GB RAM","1TB SSD","18h battery"],
    images: [
      "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p05",
    service: "migration",
    name: "Atlas Pro Tablet 12",
    cat: "computing",
    brand: "Atlas",
    price: 98990,
    old: 0,
    rating: 4.5,
    reviews: 74,
    badge: "",
    stock: 27,
    seller: "Atlas Studio",
    desc: "Touch, draw, and write on a 12-inch glass-and-steel canvas with measured response.",
    features: ["12in mini-LED","Stylus included","256GB / 1TB","M-series chip","12MP camera"],
    images: [
      "https://images.unsplash.com/photo-1561154464-82e9adf32764?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1542751110-97427bbecf20?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1623126908029-58cb08a2b272?auto=format&fit=crop&w=900&q=80"
    ]
  },
  /* ---------- Mobile ---------- */
  {
    id: "p06",
    service: "device",
    name: "Sterling Mobile Edition",
    cat: "mobile",
    brand: "Sterling",
    price: 89990,
    old: 0,
    rating: 4.7,
    reviews: 502,
    badge: "Best Seller",
    stock: 64,
    seller: "Sterling House",
    desc: "A phone built around a triple-lens optical system and a titanium frame. Restraint, considered.",
    features: ["6.3in ProMotion","Triple optical lens","Titanium chassis","Action button","All-day battery"],
    images: [
      "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1605236453806-6ff36851218e?auto=format&fit=crop&w=900&q=80"
    ]
  },
  /* ---------- Imaging ---------- */
  {
    id: "p07",
    service: "concierge",
    name: "Beaumont Mirrorless Camera",
    cat: "imaging",
    brand: "Beaumont",
    price: 189990,
    old: 204990,
    rating: 4.9,
    reviews: 41,
    badge: "Limited",
    stock: 6,
    seller: "Beaumont Optics",
    desc: "A full-frame mirrorless with a hand-coated prime lens. The shutter speaks softly, the prints sing.",
    features: ["45MP full-frame","8K video","5-axis stabilisation","Hot-shoe accessory port","Magnesium alloy body"],
    images: [
      "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1606986601547-9d3d6f0bf2b4?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1519183071298-a2962feb14f4?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1495707902641-75cac588d2e9?auto=format&fit=crop&w=900&q=80"
    ]
  },
  /* ---------- Smart Home ---------- */
  {
    id: "p08",
    service: "concierge",
    name: "Cedarwood Smart Speaker",
    cat: "home",
    brand: "Cedarwood",
    price: 28990,
    old: 0,
    rating: 4.4,
    reviews: 188,
    badge: "",
    stock: 39,
    seller: "Cedarwood Acoustics",
    desc: "A walnut-and-fabric speaker that disappears into the room until it doesn't.",
    features: ["Room calibration","Stereo pairing","Voice assistant","AirPlay 2 / Spotify Connect","Hand-finished cabinet"],
    images: [
      "https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1589003077984-894e133dabab?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1558379850-9c5b1f5d5d54?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1545127398-14699f92334b?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p09",
    name: "Aurelius Desk Headphones II",
    cat: "audio",
    brand: "Aurelius",
    price: 34990,
    old: 38990,
    rating: 4.5,
    reviews: 87,
    badge: "",
    stock: 22,
    seller: "Aurelius Atelier",
    desc: "On-ear comfort with a measured ear-cup pivot. Lightweight, long sessions.",
    features: ["32mm drivers","Bluetooth 5.2","28h battery","Memory foam","USB-C"],
    images: [
      "https://images.unsplash.com/photo-1487215078519-e21cc028cb29?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1599669454699-248893623440?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1574920162043-b872873f19c8?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p10",
    name: "Holloway Field Watch",
    cat: "wearables",
    brand: "Holloway",
    price: 35990,
    old: 0,
    rating: 4.6,
    reviews: 154,
    badge: "",
    stock: 33,
    seller: "Holloway & Sons",
    desc: "A working watch finished like a dress watch — patinaed steel and a domed sapphire.",
    features: ["38mm steel case","Sapphire crystal","100m water resistance","Sellita SW200","Quick-change strap"],
    images: [
      "https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1547996160-81dfa63595aa?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1612817159576-bb55cb01a02d?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1495856458515-0637185db551?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p11",
    name: "Atlas Wireless Keyboard",
    cat: "computing",
    brand: "Atlas",
    price: 15990,
    old: 18990,
    rating: 4.3,
    reviews: 63,
    badge: "",
    stock: 58,
    seller: "Atlas Studio",
    desc: "A low-profile mechanical board in ivory and brass. Quiet switches and a measured travel.",
    features: ["Mechanical low-profile","Bluetooth + USB-C","Backlit","Aluminium plate","Mac & Win layouts"],
    images: [
      "https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1601445638532-3c6f6c3aa1d6?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1595044426077-d36d9236d44e?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1561112078-7d24e04c3407?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p12",
    name: "Sterling Leather Phone Case",
    cat: "mobile",
    brand: "Sterling",
    price: 6490,
    old: 0,
    rating: 4.2,
    reviews: 211,
    badge: "",
    stock: 120,
    seller: "Sterling House",
    desc: "Full-grain vegetable-tanned leather, hand-stitched. Patinas with use.",
    features: ["Italian leather","Hand-stitched","Microfiber lining","MagSafe compatible","Three colorways"],
    images: [
      "https://images.unsplash.com/photo-1601593346740-925612772716?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1574539558944-fdf8c1ec5cb1?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1556656793-08538906a9f8?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1585060544812-6b45742d762f?auto=format&fit=crop&w=900&q=80"
    ]
  },

  /* ---------- Home Appliances ---------- */
  {
    id: "p13",
    service: "install",
    name: "Marlowe Smart Refrigerator 580",
    cat: "appliances",
    brand: "Marlowe",
    price: 124990,
    old: 142990,
    rating: 4.7,
    reviews: 88,
    badge: "New",
    stock: 12,
    seller: "Marlowe Living",
    desc: "A 580-litre side-by-side refrigerator in brushed bronze. Inverter-cooled, whisper-quiet, and finished to the millimetre.",
    features: ["580L capacity","Linear inverter compressor","Convertible freezer","Smart Wi-Fi diagnostics","10-year compressor warranty"],
    images: [
      "https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1584568694244-14fbdf83bd30?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1620626011761-996317b8d101?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p14",
    service: "install",
    name: "Atherton Front-Load Washer 8kg",
    cat: "appliances",
    brand: "Atherton",
    price: 56990,
    old: 64990,
    rating: 4.6,
    reviews: 142,
    badge: "",
    stock: 18,
    seller: "Atherton Home",
    desc: "An inverter-driven 8-kilogram front-load washer with steam care and a hand-balanced drum.",
    features: ["8kg capacity","Inverter motor","Steam wash","15 wash programs","Silent operation 49dB"],
    images: [
      "https://images.unsplash.com/photo-1626806787461-102c1bfaaea1?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1610557892470-55d9e80c0bce?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1604335398480-1c2f6b51ae29?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p15",
    service: "install",
    name: "Beaumont Built-in Microwave",
    cat: "appliances",
    brand: "Beaumont",
    price: 38990,
    old: 0,
    rating: 4.4,
    reviews: 65,
    badge: "",
    stock: 24,
    seller: "Beaumont Living",
    desc: "A 32-litre convection microwave with a brushed-steel face and an unhurried, mechanical dial.",
    features: ["32L convection","Auto-cook menu","Steel cavity","Pre-set rotary dial","Child lock"],
    images: [
      "https://images.unsplash.com/photo-1574269909862-7e1d70bb8078?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1585237017125-24baf8d7406f?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1574269906893-cf16c30dadcc?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1610701596007-11502861dcfa?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p16",
    service: "install",
    name: "Ravensdale Air Purifier Pro",
    cat: "appliances",
    brand: "Ravensdale",
    price: 32990,
    old: 36990,
    rating: 4.8,
    reviews: 219,
    badge: "Featured",
    stock: 30,
    seller: "Ravensdale Air",
    desc: "A three-stage HEPA purifier sheathed in oak veneer. Quietly returns a room to itself.",
    features: ["True HEPA + carbon","60 m² coverage","PM2.5 sensor + display","Night mode (24dB)","Wi-Fi & app control"],
    images: [
      "https://images.unsplash.com/photo-1605101100278-5d1deb2b6498?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1631545806609-1ac26c269bff?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1626806787461-102c1bfaaea1?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1583846617408-19e1a48a4f9d?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p17",
    service: "install",
    name: "Halcyon Smart Air Conditioner 1.5T",
    cat: "appliances",
    brand: "Halcyon",
    price: 64990,
    old: 71990,
    rating: 4.5,
    reviews: 96,
    badge: "",
    stock: 14,
    seller: "Halcyon Climate",
    desc: "A 1.5-ton inverter split AC tuned for sleep. A whisper, then a cool room.",
    features: ["1.5 Ton inverter","5-star efficiency","Anti-bacterial filter","Voice + app control","Self-clean"],
    images: [
      "https://images.unsplash.com/photo-1581275288578-bda1c1e3e8d2?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1635340860336-aa45a3c84e36?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1631545806609-1ac26c269bff?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1567720700446-93b8a3edaf7c?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p18",
    service: "install",
    name: "Cedarwood Built-in Dishwasher",
    cat: "appliances",
    brand: "Cedarwood",
    price: 78990,
    old: 0,
    rating: 4.6,
    reviews: 54,
    badge: "",
    stock: 9,
    seller: "Cedarwood Living",
    desc: "A 14-place-setting dishwasher with a steel cavity and a soft-close door. Discreet to the eye, polite to the hour.",
    features: ["14 place settings","Steel inox tub","43dB silent cycle","Auto-dose detergent","8 programs"],
    images: [
      "https://images.unsplash.com/photo-1581622558663-b2e33377dfb2?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1610557892470-55d9e80c0bce?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1604335398480-1c2f6b51ae29?auto=format&fit=crop&w=900&q=80"
    ]
  },

  /* ---------- Audio (more) ---------- */
  {
    id: "p19",
    service: "concierge",
    name: "Aurelius Reference Open-Back Headphones",
    cat: "audio",
    brand: "Aurelius",
    price: 89990,
    old: 99990,
    rating: 4.9,
    reviews: 64,
    badge: "Editor's choice",
    stock: 8,
    seller: "Aurelius Atelier",
    desc: "An audiophile open-back in ebony and lambskin. For listening rooms with carpet and a quiet wall.",
    features: ["50mm planar drivers","Ebony cups, hand-finished","Lambskin headband","Balanced 4-pin cable","Lifetime atelier service"],
    images: [
      "https://images.unsplash.com/photo-1545127398-14699f92334b?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1487215078519-e21cc028cb29?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1583394838336-acd977736f90?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p20",
    service: "concierge",
    name: "Marchetti Belt-Drive Turntable",
    cat: "audio",
    brand: "Marchetti",
    price: 64990,
    old: 72990,
    rating: 4.7,
    reviews: 38,
    badge: "",
    stock: 14,
    seller: "Marchetti Sound",
    desc: "A walnut-plinth belt-drive turntable with a balanced tonearm and a moving-magnet cartridge fitted by hand.",
    features: ["Belt-drive 33⅓/45","Walnut plinth","Pre-mounted MM cartridge","Balanced tonearm","Anti-skating adjustment"],
    images: [
      "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1574169208507-84376144848b?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1594732832278-abd644401426?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1542456885-0e9e91a6b1be?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p21",
    service: "install",
    name: "Cedarwood Bookshelf Speakers (pair)",
    cat: "audio",
    brand: "Cedarwood",
    price: 78990,
    old: 0,
    rating: 4.8,
    reviews: 52,
    badge: "",
    stock: 16,
    seller: "Cedarwood Acoustics",
    desc: "A pair of stand-mount speakers in walnut with silk-dome tweeters. Hand-tuned in our acoustic room.",
    features: ["6.5in mid-bass driver","1in silk-dome tweeter","Walnut veneer cabinet","Bi-wire ready","Hand-tuned crossover"],
    images: [
      "https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1589003077984-894e133dabab?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1558379850-9c5b1f5d5d54?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1545127398-14699f92334b?auto=format&fit=crop&w=900&q=80"
    ]
  },

  /* ---------- Wearables (more) ---------- */
  {
    id: "p22",
    service: "concierge",
    name: "Holloway Dress Watch in Gold",
    cat: "wearables",
    brand: "Holloway",
    price: 124990,
    old: 142990,
    rating: 4.9,
    reviews: 28,
    badge: "Limited",
    stock: 4,
    seller: "Holloway & Sons",
    desc: "A dress watch in 18k yellow gold with an alligator strap. Quiet at the cuff, unmistakable on the wrist.",
    features: ["18k yellow gold case","Hand-wound calibre","Alligator leather strap","Sapphire crystal","50m water resistance"],
    images: [
      "https://images.unsplash.com/photo-1547996160-81dfa63595aa?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1495856458515-0637185db551?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1612817159576-bb55cb01a02d?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1611591437281-460914d3a1a2?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p23",
    name: "Marchetti Leather Fitness Band",
    cat: "wearables",
    brand: "Marchetti",
    price: 12990,
    old: 14990,
    rating: 4.3,
    reviews: 96,
    badge: "",
    stock: 72,
    seller: "Marchetti Sound",
    desc: "A discreet fitness band in vegetable-tanned leather. The work of staying well, quietly tracked.",
    features: ["Heart rate & SpO2","Sleep tracking","7-day battery","Italian leather strap","Water resistant 5ATM"],
    images: [
      "https://images.unsplash.com/photo-1579586337278-3f436f25d4a6?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1575311373937-040b8e1fd6b0?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1551816230-ef5deaed4a26?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p24",
    service: "concierge",
    name: "Holloway Pocket Watch Heritage",
    cat: "wearables",
    brand: "Holloway",
    price: 89990,
    old: 0,
    rating: 4.8,
    reviews: 19,
    badge: "Featured",
    stock: 6,
    seller: "Holloway & Sons",
    desc: "A skeleton pocket watch in stainless steel with a sapphire caseback. A pocket weight, considered.",
    features: ["Hand-wound skeleton movement","Sapphire crystal both sides","Stainless steel case","Albert chain included","Lifetime atelier service"],
    images: [
      "https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1612817159576-bb55cb01a02d?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1547996160-81dfa63595aa?auto=format&fit=crop&w=900&q=80"
    ]
  },

  /* ---------- Computing (more) ---------- */
  {
    id: "p25",
    service: "install",
    name: "Vesta Studio Display 27",
    cat: "computing",
    brand: "Vesta",
    price: 174990,
    old: 199990,
    rating: 4.8,
    reviews: 56,
    badge: "",
    stock: 9,
    seller: "Vesta Works",
    desc: "A 27-inch 5K display in machined aluminium. Calibrated at the factory, hand-checked in our atelier.",
    features: ["27in 5K Retina","P3 wide colour gamut","600 nits sustained","USB-C hub with 96W charging","VESA mount adapter"],
    images: [
      "https://images.unsplash.com/photo-1527443060795-0402a18106c2?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p26",
    name: "Atlas Precision Mouse",
    cat: "computing",
    brand: "Atlas",
    price: 9990,
    old: 11990,
    rating: 4.4,
    reviews: 84,
    badge: "",
    stock: 96,
    seller: "Atlas Studio",
    desc: "A precision mouse in ivory and brass with quiet mechanical switches and a hand-finished body.",
    features: ["8000 DPI optical sensor","Quiet mechanical switches","USB-C charging","Aluminium chassis","Ivory & brass finish"],
    images: [
      "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1605773527852-c546a8584ea3?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p27",
    service: "migration",
    name: "Vesta Pro Laptop 16",
    cat: "computing",
    brand: "Vesta",
    price: 224990,
    old: 239990,
    rating: 4.9,
    reviews: 42,
    badge: "Best Seller",
    stock: 7,
    seller: "Vesta Works",
    desc: "A 16-inch pro laptop with a mini-LED display, M-series Max silicon, and 22 hours of quiet work.",
    features: ["16in mini-LED ProMotion 120Hz","M-series Max chip","32GB unified memory","2TB SSD","22-hour battery"],
    images: [
      "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?auto=format&fit=crop&w=900&q=80"
    ]
  },

  /* ---------- Mobile (more) ---------- */
  {
    id: "p28",
    service: "device",
    name: "Sterling Compact Edition",
    cat: "mobile",
    brand: "Sterling",
    price: 79990,
    old: 0,
    rating: 4.6,
    reviews: 218,
    badge: "",
    stock: 38,
    seller: "Sterling House",
    desc: "A compact phone with the full optical system. Reaches the pocket without compromising the print.",
    features: ["5.4in ProMotion","Triple optical lens","Titanium chassis","Action button","Day-and-a-half battery"],
    images: [
      "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1567720700446-93b8a3edaf7c?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1605236453806-6ff36851218e?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p29",
    name: "Sterling Wallet Phone Case",
    cat: "mobile",
    brand: "Sterling",
    price: 8990,
    old: 0,
    rating: 4.4,
    reviews: 142,
    badge: "",
    stock: 110,
    seller: "Sterling House",
    desc: "A leather wallet case with a hand-stitched card holder. Three cards, one cheque, a small note.",
    features: ["Full-grain Italian leather","Three card slots","Hand-stitched","MagSafe-compatible","Cognac, black, oxblood"],
    images: [
      "https://images.unsplash.com/photo-1601593346740-925612772716?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1556656793-08538906a9f8?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1585060544812-6b45742d762f?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1574539558944-fdf8c1ec5cb1?auto=format&fit=crop&w=900&q=80"
    ]
  },

  /* ---------- Imaging (more) ---------- */
  {
    id: "p30",
    service: "concierge",
    name: "Beaumont 50mm f/1.4 Prime Lens",
    cat: "imaging",
    brand: "Beaumont",
    price: 89990,
    old: 99990,
    rating: 4.9,
    reviews: 31,
    badge: "Featured",
    stock: 8,
    seller: "Beaumont Optics",
    desc: "A hand-coated 50mm prime in brass and aluminium. A working lens that becomes a favourite.",
    features: ["50mm f/1.4 prime","Hand-coated optics","Manual aperture ring","Brass mount","Weather-sealed"],
    images: [
      "https://images.unsplash.com/photo-1606986601547-9d3d6f0bf2b4?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1519183071298-a2962feb14f4?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1495707902641-75cac588d2e9?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p31",
    service: "concierge",
    name: "Beaumont Compact Camera",
    cat: "imaging",
    brand: "Beaumont",
    price: 119990,
    old: 0,
    rating: 4.7,
    reviews: 24,
    badge: "Limited",
    stock: 5,
    seller: "Beaumont Optics",
    desc: "A fixed-lens compact with an APS-C sensor and a hybrid optical viewfinder. For pocket carry, and serious work.",
    features: ["28mm f/1.7 fixed lens","APS-C sensor","Hybrid optical viewfinder","Magnesium body","Leather neck strap"],
    images: [
      "https://images.unsplash.com/photo-1495707902641-75cac588d2e9?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1606986601547-9d3d6f0bf2b4?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1519183071298-a2962feb14f4?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?auto=format&fit=crop&w=900&q=80"
    ]
  },

  /* ---------- Smart Home (more) ---------- */
  {
    id: "p32",
    service: "install",
    name: "Holloway Brass Floor Lamp",
    cat: "home",
    brand: "Holloway",
    price: 42990,
    old: 0,
    rating: 4.5,
    reviews: 67,
    badge: "",
    stock: 18,
    seller: "Holloway & Sons",
    desc: "A standing lamp in brushed brass with a linen shade. Quietly dimmable, voice-aware, hand-finished.",
    features: ["Brushed brass body","Hand-stitched linen shade","Wi-Fi & voice dimmer","Warm-to-cool whites","Hand-finished base"],
    images: [
      "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1517991104123-1d56a6e81ed9?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1572025442646-866d16c84a54?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p33",
    service: "install",
    name: "Cedarwood Premium Soundbar",
    cat: "home",
    brand: "Cedarwood",
    price: 89990,
    old: 99990,
    rating: 4.8,
    reviews: 78,
    badge: "",
    stock: 12,
    seller: "Cedarwood Acoustics",
    desc: "A wide soundbar with a wireless subwoofer, finished in walnut. A discreet upgrade for the living room.",
    features: ["7.1.4 Dolby Atmos","Wireless subwoofer","Walnut grille","HDMI eARC","Automatic room calibration"],
    images: [
      "https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1545127398-14699f92334b?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1589003077984-894e133dabab?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1558379850-9c5b1f5d5d54?auto=format&fit=crop&w=900&q=80"
    ]
  },

  /* ---------- Home Appliances (more) ---------- */
  {
    id: "p34",
    service: "install",
    name: "Marlowe Espresso Machine Pro",
    cat: "appliances",
    brand: "Marlowe",
    price: 54990,
    old: 64990,
    rating: 4.7,
    reviews: 112,
    badge: "Best Seller",
    stock: 15,
    seller: "Marlowe Living",
    desc: "A dual-boiler espresso machine in brushed steel. A few seconds of warm-up, the rest of your morning, set.",
    features: ["Dual boiler","PID temperature control","Professional steam wand","58mm portafilter","Brushed stainless steel"],
    images: [
      "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1610889556528-9a770e32642f?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1572286258217-215cf8e9a061?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p35",
    service: "install",
    name: "Atherton Smart Tower Fan",
    cat: "appliances",
    brand: "Atherton",
    price: 24990,
    old: 28990,
    rating: 4.5,
    reviews: 98,
    badge: "",
    stock: 28,
    seller: "Atherton Home",
    desc: "A bladeless tower fan with twelve speeds and a quiet sleep mode. A presence in the room only when you ask it.",
    features: ["360° oscillation","12-speed inverter motor","Sleep mode (24dB)","Voice & app control","HEPA-ready slot"],
    images: [
      "https://images.unsplash.com/photo-1564540586988-aa4e53c3d799?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1631545806609-1ac26c269bff?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1583846617408-19e1a48a4f9d?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1605101100278-5d1deb2b6498?auto=format&fit=crop&w=900&q=80"
    ]
  },
  {
    id: "p36",
    service: "install",
    name: "Ravensdale Temperature Kettle",
    cat: "appliances",
    brand: "Ravensdale",
    price: 16990,
    old: 0,
    rating: 4.6,
    reviews: 184,
    badge: "",
    stock: 44,
    seller: "Ravensdale Air",
    desc: "A 1.7-litre brushed-steel kettle with precise temperature presets. The right water for the right tea.",
    features: ["Temperature presets (40–100°C)","1.7L brushed steel","Keep-warm 60 minutes","App control","Silent boil"],
    images: [
      "https://images.unsplash.com/photo-1573830079427-7e6f3683c5cd?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=900&q=80",
      "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=900&q=80"
    ]
  }
];

/* Offers / deals — INR */
const OFFERS = [
  { code: "HERITAGE10", desc: "10% off any purchase above ₹40,000", until: "31 Dec 2026", amount: 0.10, min: 40000 },
  { code: "SOUND15",    desc: "15% off all audio products",        until: "30 Jun 2026", amount: 0.15, min: 0  },
  { code: "GIFT2000",   desc: "₹2,000 off your first order",       until: "30 Sep 2026", amount: 2000,  flat: true, min: 8000 },
  { code: "HOME20",     desc: "20% off home appliances",           until: "31 Aug 2026", amount: 0.20, min: 25000 }
];

/* Make accessible globally */
window.CATEGORIES = CATEGORIES;
window.PRODUCTS = PRODUCTS;
window.OFFERS = OFFERS;
