/* =========================================================
   ELECTRO HUB — Dynamic invoice renderer.
   Called from confirmation.html and orders.html.
   ========================================================= */

function renderInvoice(order) {
  const d = new Date(order.date);
  const dateStr = d.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  const timeStr = d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
  const c = order.customer || {};
  return `
    <header>
      <div>
        <h2>Electro Hub</h2>
        <p class="muted" style="margin:0; font-size:0.85rem;">House of Considered Electronics<br>8 Lavelle Road · Bangalore 560001 · Karnataka, India</p>
      </div>
      <div class="right">
        <span class="eyebrow">Invoice</span>
        <h3 style="font-family:var(--serif); margin:6px 0;">${order.id}</h3>
        <p class="muted" style="margin:0;">${dateStr} · ${timeStr}</p>
      </div>
    </header>

    <div class="inv-grid">
      <div>
        <h5>Billed to</h5>
        <p style="margin:0;">${c.cName || "Customer"}<br>${c.cAddr || ""}<br>${c.cCity || ""}${c.cState ? ', ' + c.cState : ''} ${c.cPostal || ""}<br>${c.cCountry || ""}<br>${c.cEmail || ""}</p>
      </div>
      <div>
        <h5>Payment</h5>
        <p style="margin:0;">Method: ${order.method.toUpperCase()}<br>Status: ${order.status}<br>Reference: ${order.id.split("-")[1]}</p>
      </div>
    </div>

    <table class="inv-table">
      <thead>
        <tr>
          <th>Item</th>
          <th class="num">Qty</th>
          <th class="num">Unit</th>
          <th class="num">Total</th>
        </tr>
      </thead>
      <tbody>
        ${order.items.map(i => `
          <tr${i.isService ? ' style="color:var(--muted);"' : ''}>
            <td>${i.name}</td>
            <td class="num">${i.qty}</td>
            <td class="num">${i.isService && i.free ? 'Free' : '₹' + i.price.toLocaleString("en-IN")}</td>
            <td class="num">${i.isService && i.free ? 'Complimentary' : '₹' + (i.price * i.qty).toLocaleString("en-IN")}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>

    <div class="inv-totals">
      <div class="line"><span>Pieces subtotal</span><span>${"₹" + Math.round(order.subtotal).toLocaleString("en-IN")}</span></div>
      ${order.servicesSubtotal ? `<div class="line"><span>Installation & setup</span><span>${"₹" + Math.round(order.servicesSubtotal).toLocaleString("en-IN")}</span></div>` : ''}
      <div class="line"><span>Shipping</span><span>${order.shipping === 0 ? "Complimentary" : "₹" + Math.round(order.shipping).toLocaleString("en-IN")}</span></div>
      <div class="line"><span>GST (18%)</span><span>${"₹" + Math.round(order.tax).toLocaleString("en-IN")}</span></div>
      <div class="line total"><span>Total paid</span><span>${"₹" + Math.round(order.total).toLocaleString("en-IN")}</span></div>
    </div>

    <div class="inv-foot">
      <span class="cursive">With our thanks.</span>
      Electro Hub — Made by hand · Made to last · contact@electrohub.example
    </div>
  `;
}

window.renderInvoice = renderInvoice;
