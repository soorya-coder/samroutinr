/* ===================================================================
   ElectroHub — cart.js
   Cart, wishlist, checkout, invoice.
   =================================================================== */

(function () {
  'use strict';

  const Cart = {};
  window.EHCart = Cart;

  Cart.add = function (productId, qty) {
    qty = qty || 1;
    const cart = EH.getCart();
    const existing = cart.find(i => i.id === productId);
    if (existing) existing.qty += qty;
    else cart.push({ id: productId, qty });
    EH.saveCart(cart);
    EH.toast('Added to cart');
  };

  Cart.remove = function (productId) {
    EH.saveCart(EH.getCart().filter(i => i.id !== productId));
    EH.toast('Removed from cart');
  };

  Cart.setQty = function (productId, qty) {
    qty = Math.max(1, Math.min(99, parseInt(qty, 10) || 1));
    const cart = EH.getCart();
    const item = cart.find(i => i.id === productId);
    if (item) { item.qty = qty; EH.saveCart(cart); }
  };

  Cart.totals = function (promo) {
    const cart = EH.getCart();
    let subtotal = 0;
    cart.forEach(i => {
      const p = EH.findProduct(i.id);
      if (p) subtotal += p.price * i.qty;
    });
    let discount = 0;
    if (promo) {
      if (promo === 'WELCOME10') discount = subtotal * 0.10;
      else if (promo === 'NOVA20') discount = subtotal * 0.20;
    }
    const shipping = subtotal > 0 ? (subtotal >= 49999 ? 0 : 99) : 0;
    const tax = (subtotal - discount) * 0.18; // 18% GST
    const total = subtotal - discount + shipping + tax;
    return { subtotal, discount, shipping, tax, total };
  };

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  /* ---------- CART PAGE ---------- */
  function initCartPage() {
    const root = document.getElementById('cartPage');
    if (!root) return;
    if (!EH.getUser()) {
      EH.renderAuthRequired(root, 'Sign in to view your cart', 'Your cart is saved to your account. Please sign in to continue.');
      return;
    }

    let activePromo = null;

    function render() {
      const cart = EH.getCart();
      if (!cart.length) {
        root.innerHTML = `
          <div class="empty-state">
            <div class="icon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/></svg></div>
            <h3>Your cart is empty</h3>
            <p>Discover our latest products and start shopping.</p>
            <a href="products.html" class="btn btn-primary" style="margin-top:16px;">Shop now</a>
          </div>`;
        return;
      }

      const t = Cart.totals(activePromo);

      root.innerHTML = `
        <div class="cart-layout">
          <div class="cart-list">
            ${cart.map(item => {
              const p = EH.findProduct(item.id);
              if (!p) return '';
              return `
                <div class="cart-item" data-id="${p.id}">
                  <div class="ci-image"><img src="${EH.path(p.image)}" alt=""/></div>
                  <div>
                    <div class="ci-brand">${escapeHtml(p.brand)}</div>
                    <a href="product-details.html?id=${p.id}" class="ci-name">${escapeHtml(p.name)}</a>
                    <div class="ci-price">${EH.formatPrice(p.price)}</div>
                  </div>
                  <div class="ci-controls">
                    <div class="qty-stepper">
                      <button data-q="-" data-id="${p.id}">−</button>
                      <span class="qty">${item.qty}</span>
                      <button data-q="+" data-id="${p.id}">+</button>
                    </div>
                    <button class="ci-remove" data-remove="${p.id}">Remove</button>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
          <aside class="summary">
            <h3>Order Summary</h3>
            <div class="line"><span>Subtotal</span><span class="tabular">${EH.formatPrice(t.subtotal)}</span></div>
            ${t.discount ? `<div class="line"><span>Discount</span><span class="tabular" style="color:var(--color-success);">−${EH.formatPrice(t.discount)}</span></div>` : ''}
            <div class="line"><span>Shipping</span><span class="tabular">${t.shipping === 0 ? 'Free' : EH.formatPrice(t.shipping)}</span></div>
            <div class="line"><span>GST (18%)</span><span class="tabular">${EH.formatPrice(t.tax)}</span></div>
            <div class="line total"><span>Total</span><span class="tabular">${EH.formatPrice(t.total)}</span></div>
            <a href="checkout.html" class="btn btn-primary btn-block btn-lg">Checkout</a>
            <a href="products.html" class="btn btn-ghost btn-block" style="margin-top:8px;">Continue shopping</a>
            <div class="promo-row">
              <input type="text" id="promoInp" placeholder="Promo code (try WELCOME10)"/>
              <button class="btn btn-secondary btn-sm" id="promoApply">Apply</button>
            </div>
          </aside>
        </div>
      `;

      // Wire actions
      root.querySelectorAll('[data-q]').forEach(btn => btn.addEventListener('click', () => {
        const cart = EH.getCart();
        const item = cart.find(i => i.id === btn.dataset.id);
        if (!item) return;
        item.qty = btn.dataset.q === '+' ? Math.min(99, item.qty + 1) : Math.max(1, item.qty - 1);
        EH.saveCart(cart); render();
      }));
      root.querySelectorAll('[data-remove]').forEach(b => b.addEventListener('click', () => {
        Cart.remove(b.dataset.remove); render();
      }));
      document.getElementById('promoApply')?.addEventListener('click', () => {
        const v = document.getElementById('promoInp').value.trim().toUpperCase();
        if (v === 'WELCOME10' || v === 'NOVA20') {
          activePromo = v;
          EH.toast('Promo applied!', 'success');
        } else {
          EH.toast('Invalid promo code.', 'error');
          activePromo = null;
        }
        render();
      });
    }
    render();
  }

  /* ---------- WISHLIST PAGE ---------- */
  function initWishlistPage() {
    const root = document.getElementById('wishlistPage');
    if (!root) return;
    if (!EH.getUser()) {
      EH.renderAuthRequired(root, 'Sign in to view your wishlist', 'Save items you love and revisit them anytime — once you sign in.');
      return;
    }

    function render() {
      const ids = EH.getWishlist();
      if (!ids.length) {
        root.innerHTML = `
          <div class="empty-state">
            <div class="icon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z"/></svg></div>
            <h3>Your wishlist is empty</h3>
            <p>Save items you love by tapping the heart icon.</p>
            <a href="products.html" class="btn btn-primary" style="margin-top:16px;">Browse products</a>
          </div>`;
        return;
      }
      const items = ids.map(id => EH.findProduct(id)).filter(Boolean);
      root.innerHTML = `<div class="wishlist-grid">${items.map(p => EH.productCardHTML(p)).join('')}</div>`;
    }

    // Re-render only when a wishlist heart is toggled
    root.addEventListener('click', (e) => {
      if (e.target.closest('[data-wish]')) setTimeout(render, 20);
    });
    render();
  }

  /* ---------- CHECKOUT PAGE ---------- */
  function initCheckoutPage() {
    const root = document.getElementById('checkoutPage');
    if (!root) return;
    if (!EH.getUser()) {
      EH.renderAuthRequired(root, 'Sign in to checkout', 'Please sign in to complete your purchase securely.');
      return;
    }

    const cart = EH.getCart();
    if (!cart.length) {
      root.innerHTML = `<div class="empty-state"><h3>Nothing to checkout</h3><p>Add items to your cart first.</p><a href="products.html" class="btn btn-primary" style="margin-top:16px;">Shop now</a></div>`;
      return;
    }

    const t = Cart.totals();

    root.innerHTML = `
      <form id="checkoutForm" class="form" novalidate style="display:contents;">
        <div class="checkout-layout">
          <div>
            <div class="checkout-section">
              <h3>Contact</h3>
              <div class="field-row">
                <div class="field">
                  <label>Full name</label>
                  <input type="text" name="fullName" data-validate="name" required/>
                  <div class="error"></div>
                </div>
                <div class="field">
                  <label>Email</label>
                  <input type="email" name="email" data-validate="email" required/>
                  <div class="error"></div>
                </div>
              </div>
              <div class="field">
                <label>Phone</label>
                <input type="tel" name="phone" data-validate="phone" required/>
                <div class="error"></div>
              </div>
            </div>

            <div class="checkout-section">
              <h3>Shipping address</h3>
              <div class="field">
                <label>Street address</label>
                <input type="text" name="addr" data-validate="address" required/>
                <div class="error"></div>
              </div>
              <div class="field-row-3">
                <div class="field">
                  <label>City</label>
                  <input type="text" name="city" data-validate="required-text" required/>
                  <div class="error"></div>
                </div>
                <div class="field">
                  <label>State</label>
                  <input type="text" name="state" data-validate="required-text" required/>
                  <div class="error"></div>
                </div>
                <div class="field">
                  <label>PIN code</label>
                  <input type="text" name="pin" data-validate="pin" required inputmode="numeric" maxlength="6"/>
                  <div class="error"></div>
                </div>
              </div>
              <div class="field">
                <label>Preferred delivery date</label>
                <input type="date" name="deliveryDate" data-validate="date-future" required/>
                <div class="error"></div>
              </div>
            </div>

            <div class="checkout-section">
              <h3>Payment method</h3>
              <div class="pay-methods" id="payMethods">
                <div class="pay-method active" data-pay="card"><div class="icon">💳</div><div class="label">Card</div><div class="sub">Credit / Debit</div></div>
                <div class="pay-method" data-pay="upi"><div class="icon">📱</div><div class="label">UPI</div><div class="sub">Instant payment</div></div>
                <div class="pay-method" data-pay="cod"><div class="icon">💵</div><div class="label">Cash on Delivery</div><div class="sub">Pay when delivered</div></div>
              </div>

              <div class="pay-form active" data-pay-form="card">
                <div class="field">
                  <label>Card number</label>
                  <input type="text" name="cardNumber" data-validate="card" data-format="card" placeholder="1234 5678 9012 3456" inputmode="numeric" autocomplete="cc-number"/>
                  <div class="error"></div>
                </div>
                <div class="field">
                  <label>Cardholder name</label>
                  <input type="text" name="cardName" data-validate="name"/>
                  <div class="error"></div>
                </div>
                <div class="field-row">
                  <div class="field">
                    <label>Expiry (MM/YY)</label>
                    <input type="text" name="cardExpiry" data-validate="expiry" data-format="expiry" placeholder="MM/YY" maxlength="5"/>
                    <div class="error"></div>
                  </div>
                  <div class="field">
                    <label>CVV</label>
                    <input type="password" name="cardCvv" data-validate="cvv" maxlength="4" inputmode="numeric" placeholder="123"/>
                    <div class="error"></div>
                  </div>
                </div>
              </div>

              <div class="pay-form" data-pay-form="upi">
                <div class="field">
                  <label>UPI ID</label>
                  <input type="text" name="upiId" data-validate="upi" placeholder="yourname@bank"/>
                  <div class="error"></div>
                </div>
                <p class="muted small">You will receive a payment request on your UPI app.</p>
              </div>

              <div class="pay-form" data-pay-form="cod">
                <p class="muted small">Pay in cash when your order arrives. An additional ${EH.formatPrice(49)} COD handling fee applies.</p>
              </div>
            </div>
          </div>

          <aside class="summary">
            <h3>Order summary</h3>
            ${cart.map(it => {
              const p = EH.findProduct(it.id);
              if (!p) return '';
              return `<div class="line"><span>${escapeHtml(p.name)} × ${it.qty}</span><span class="tabular">${EH.formatPrice(p.price * it.qty)}</span></div>`;
            }).join('')}
            <div class="line"><span>Subtotal</span><span class="tabular">${EH.formatPrice(t.subtotal)}</span></div>
            <div class="line"><span>Shipping</span><span class="tabular">${t.shipping === 0 ? 'Free' : EH.formatPrice(t.shipping)}</span></div>
            <div class="line"><span>GST (18%)</span><span class="tabular">${EH.formatPrice(t.tax)}</span></div>
            <div class="line total"><span>Total</span><span class="tabular" id="grandTotal">${EH.formatPrice(t.total)}</span></div>
            <button class="btn btn-primary btn-block btn-lg" type="submit" data-submit>Place Order</button>
            <p class="muted small text-center" style="margin-top:8px;">Secure checkout. SSL encrypted.</p>
          </aside>
        </div>
      </form>
    `;

    const form = document.getElementById('checkoutForm');
    const dateInp = form.querySelector('input[name="deliveryDate"]');
    if (dateInp) dateInp.min = new Date().toISOString().split('T')[0];

    let selectedPay = 'card';
    document.querySelectorAll('.pay-method').forEach(pm => pm.addEventListener('click', () => {
      document.querySelectorAll('.pay-method').forEach(x => x.classList.remove('active'));
      pm.classList.add('active');
      selectedPay = pm.dataset.pay;
      document.querySelectorAll('.pay-form').forEach(f => f.classList.remove('active'));
      document.querySelector(`[data-pay-form="${selectedPay}"]`).classList.add('active');
      // Update grand total for COD fee
      const totals = Cart.totals();
      const codFee = selectedPay === 'cod' ? 49 : 0;
      document.getElementById('grandTotal').textContent = EH.formatPrice(totals.total + codFee);
    }));

    EHValidate.bind(form);

    form.addEventListener('submit', (e) => {
      e.preventDefault();

      // Validate base fields
      let baseFields = ['fullName', 'email', 'phone', 'addr', 'city', 'state', 'pin', 'deliveryDate'];
      let ok = true;
      baseFields.forEach(n => {
        const inp = form[n];
        if (!inp) return;
        const f = inp.closest('.field');
        // trigger blur to validate
        inp.dispatchEvent(new Event('blur'));
        if (f && f.classList.contains('error')) ok = false;
      });

      // Validate payment-specific fields
      if (selectedPay === 'card') {
        ['cardNumber', 'cardName', 'cardExpiry', 'cardCvv'].forEach(n => {
          const inp = form[n];
          inp.required = true;
          inp.dispatchEvent(new Event('blur'));
          if (inp.closest('.field').classList.contains('error') || !inp.value) ok = false;
        });
      } else if (selectedPay === 'upi') {
        const inp = form.upiId;
        inp.required = true;
        inp.dispatchEvent(new Event('blur'));
        if (inp.closest('.field').classList.contains('error') || !inp.value) ok = false;
      }

      if (!ok) {
        EH.toast('Please correct the highlighted fields.', 'error');
        return;
      }

      // Create order
      const totals = Cart.totals();
      const codFee = selectedPay === 'cod' ? 49 : 0;
      const order = {
        id: 'EH-' + Date.now().toString().slice(-8),
        date: new Date().toISOString(),
        items: EH.getCart().map(it => {
          const p = EH.findProduct(it.id);
          return { id: it.id, name: p?.name, brand: p?.brand, price: p?.price, qty: it.qty };
        }),
        customer: {
          name: form.fullName.value.trim(),
          email: form.email.value.trim(),
          phone: form.phone.value.trim(),
          address: form.addr.value.trim() + ', ' + form.city.value.trim() + ', ' + form.state.value.trim() + ' ' + form.pin.value.trim()
        },
        delivery: form.deliveryDate.value,
        payment: selectedPay,
        totals: { ...totals, codFee, total: totals.total + codFee },
        status: 'Confirmed'
      };
      EH.addOrder(order);
      EH.SessionStore.set('eh_lastOrder', order);
      EH.saveCart([]); // clear cart
      EH.toast('Order placed successfully!', 'success');
      setTimeout(() => location.href = 'invoice.html?id=' + order.id, 700);
    });
  }

  /* ---------- INVOICE PAGE ---------- */
  function initInvoicePage() {
    const root = document.getElementById('invoicePage');
    if (!root) return;
    if (!EH.getUser()) {
      root.innerHTML = '<div class="container"><div id="ehAuthMount"></div></div>';
      EH.renderAuthRequired(document.getElementById('ehAuthMount'), 'Sign in to view your invoice', 'Your order history is tied to your account. Please sign in.');
      return;
    }

    const idParam = new URLSearchParams(location.search).get('id');
    const orders = EH.getOrders();
    const order = idParam ? orders.find(o => o.id === idParam) : (EH.SessionStore.get('eh_lastOrder', null) || orders[0]);

    if (!order) {
      root.innerHTML = `<div class="empty-state"><h3>No invoice found</h3><p>You haven't placed any orders yet.</p><a href="products.html" class="btn btn-primary" style="margin-top:16px;">Start shopping</a></div>`;
      return;
    }

    const d = new Date(order.date);
    const dateStr = d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    const delivDate = order.delivery ? new Date(order.delivery).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) : '—';

    root.innerHTML = `
      <div class="container">
        <div class="empty-state" style="padding:32px 0 16px;">
          <div class="icon" style="background:var(--color-success-soft);color:var(--color-success);">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
          </div>
          <h3>Order confirmed</h3>
          <p>Thank you for your purchase, ${escapeHtml(order.customer.name.split(' ')[0])}. A confirmation has been sent to ${escapeHtml(order.customer.email)}.</p>
        </div>

        <div class="invoice-card">
          <div class="invoice-head">
            <div class="from">
              <div class="brand-name" style="font-family:'Dancing Script','Brush Script MT',cursive;font-size:26px;font-weight:700;">ElectroHub</div>
              <div class="muted small">ElectroHub Pvt. Ltd.<br/>14th Floor, Prestige Technostar, MG Road<br/>Bengaluru, Karnataka 560048<br/>support@electrohub.in · +91 1800-123-4567<br/>GSTIN: 29AABCE1234F1Z5</div>
            </div>
            <div class="meta">
              <div class="num">Invoice #${escapeHtml(order.id)}</div>
              <div>Date: ${dateStr}</div>
              <div>Status: <span class="status-pill ok">${escapeHtml(order.status)}</span></div>
            </div>
          </div>

          <div class="invoice-parties">
            <div>
              <h5>Billed to</h5>
              <div class="who">
                <strong>${escapeHtml(order.customer.name)}</strong><br/>
                ${escapeHtml(order.customer.address)}<br/>
                ${escapeHtml(order.customer.email)} · ${escapeHtml(order.customer.phone)}
              </div>
            </div>
            <div>
              <h5>Delivery</h5>
              <div class="who">
                Expected: <strong>${delivDate}</strong><br/>
                Method: Standard delivery<br/>
                Payment: ${escapeHtml((order.payment || '').toUpperCase())}
              </div>
            </div>
          </div>

          <table class="invoice-table">
            <thead>
              <tr><th>Item</th><th class="num">Qty</th><th class="num">Price</th><th class="num">Total</th></tr>
            </thead>
            <tbody>
              ${order.items.map(it => `
                <tr>
                  <td><strong>${escapeHtml(it.name || '')}</strong><br/><span class="muted small">${escapeHtml(it.brand || '')}</span></td>
                  <td class="num">${it.qty}</td>
                  <td class="num">${EH.formatPrice(it.price)}</td>
                  <td class="num">${EH.formatPrice(it.price * it.qty)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>

          <div class="invoice-totals">
            <div class="row"><span>Subtotal</span><span class="tabular">${EH.formatPrice(order.totals.subtotal)}</span></div>
            <div class="row"><span>Shipping</span><span class="tabular">${order.totals.shipping === 0 ? 'Free' : EH.formatPrice(order.totals.shipping)}</span></div>
            <div class="row"><span>GST (18%)</span><span class="tabular">${EH.formatPrice(order.totals.tax)}</span></div>
            ${order.totals.codFee ? `<div class="row"><span>COD fee</span><span class="tabular">${EH.formatPrice(order.totals.codFee)}</span></div>` : ''}
            <div class="row total"><span>Total</span><span class="tabular">${EH.formatPrice(order.totals.total)}</span></div>
          </div>

          <div class="invoice-footer">
            Thank you for shopping with ElectroHub. This is a computer-generated invoice. For support, contact support@electrohub.in or call +91 1800-123-4567.
          </div>
        </div>

        <div class="row no-print" style="justify-content:center; gap:10px; margin-bottom:48px;">
          <button class="btn btn-primary" onclick="window.print()">Print invoice</button>
          <a href="products.html" class="btn btn-outline">Continue shopping</a>
        </div>
      </div>
    `;
  }

  /* ---------- Init ---------- */
  document.addEventListener('DOMContentLoaded', () => {
    initCartPage();
    initWishlistPage();
    initCheckoutPage();
    initInvoicePage();
  });
})();
