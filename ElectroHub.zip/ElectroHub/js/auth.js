/* ===================================================================
   ElectroHub — auth.js
   Login + Register (frontend-only, localStorage).
   =================================================================== */

(function () {
  'use strict';

  function getUsers() { return EH.Store.get('eh_users', null) || seedUsers(); }
  function saveUsers(u) { EH.Store.set('eh_users', u); }

  function seedUsers() {
    const seeded = [
      { email: 'admin@electrohub.com', password: 'Admin@123', name: 'Admin User', role: 'admin', phone: '5550100001' },
      { email: 'seller@electrohub.com', password: 'Seller@123', name: 'Nova Direct', role: 'seller', phone: '5550100002' },
      { email: 'demo@electrohub.com', password: 'Demo@1234', name: 'Demo Customer', role: 'customer', phone: '5550100003' }
    ];
    EH.Store.set('eh_users', seeded);
    return seeded;
  }

  /* ---------- LOGIN ---------- */
  function initLogin() {
    const form = document.getElementById('loginForm');
    if (!form) return;

    EHValidate.bind(form);

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!EHValidate.validateAll(form)) {
        EH.toast('Please fix the errors above.', 'error');
        return;
      }
      const email = form.email.value.trim().toLowerCase();
      const password = form.password.value;
      const users = getUsers();
      const match = users.find(u => u.email.toLowerCase() === email && u.password === password);
      if (!match) {
        EH.toast('Invalid email or password.', 'error');
        EHValidate.showError(form.password, 'Email or password is incorrect.');
        return;
      }
      EH.setUser({ email: match.email, name: match.name, role: match.role });
      EH.toast('Welcome back, ' + match.name.split(' ')[0] + '!', 'success');
      const redirect = (() => { try { return sessionStorage.getItem('eh_redirect'); } catch (e) { return null; } })();
      try { sessionStorage.removeItem('eh_redirect'); } catch (e) {}
      setTimeout(() => {
        if (redirect) { location.href = redirect; return; }
        if (match.role === 'admin') location.href = 'admin-dashboard.html';
        else if (match.role === 'seller') location.href = 'seller-dashboard.html';
        else location.href = '../index.html';
      }, 700);
    });
  }

  /* ---------- REGISTER ---------- */
  function initRegister() {
    const form = document.getElementById('registerForm');
    if (!form) return;

    EHValidate.bind(form);

    // Password strength meter
    const pw = form.password;
    const meter = document.getElementById('pwMeter');
    const label = document.getElementById('pwLabel');
    if (pw && meter) EHValidate.bindPasswordMeter(pw, meter, label);

    // Role picker
    const rolePicks = form.querySelectorAll('.role-pick');
    rolePicks.forEach(p => p.addEventListener('click', () => {
      rolePicks.forEach(x => x.classList.remove('active'));
      p.classList.add('active');
      form.dataset.role = p.dataset.role;
    }));

    // Birth date max = today
    const dob = form.dob;
    if (dob) dob.max = new Date().toISOString().split('T')[0];

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!EHValidate.validateAll(form)) {
        EH.toast('Please fix the errors above.', 'error');
        return;
      }
      const email = form.email.value.trim().toLowerCase();
      const users = getUsers();
      if (users.find(u => u.email.toLowerCase() === email)) {
        EHValidate.showError(form.email, 'This email is already registered.');
        EH.toast('Email already registered.', 'error');
        return;
      }
      const newUser = {
        email,
        password: form.password.value,
        name: form.fullName.value.trim(),
        phone: form.phone.value.trim(),
        dob: form.dob.value,
        role: form.dataset.role || 'customer'
      };
      users.push(newUser);
      saveUsers(users);
      EH.setUser({ email: newUser.email, name: newUser.name, role: newUser.role });
      EH.toast('Account created. Welcome to ElectroHub!', 'success');
      const redirect = (() => { try { return sessionStorage.getItem('eh_redirect'); } catch (e) { return null; } })();
      try { sessionStorage.removeItem('eh_redirect'); } catch (e) {}
      setTimeout(() => {
        if (redirect) { location.href = redirect; return; }
        if (newUser.role === 'admin') location.href = 'admin-dashboard.html';
        else if (newUser.role === 'seller') location.href = 'seller-dashboard.html';
        else location.href = '../index.html';
      }, 700);
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    getUsers(); // seed
    initLogin();
    initRegister();
  });
})();
