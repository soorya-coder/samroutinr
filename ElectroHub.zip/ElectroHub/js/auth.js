/* ===================================================================
   ElectroHub — auth.js
   Login + Register (frontend-only, localStorage).
   =================================================================== */

(function () {
  'use strict';

  function getUsers() { return EH.Store.get('eh_users', null) || seedUsers(); }
  function saveUsers(u) { EH.Store.set('eh_users', u); }

  function seedUsers() {
    const now = Date.now();
    const seeded = [
      { email: 'admin@electrohub.com', password: 'Admin@123', name: 'Admin User', role: 'admin', phone: '9876500001', status: 'approved', joinedAt: new Date(now - 90 * 24 * 3600 * 1000).toISOString() },
      { email: 'seller@electrohub.com', password: 'Seller@123', name: 'Nova Direct', role: 'seller', phone: '9876500002', status: 'approved', joinedAt: new Date(now - 60 * 24 * 3600 * 1000).toISOString() },
      { email: 'demo@electrohub.com', password: 'Demo@1234', name: 'Demo Customer', role: 'customer', phone: '9876500003', status: 'approved', joinedAt: new Date(now - 30 * 24 * 3600 * 1000).toISOString() },
      // Two sample pending sellers so the admin's approval queue is dynamic & populated
      { email: 'aurora@example.com', password: 'Aurora@123', name: 'Aurora Tech', role: 'seller', phone: '9876500004', status: 'pending', joinedAt: new Date(now - 2 * 3600 * 1000).toISOString(), appliedAt: new Date(now - 2 * 3600 * 1000).toISOString() },
      { email: 'hello@pixelgear.io', password: 'Pixel@123', name: 'PixelGear', role: 'seller', phone: '9876500005', status: 'pending', joinedAt: new Date(now - 1 * 24 * 3600 * 1000).toISOString(), appliedAt: new Date(now - 1 * 24 * 3600 * 1000).toISOString() }
    ];
    EH.Store.set('eh_users', seeded);
    return seeded;
  }

  /* ---------- LOGIN ---------- */
  function initLogin() {
    const form = document.getElementById('loginForm');
    if (!form) return;

    EHValidate.bind(form);

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!EHValidate.validateAll(form)) {
        EH.toast('Please fix the errors above.', 'error');
        return;
      }
      const email = form.email.value.trim().toLowerCase();
      const password = form.password.value;
      const users = getUsers();
      const match = users.find(u => u.email.toLowerCase() === email && u.password === password);
      if (!match) {
        EH.toast('Invalid email or password.', 'error');
        EHValidate.showError(form.password, 'Email or password is incorrect.');
        return;
      }
      EH.setUser({ email: match.email, name: match.name, role: match.role, status: match.status || 'approved' });
      EH.toast('Welcome back, ' + match.name.split(' ')[0] + '!', 'success');
      const redirect = (() => { try { return sessionStorage.getItem('eh_redirect'); } catch (e) { return null; } })();
      try { sessionStorage.removeItem('eh_redirect'); } catch (e) {}
      setTimeout(() => {
        if (redirect) { location.href = redirect; return; }
        if (match.role === 'admin') location.href = 'admin-dashboard.html';
        else if (match.role === 'seller') location.href = 'seller-dashboard.html';
        else location.href = '../index.html';
      }, 700);
    });
  }

  /* ---------- REGISTER ---------- */
  function initRegister() {
    const form = document.getElementById('registerForm');
    if (!form) return;

    EHValidate.bind(form);

    // Password strength meter
    const pw = form.password;
    const meter = document.getElementById('pwMeter');
    const label = document.getElementById('pwLabel');
    if (pw && meter) EHValidate.bindPasswordMeter(pw, meter, label);

    // Role picker
    const rolePicks = form.querySelectorAll('.role-pick');
    rolePicks.forEach(p => p.addEventListener('click', () => {
      rolePicks.forEach(x => x.classList.remove('active'));
      p.classList.add('active');
      form.dataset.role = p.dataset.role;
    }));

    // Birth date max = today
    const dob = form.dob;
    if (dob) dob.max = new Date().toISOString().split('T')[0];

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!EHValidate.validateAll(form)) {
        EH.toast('Please fix the errors above.', 'error');
        return;
      }
      const email = form.email.value.trim().toLowerCase();
      const users = getUsers();
      if (users.find(u => u.email.toLowerCase() === email)) {
        EHValidate.showError(form.email, 'This email is already registered.');
        EH.toast('Email already registered.', 'error');
        return;
      }
      const role = form.dataset.role || 'customer';
      const nowISO = new Date().toISOString();
      const newUser = {
        email,
        password: form.password.value,
        name: form.fullName.value.trim(),
        phone: form.phone.value.trim(),
        dob: form.dob.value,
        role,
        // Sellers need admin approval; customers and admin are auto-approved
        status: (role === 'seller') ? 'pending' : 'approved',
        joinedAt: nowISO,
        appliedAt: (role === 'seller') ? nowISO : null
      };
      users.push(newUser);
      saveUsers(users);
      EH.setUser({ email: newUser.email, name: newUser.name, role: newUser.role, status: newUser.status });
      if (newUser.status === 'pending') {
        EH.toast('Seller account created — awaiting admin approval', 'success');
      } else {
        EH.toast('Account created. Welcome to ElectroHub!', 'success');
      }
      const redirect = (() => { try { return sessionStorage.getItem('eh_redirect'); } catch (e) { return null; } })();
      try { sessionStorage.removeItem('eh_redirect'); } catch (e) {}
      setTimeout(() => {
        if (redirect) { location.href = redirect; return; }
        if (newUser.role === 'admin') location.href = 'admin-dashboard.html';
        else if (newUser.role === 'seller') location.href = 'seller-dashboard.html';
        else location.href = '../index.html';
      }, 900);
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    getUsers(); // seed
    initLogin();
    initRegister();
  });
})();
