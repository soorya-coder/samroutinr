/* ===================================================================
   ElectroHub — dashboard.js
   Seller + Admin dashboards. Product CRUD, user mgmt, analytics.
   =================================================================== */

(function () {
  'use strict';

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function getUsers() { return EH.Store.get('eh_users', []); }
  function saveUsers(u) { EH.Store.set('eh_users', u); }

  /* ---------- SELLER DASHBOARD ---------- */
  function initSellerDashboard() {
    const root = document.getElementById('sellerDash');
    if (!root) return;
    const user = EH.getUser();
    if (!user) {
      EH.renderAuthRequired(root, 'Sign in to access the seller dashboard', 'This area is for seller accounts only.');
      return;
    }
    if (user.role !== 'seller' && user.role !== 'admin') {
      EH.renderAuthRequired(root, 'Seller account required', 'Sign in with a seller account to access this dashboard.');
      return;
    }

    let activeTab = 'overview';

    const stats = () => {
      const products = EH.getProducts();
      const orders = EH.getOrders();
      const totalSales = orders.reduce((s, o) => s + (o.totals?.total || 0), 0);
      return {
        revenue: totalSales,
        products: products.length,
        orders: orders.length,
        avg: orders.length ? totalSales / orders.length : 0
      };
    };

    function render() {
      const s = stats();
      const products = EH.getProducts();
      const orders = EH.getOrders();
      const user = EH.getUser();

      root.innerHTML = `
        <div class="dash-layout">
          <aside class="dash-side">
            <div class="who">
              <div class="name">${user ? escapeHtml(user.name) : 'Demo Seller'}</div>
              <div class="role">Seller</div>
            </div>
            <nav class="dash-nav">
              <a href="#overview" data-tab="overview" class="${activeTab==='overview'?'active':''}">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                Overview
              </a>
              <a href="#products" data-tab="products" class="${activeTab==='products'?'active':''}">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/></svg>
                Products
              </a>
              <a href="#orders" data-tab="orders" class="${activeTab==='orders'?'active':''}">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/></svg>
                Orders
              </a>
              <a href="#analytics" data-tab="analytics" class="${activeTab==='analytics'?'active':''}">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
                Analytics
              </a>
            </nav>
          </aside>

          <div class="dash-main">
            ${activeTab === 'overview' ? `
              <div class="stat-grid">
                <div class="stat-card"><div class="label">Revenue</div><div class="value">${EH.formatPrice(s.revenue)}</div><div class="delta up">▲ 12.4% vs last month</div></div>
                <div class="stat-card"><div class="label">Orders</div><div class="value">${s.orders}</div><div class="delta up">▲ 8.1%</div></div>
                <div class="stat-card"><div class="label">Products</div><div class="value">${s.products}</div><div class="delta muted">Live in store</div></div>
                <div class="stat-card"><div class="label">Avg. Order</div><div class="value">${EH.formatPrice(s.avg)}</div><div class="delta up">▲ 3.2%</div></div>
              </div>
              <div class="dash-panel">
                <div class="panel-head"><h3>Recent orders</h3><a href="#orders" data-tab="orders" class="btn btn-sm btn-ghost">View all</a></div>
                ${renderOrdersTable(orders.slice(0, 5))}
              </div>
              <div class="dash-panel">
                <div class="panel-head"><h3>Top products</h3></div>
                ${renderProductsTable(products.slice(0, 5), true)}
              </div>
            ` : ''}

            ${activeTab === 'products' ? `
              <div class="dash-panel">
                <div class="panel-head">
                  <h3>Product catalog</h3>
                  <button class="btn btn-primary btn-sm" id="addProductBtn">+ Add Product</button>
                </div>
                ${renderProductsTable(products, false)}
              </div>
              <div id="productFormPanel" class="dash-panel hidden"></div>
            ` : ''}

            ${activeTab === 'orders' ? `
              <div class="dash-panel">
                <div class="panel-head"><h3>All orders</h3></div>
                ${orders.length ? renderOrdersTable(orders) : '<p class="muted">No orders yet.</p>'}
              </div>
            ` : ''}

            ${activeTab === 'analytics' ? `
              <div class="stat-grid">
                <div class="stat-card"><div class="label">This week</div><div class="value">${EH.formatPrice(s.revenue * 0.28)}</div><div class="delta up">▲ 14%</div></div>
                <div class="stat-card"><div class="label">Conversion</div><div class="value">3.4%</div><div class="delta up">▲ 0.4%</div></div>
                <div class="stat-card"><div class="label">Returning</div><div class="value">42%</div><div class="delta up">▲ 2%</div></div>
                <div class="stat-card"><div class="label">Refund rate</div><div class="value">1.2%</div><div class="delta down">▼ 0.3%</div></div>
              </div>
              <div class="dash-panel">
                <div class="panel-head"><h3>Sales by month</h3></div>
                <div class="bars">
                  ${['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'].map((m, i) => {
                    const h = 30 + (Math.sin(i) + 1) * 60 + (i * 3);
                    return `<div class="bar" style="height:${h}px;"><span>${m}</span></div>`;
                  }).join('')}
                </div>
                <div style="margin-top:32px; padding-top:16px;"></div>
              </div>
              <div class="dash-panel">
                <div class="panel-head"><h3>Category mix</h3></div>
                <div style="display:grid; grid-template-columns:repeat(2,1fr); gap:14px;">
                  ${['Laptops 32%','Phones 28%','Audio 18%','Wearables 12%','Tablets 6%','Other 4%'].map(c => {
                    const [n, pct] = c.split(' ');
                    const p = parseInt(pct);
                    return `
                      <div>
                        <div class="row" style="justify-content:space-between; font-size:13px; margin-bottom:6px;"><span>${n}</span><span class="muted">${pct}</span></div>
                        <div style="background:var(--color-line-soft); height:6px; border-radius:999px; overflow:hidden;"><div style="background:var(--color-ink); width:${p}%; height:100%;"></div></div>
                      </div>`;
                  }).join('')}
                </div>
              </div>
            ` : ''}
          </div>
        </div>
      `;

      // Tab nav
      root.querySelectorAll('[data-tab]').forEach(a => a.addEventListener('click', (e) => {
        e.preventDefault();
        activeTab = a.dataset.tab;
        render();
      }));

      // Product actions
      root.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => openProductForm(b.dataset.edit)));
      root.querySelectorAll('[data-delete]').forEach(b => b.addEventListener('click', () => {
        if (!confirm('Delete this product?')) return;
        const list = EH.getProducts().filter(p => p.id !== b.dataset.delete);
        EH.saveProducts(list);
        EH.toast('Product deleted');
        render();
      }));
      document.getElementById('addProductBtn')?.addEventListener('click', () => openProductForm(null));
    }

    function renderProductsTable(products, simple) {
      return `
        <table class="table">
          <thead>
            <tr><th></th><th>Name</th><th>Brand</th><th>Category</th><th>Price</th><th>Stock</th>${simple ? '' : '<th>Actions</th>'}</tr>
          </thead>
          <tbody>
            ${products.map(p => `
              <tr>
                <td><div class="thumb"><img src="${EH.path(p.image)}" alt=""/></div></td>
                <td>${escapeHtml(p.name)}</td>
                <td>${escapeHtml(p.brand)}</td>
                <td>${escapeHtml(p.category)}</td>
                <td class="tabular">${EH.formatPrice(p.price)}</td>
                <td>${p.stock < 20 ? '<span class="status-pill pending">Low</span>' : '<span class="status-pill ok">In stock</span>'} ${p.stock}</td>
                ${simple ? '' : `<td><div class="row-actions">
                  <button class="btn btn-sm btn-ghost" data-edit="${p.id}">Edit</button>
                  <button class="btn btn-sm btn-ghost" data-delete="${p.id}" style="color:var(--color-danger);">Delete</button>
                </div></td>`}
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    }

    function renderOrdersTable(orders) {
      if (!orders.length) return '<p class="muted">No orders yet.</p>';
      return `
        <table class="table">
          <thead><tr><th>Order ID</th><th>Customer</th><th>Items</th><th>Total</th><th>Status</th><th>Date</th></tr></thead>
          <tbody>
            ${orders.map(o => `
              <tr>
                <td><strong>${escapeHtml(o.id)}</strong></td>
                <td>${escapeHtml(o.customer?.name || '')}</td>
                <td>${o.items?.length || 0}</td>
                <td class="tabular">${EH.formatPrice(o.totals?.total || 0)}</td>
                <td><span class="status-pill ok">${escapeHtml(o.status || '')}</span></td>
                <td>${new Date(o.date).toLocaleDateString()}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    }

    function openProductForm(id) {
      const panel = document.getElementById('productFormPanel');
      const p = id ? EH.findProduct(id) : null;
      const isEdit = !!p;

      panel.classList.remove('hidden');
      panel.innerHTML = `
        <div class="panel-head"><h3>${isEdit ? 'Edit product' : 'New product'}</h3><button class="btn btn-sm btn-ghost" id="closeForm">Cancel</button></div>
        <form id="prodForm" class="form" novalidate>
          <div class="field-row">
            <div class="field">
              <label>Name</label>
              <input name="name" type="text" data-validate="required-text" required value="${p ? escapeHtml(p.name) : ''}"/>
              <div class="error"></div>
            </div>
            <div class="field">
              <label>Brand</label>
              <input name="brand" type="text" data-validate="required-text" required value="${p ? escapeHtml(p.brand) : ''}"/>
              <div class="error"></div>
            </div>
          </div>
          <div class="field-row-3">
            <div class="field">
              <label>Category</label>
              <input name="category" type="text" data-validate="required-text" required value="${p ? escapeHtml(p.category) : ''}"/>
              <div class="error"></div>
            </div>
            <div class="field">
              <label>Price (USD)</label>
              <input name="price" type="number" min="1" step="1" data-validate="price" required value="${p ? p.price : ''}"/>
              <div class="error"></div>
            </div>
            <div class="field">
              <label>Stock</label>
              <input name="stock" type="number" min="0" step="1" required value="${p ? p.stock : ''}"/>
              <div class="error"></div>
            </div>
          </div>
          <div class="field">
            <label>Image path</label>
            <input name="image" type="text" required value="${p ? escapeHtml(p.image) : 'assets/images/laptop-pro.svg'}"/>
            <div class="error"></div>
            <div class="hint">Use a local image path under assets/images/.</div>
          </div>
          <div class="field">
            <label>Tagline</label>
            <textarea name="tagline">${p ? escapeHtml(p.tagline || '') : ''}</textarea>
          </div>
          <div class="row" style="gap:10px;">
            <button class="btn btn-primary" type="submit" data-submit>${isEdit ? 'Save Changes' : 'Create Product'}</button>
            <button type="button" class="btn btn-ghost" id="cancelForm">Cancel</button>
          </div>
        </form>
      `;

      const form = document.getElementById('prodForm');
      EHValidate.bind(form);

      document.getElementById('closeForm').addEventListener('click', () => { panel.classList.add('hidden'); panel.innerHTML = ''; });
      document.getElementById('cancelForm').addEventListener('click', () => { panel.classList.add('hidden'); panel.innerHTML = ''; });

      form.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!EHValidate.validateAll(form)) { EH.toast('Fix errors before saving.', 'error'); return; }
        const stock = parseInt(form.stock.value, 10);
        if (!Number.isFinite(stock) || stock < 0) { EHValidate.showError(form.stock, 'Stock must be ≥ 0'); return; }

        const list = EH.getProducts();
        if (isEdit) {
          Object.assign(p, {
            name: form.name.value.trim(),
            brand: form.brand.value.trim(),
            category: form.category.value.trim(),
            price: Number(form.price.value),
            stock,
            image: form.image.value.trim(),
            tagline: form.tagline.value.trim()
          });
          EH.saveProducts(list);
          EH.toast('Product updated', 'success');
        } else {
          list.push({
            id: 'p-' + Date.now().toString().slice(-6),
            name: form.name.value.trim(),
            brand: form.brand.value.trim(),
            category: form.category.value.trim(),
            price: Number(form.price.value),
            stock,
            image: form.image.value.trim(),
            rating: 4.5, reviews: 0,
            tagline: form.tagline.value.trim(),
            features: [], specs: {}, colors: []
          });
          EH.saveProducts(list);
          EH.toast('Product created', 'success');
        }
        panel.classList.add('hidden'); panel.innerHTML = '';
        render();
      });
    }

    render();
  }

  /* ---------- ADMIN DASHBOARD ---------- */
  function initAdminDashboard() {
    const root = document.getElementById('adminDash');
    if (!root) return;
    const user = EH.getUser();
    if (!user) {
      EH.renderAuthRequired(root, 'Sign in to access the admin dashboard', 'This area is for administrators only.');
      return;
    }
    if (user.role !== 'admin') {
      EH.renderAuthRequired(root, 'Admin account required', 'Sign in with an administrator account to view this page.');
      return;
    }

    let activeTab = 'overview';

    function render() {
      const users = getUsers();
      const products = EH.getProducts();
      const orders = EH.getOrders();
      const me = EH.getUser();
      const totalRev = orders.reduce((s, o) => s + (o.totals?.total || 0), 0);

      root.innerHTML = `
        <div class="dash-layout">
          <aside class="dash-side">
            <div class="who">
              <div class="name">${me ? escapeHtml(me.name) : 'Admin User'}</div>
              <div class="role">Administrator</div>
            </div>
            <nav class="dash-nav">
              <a href="#overview" data-tab="overview" class="${activeTab==='overview'?'active':''}">Overview</a>
              <a href="#users" data-tab="users" class="${activeTab==='users'?'active':''}">Users</a>
              <a href="#sellers" data-tab="sellers" class="${activeTab==='sellers'?'active':''}">Sellers</a>
              <a href="#moderation" data-tab="moderation" class="${activeTab==='moderation'?'active':''}">Products</a>
              <a href="#reports" data-tab="reports" class="${activeTab==='reports'?'active':''}">Reports</a>
            </nav>
          </aside>

          <div class="dash-main">
            ${activeTab === 'overview' ? `
              <div class="stat-grid">
                <div class="stat-card"><div class="label">Total revenue</div><div class="value">${EH.formatPrice(totalRev)}</div><div class="delta up">▲ Platform-wide</div></div>
                <div class="stat-card"><div class="label">Users</div><div class="value">${users.length}</div><div class="delta up">▲ ${users.filter(u=>u.role==='customer').length} customers</div></div>
                <div class="stat-card"><div class="label">Sellers</div><div class="value">${users.filter(u=>u.role==='seller').length}</div><div class="delta muted">Active sellers</div></div>
                <div class="stat-card"><div class="label">Products</div><div class="value">${products.length}</div><div class="delta muted">Listed</div></div>
              </div>
              <div class="dash-panel">
                <div class="panel-head"><h3>Pending seller approvals</h3></div>
                <table class="table">
                  <thead><tr><th>Name</th><th>Email</th><th>Applied</th><th>Status</th><th>Actions</th></tr></thead>
                  <tbody>
                    <tr>
                      <td>Aurora Tech</td><td>aurora@example.com</td><td>2 hours ago</td>
                      <td><span class="status-pill pending">Pending</span></td>
                      <td><div class="row-actions"><button class="btn btn-sm btn-primary" data-approve>Approve</button><button class="btn btn-sm btn-ghost" data-reject style="color:var(--color-danger);">Reject</button></div></td>
                    </tr>
                    <tr>
                      <td>PixelGear</td><td>hello@pixelgear.io</td><td>1 day ago</td>
                      <td><span class="status-pill pending">Pending</span></td>
                      <td><div class="row-actions"><button class="btn btn-sm btn-primary" data-approve>Approve</button><button class="btn btn-sm btn-ghost" data-reject style="color:var(--color-danger);">Reject</button></div></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            ` : ''}

            ${activeTab === 'users' ? `
              <div class="dash-panel">
                <div class="panel-head"><h3>All users</h3><div class="toolbar"><input type="text" id="userSearch" placeholder="Search by name or email" style="padding:8px 12px; border:1px solid var(--color-line); border-radius:999px; font-size:13px;"/></div></div>
                <table class="table" id="usersTbl">
                  <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
                  <tbody>
                    ${users.map(u => `
                      <tr data-search="${escapeHtml((u.name+' '+u.email).toLowerCase())}">
                        <td>${escapeHtml(u.name)}</td>
                        <td>${escapeHtml(u.email)}</td>
                        <td>${escapeHtml(u.phone || '—')}</td>
                        <td><span class="status-pill ${u.role==='admin'?'info':(u.role==='seller'?'pending':'muted')}">${u.role}</span></td>
                        <td><span class="status-pill ok">Active</span></td>
                        <td><button class="btn btn-sm btn-ghost" style="color:var(--color-danger);" data-del-user="${escapeHtml(u.email)}">Suspend</button></td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            ` : ''}

            ${activeTab === 'sellers' ? `
              <div class="dash-panel">
                <div class="panel-head"><h3>Sellers</h3></div>
                <table class="table">
                  <thead><tr><th>Name</th><th>Email</th><th>Products</th><th>Status</th></tr></thead>
                  <tbody>
                    ${users.filter(u => u.role === 'seller').map(u => `
                      <tr>
                        <td>${escapeHtml(u.name)}</td>
                        <td>${escapeHtml(u.email)}</td>
                        <td>${products.filter(p=>p.seller===u.name).length || products.length}</td>
                        <td><span class="status-pill ok">Verified</span></td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            ` : ''}

            ${activeTab === 'moderation' ? `
              <div class="dash-panel">
                <div class="panel-head"><h3>Product moderation</h3></div>
                <table class="table">
                  <thead><tr><th></th><th>Name</th><th>Seller</th><th>Price</th><th>Status</th><th>Actions</th></tr></thead>
                  <tbody>
                    ${products.map(p => `
                      <tr>
                        <td><div class="thumb"><img src="${EH.path(p.image)}" alt=""/></div></td>
                        <td>${escapeHtml(p.name)}</td>
                        <td>${escapeHtml(p.seller || p.brand)}</td>
                        <td class="tabular">${EH.formatPrice(p.price)}</td>
                        <td><span class="status-pill ok">Approved</span></td>
                        <td><button class="btn btn-sm btn-ghost" data-takedown="${p.id}" style="color:var(--color-danger);">Take down</button></td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            ` : ''}

            ${activeTab === 'reports' ? `
              <div class="stat-grid">
                <div class="stat-card"><div class="label">Open tickets</div><div class="value">7</div><div class="delta down">▼ 2 vs last week</div></div>
                <div class="stat-card"><div class="label">Flagged listings</div><div class="value">2</div><div class="delta muted">Needs review</div></div>
                <div class="stat-card"><div class="label">Refund requests</div><div class="value">3</div><div class="delta up">▲ 1</div></div>
                <div class="stat-card"><div class="label">Disputes</div><div class="value">1</div><div class="delta muted">In progress</div></div>
              </div>
              <div class="dash-panel">
                <div class="panel-head"><h3>Recent reports</h3></div>
                <table class="table">
                  <thead><tr><th>Type</th><th>Subject</th><th>Reported by</th><th>Status</th><th>Date</th></tr></thead>
                  <tbody>
                    <tr><td>Listing</td><td>Counterfeit charger</td><td>customer@x.com</td><td><span class="status-pill pending">Open</span></td><td>2 days ago</td></tr>
                    <tr><td>Review</td><td>Spam content</td><td>moderator@x.com</td><td><span class="status-pill ok">Resolved</span></td><td>5 days ago</td></tr>
                    <tr><td>Refund</td><td>Damaged in transit</td><td>buyer@x.com</td><td><span class="status-pill pending">Pending</span></td><td>1 week ago</td></tr>
                  </tbody>
                </table>
              </div>
            ` : ''}
          </div>
        </div>
      `;

      root.querySelectorAll('[data-tab]').forEach(a => a.addEventListener('click', (e) => {
        e.preventDefault();
        activeTab = a.dataset.tab;
        render();
      }));
      root.querySelectorAll('[data-approve]').forEach(b => b.addEventListener('click', () => { EH.toast('Seller approved', 'success'); b.closest('tr').querySelector('.status-pill').className = 'status-pill ok'; b.closest('tr').querySelector('.status-pill').textContent = 'Approved'; b.closest('td').innerHTML = '<span class="muted small">Approved</span>'; }));
      root.querySelectorAll('[data-reject]').forEach(b => b.addEventListener('click', () => { EH.toast('Seller rejected', 'error'); b.closest('tr').remove(); }));
      root.querySelectorAll('[data-takedown]').forEach(b => b.addEventListener('click', () => {
        if (!confirm('Take down this product?')) return;
        EH.saveProducts(EH.getProducts().filter(p => p.id !== b.dataset.takedown));
        EH.toast('Product taken down');
        render();
      }));
      root.querySelectorAll('[data-del-user]').forEach(b => b.addEventListener('click', () => {
        if (!confirm('Suspend this user?')) return;
        saveUsers(getUsers().filter(u => u.email !== b.dataset.delUser));
        EH.toast('User suspended');
        render();
      }));

      const searchInp = document.getElementById('userSearch');
      if (searchInp) {
        searchInp.addEventListener('input', () => {
          const q = searchInp.value.toLowerCase();
          document.querySelectorAll('#usersTbl tbody tr').forEach(tr => {
            tr.style.display = tr.dataset.search.includes(q) ? '' : 'none';
          });
        });
      }
    }
    render();
  }

  document.addEventListener('DOMContentLoaded', () => {
    initSellerDashboard();
    initAdminDashboard();
  });
})();
