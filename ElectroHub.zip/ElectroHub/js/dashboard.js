/* ===================================================================
   ElectroHub — dashboard.js
   Seller + Admin dashboards. Product CRUD, user mgmt, analytics.
   =================================================================== */

(function () {
  'use strict';

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function getUsers() { return EH.Store.get('eh_users', []); }
  function saveUsers(u) { EH.Store.set('eh_users', u); }

  /* ---------- SELLER DASHBOARD ---------- */
  function initSellerDashboard() {
    const root = document.getElementById('sellerDash');
    if (!root) return;
    const user = EH.getUser();
    if (!user) {
      EH.renderAuthRequired(root, 'Sign in to access the seller dashboard', 'This area is for seller accounts only.');
      return;
    }
    if (user.role !== 'seller' && user.role !== 'admin') {
      EH.renderAuthRequired(root, 'Seller account required', 'Sign in with a seller account to access this dashboard.');
      return;
    }
    // Pull fresh status from eh_users (admin may have approved since last sign-in)
    const fresh = getUsers().find(u => u.email === user.email);
    if (fresh) {
      if (fresh.status !== user.status) {
        EH.setUser({ ...user, status: fresh.status });
      }
    }
    const userStatus = fresh ? fresh.status : (user.status || 'approved');

    if (user.role === 'seller' && userStatus !== 'approved') {
      const headline = userStatus === 'rejected'
        ? 'Application rejected'
        : 'Awaiting admin approval';
      const msg = userStatus === 'rejected'
        ? 'Your seller application has been declined. Contact support if you believe this is an error.'
        : 'Your seller account is being reviewed. You\'ll get full dashboard access once an administrator approves it.';
      root.innerHTML = `
        <div class="empty-state">
          <div class="icon" style="background:${userStatus === 'rejected' ? 'var(--color-danger-soft)' : 'var(--color-warning-soft)'}; color:${userStatus === 'rejected' ? 'var(--color-danger)' : 'var(--color-warning)'};">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              ${userStatus === 'rejected'
                ? '<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>'
                : '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>'}
            </svg>
          </div>
          <h3>${headline}</h3>
          <p>${msg}</p>
          <div class="row" style="justify-content:center; gap:10px; margin-top:18px;">
            <a href="../index.html" class="btn btn-primary">Back to home</a>
            <a href="support.html" class="btn btn-outline">Contact support</a>
          </div>
          <p class="muted small" style="margin-top:20px;">Status: <strong style="color:${userStatus === 'rejected' ? 'var(--color-danger)' : 'var(--color-warning)'};">${userStatus.toUpperCase()}</strong></p>
        </div>`;
      return;
    }

    let activeTab = 'overview';

    // The seller view should only show this seller's own products & orders
    const sellerName = () => (EH.getUser() && EH.getUser().name) || 'Demo Seller';
    const myProducts = () => EH.getProducts().filter(p => (p.seller || p.brand) === sellerName());
    const myProductIds = () => new Set(myProducts().map(p => p.id));
    const myOrders = () => {
      const ids = myProductIds();
      return EH.getOrders().filter(o => (o.items || []).some(it => ids.has(it.id)));
    };
    const mySalesTotal = () =>
      myOrders().reduce((sum, o) => {
        const ids = myProductIds();
        return sum + (o.items || [])
          .filter(it => ids.has(it.id))
          .reduce((s, it) => s + (it.price * it.qty), 0);
      }, 0);

    const stats = () => {
      const sellerProducts = myProducts();
      const sellerOrders = myOrders();
      const totalSales = mySalesTotal();
      return {
        revenue: totalSales,
        products: sellerProducts.length,
        orders: sellerOrders.length,
        avg: sellerOrders.length ? totalSales / sellerOrders.length : 0
      };
    };

    function render() {
      const s = stats();
      const products = myProducts();
      const orders = myOrders();
      const user = EH.getUser();

      root.innerHTML = `
        <div class="dash-layout">
          <aside class="dash-side">
            <div class="who">
              <div class="name">${user ? escapeHtml(user.name) : 'Demo Seller'}</div>
              <div class="role">Seller</div>
            </div>
            <nav class="dash-nav">
              <a href="#overview" data-tab="overview" class="${activeTab==='overview'?'active':''}">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                Overview
              </a>
              <a href="#products" data-tab="products" class="${activeTab==='products'?'active':''}">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/></svg>
                Products
              </a>
              <a href="#orders" data-tab="orders" class="${activeTab==='orders'?'active':''}">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/></svg>
                Orders
              </a>
              <a href="#analytics" data-tab="analytics" class="${activeTab==='analytics'?'active':''}">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
                Analytics
              </a>
            </nav>
          </aside>

          <div class="dash-main">
            ${activeTab === 'overview' ? `
              <div class="stat-grid">
                <div class="stat-card"><div class="label">Revenue</div><div class="value">${EH.formatPrice(s.revenue)}</div><div class="delta up">▲ 12.4% vs last month</div></div>
                <div class="stat-card"><div class="label">Orders</div><div class="value">${s.orders}</div><div class="delta up">▲ 8.1%</div></div>
                <div class="stat-card"><div class="label">Products</div><div class="value">${s.products}</div><div class="delta muted">Live in store</div></div>
                <div class="stat-card"><div class="label">Avg. Order</div><div class="value">${EH.formatPrice(s.avg)}</div><div class="delta up">▲ 3.2%</div></div>
              </div>
              <div class="dash-panel">
                <div class="panel-head"><h3>Recent orders</h3><a href="#orders" data-tab="orders" class="btn btn-sm btn-ghost">View all</a></div>
                ${renderOrdersTable(orders.slice(0, 5))}
              </div>
              <div class="dash-panel">
                <div class="panel-head"><h3>Top products</h3></div>
                ${renderProductsTable(products.slice(0, 5), true)}
              </div>
            ` : ''}

            ${activeTab === 'products' ? `
              <div class="dash-panel">
                <div class="panel-head">
                  <h3>Product catalog</h3>
                  <button class="btn btn-primary btn-sm" id="addProductBtn">+ Add Product</button>
                </div>
                ${renderProductsTable(products, false)}
              </div>
              <div id="productFormPanel" class="dash-panel hidden"></div>
            ` : ''}

            ${activeTab === 'orders' ? `
              <div class="dash-panel">
                <div class="panel-head"><h3>All orders</h3></div>
                ${orders.length ? renderOrdersTable(orders) : '<p class="muted">No orders yet.</p>'}
              </div>
            ` : ''}

            ${activeTab === 'analytics' ? `
              <div class="stat-grid">
                <div class="stat-card"><div class="label">This week</div><div class="value">${EH.formatPrice(s.revenue * 0.28)}</div><div class="delta up">▲ 14%</div></div>
                <div class="stat-card"><div class="label">Conversion</div><div class="value">3.4%</div><div class="delta up">▲ 0.4%</div></div>
                <div class="stat-card"><div class="label">Returning</div><div class="value">42%</div><div class="delta up">▲ 2%</div></div>
                <div class="stat-card"><div class="label">Refund rate</div><div class="value">1.2%</div><div class="delta down">▼ 0.3%</div></div>
              </div>
              <div class="dash-panel">
                <div class="panel-head"><h3>Sales by month</h3></div>
                <div class="bars">
                  ${['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'].map((m, i) => {
                    const h = 30 + (Math.sin(i) + 1) * 60 + (i * 3);
                    return `<div class="bar" style="height:${h}px;"><span>${m}</span></div>`;
                  }).join('')}
                </div>
                <div style="margin-top:32px; padding-top:16px;"></div>
              </div>
              <div class="dash-panel">
                <div class="panel-head"><h3>Category mix</h3></div>
                <div style="display:grid; grid-template-columns:repeat(2,1fr); gap:14px;">
                  ${['Laptops 32%','Phones 28%','Audio 18%','Wearables 12%','Tablets 6%','Other 4%'].map(c => {
                    const [n, pct] = c.split(' ');
                    const p = parseInt(pct);
                    return `
                      <div>
                        <div class="row" style="justify-content:space-between; font-size:13px; margin-bottom:6px;"><span>${n}</span><span class="muted">${pct}</span></div>
                        <div style="background:var(--color-line-soft); height:6px; border-radius:999px; overflow:hidden;"><div style="background:var(--color-ink); width:${p}%; height:100%;"></div></div>
                      </div>`;
                  }).join('')}
                </div>
              </div>
            ` : ''}
          </div>
        </div>
      `;

      // Tab nav
      root.querySelectorAll('[data-tab]').forEach(a => a.addEventListener('click', (e) => {
        e.preventDefault();
        activeTab = a.dataset.tab;
        render();
      }));

      // Product actions
      root.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => openProductForm(b.dataset.edit)));
      root.querySelectorAll('[data-delete]').forEach(b => b.addEventListener('click', () => {
        if (!confirm('Delete this product?')) return;
        const list = EH.getProducts().filter(p => p.id !== b.dataset.delete);
        EH.saveProducts(list);
        EH.toast('Product deleted');
        render();
      }));
      document.getElementById('addProductBtn')?.addEventListener('click', () => openProductForm(null));
    }

    function renderProductsTable(products, simple) {
      return `
        <table class="table">
          <thead>
            <tr><th></th><th>Name</th><th>Brand</th><th>Category</th><th>Price</th><th>Stock</th>${simple ? '' : '<th>Actions</th>'}</tr>
          </thead>
          <tbody>
            ${products.map(p => `
              <tr>
                <td><div class="thumb"><img src="${EH.path(p.image)}" alt=""/></div></td>
                <td>${escapeHtml(p.name)}</td>
                <td>${escapeHtml(p.brand)}</td>
                <td>${escapeHtml(p.category)}</td>
                <td class="tabular">${EH.formatPrice(p.price)}</td>
                <td>${p.stock < 20 ? '<span class="status-pill pending">Low</span>' : '<span class="status-pill ok">In stock</span>'} ${p.stock}</td>
                ${simple ? '' : `<td><div class="row-actions">
                  <button class="btn btn-sm btn-ghost" data-edit="${p.id}">Edit</button>
                  <button class="btn btn-sm btn-ghost" data-delete="${p.id}" style="color:var(--color-danger);">Delete</button>
                </div></td>`}
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    }

    function renderOrdersTable(orders) {
      if (!orders.length) return '<p class="muted">No orders yet.</p>';
      return `
        <table class="table">
          <thead><tr><th>Order ID</th><th>Customer</th><th>Items</th><th>Total</th><th>Status</th><th>Date</th></tr></thead>
          <tbody>
            ${orders.map(o => `
              <tr>
                <td><strong>${escapeHtml(o.id)}</strong></td>
                <td>${escapeHtml(o.customer?.name || '')}</td>
                <td>${o.items?.length || 0}</td>
                <td class="tabular">${EH.formatPrice(o.totals?.total || 0)}</td>
                <td><span class="status-pill ok">${escapeHtml(o.status || '')}</span></td>
                <td>${new Date(o.date).toLocaleDateString()}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    }

    function openProductForm(id) {
      const panel = document.getElementById('productFormPanel');
      const p = id ? EH.findProduct(id) : null;
      const isEdit = !!p;

      panel.classList.remove('hidden');
      panel.innerHTML = `
        <div class="panel-head"><h3>${isEdit ? 'Edit product' : 'New product'}</h3><button class="btn btn-sm btn-ghost" id="closeForm">Cancel</button></div>
        <form id="prodForm" class="form" novalidate>
          <div class="field-row">
            <div class="field">
              <label>Name</label>
              <input name="name" type="text" data-validate="required-text" required value="${p ? escapeHtml(p.name) : ''}"/>
              <div class="error"></div>
            </div>
            <div class="field">
              <label>Brand</label>
              <input name="brand" type="text" data-validate="required-text" required value="${p ? escapeHtml(p.brand) : ''}"/>
              <div class="error"></div>
            </div>
          </div>
          <div class="field-row-3">
            <div class="field">
              <label>Category</label>
              <input name="category" type="text" data-validate="required-text" required value="${p ? escapeHtml(p.category) : ''}"/>
              <div class="error"></div>
            </div>
            <div class="field">
              <label>Price (USD)</label>
              <input name="price" type="number" min="1" step="1" data-validate="price" required value="${p ? p.price : ''}"/>
              <div class="error"></div>
            </div>
            <div class="field">
              <label>Stock</label>
              <input name="stock" type="number" min="0" step="1" required value="${p ? p.stock : ''}"/>
              <div class="error"></div>
            </div>
          </div>
          <div class="field">
            <label>Image path</label>
            <input name="image" type="text" required value="${p ? escapeHtml(p.image) : 'assets/images/laptop-pro.svg'}"/>
            <div class="error"></div>
            <div class="hint">Use a local image path under assets/images/.</div>
          </div>
          <div class="field">
            <label>Tagline</label>
            <textarea name="tagline">${p ? escapeHtml(p.tagline || '') : ''}</textarea>
          </div>
          <div class="row" style="gap:10px;">
            <button class="btn btn-primary" type="submit" data-submit>${isEdit ? 'Save Changes' : 'Create Product'}</button>
            <button type="button" class="btn btn-ghost" id="cancelForm">Cancel</button>
          </div>
        </form>
      `;

      const form = document.getElementById('prodForm');
      EHValidate.bind(form);

      document.getElementById('closeForm').addEventListener('click', () => { panel.classList.add('hidden'); panel.innerHTML = ''; });
      document.getElementById('cancelForm').addEventListener('click', () => { panel.classList.add('hidden'); panel.innerHTML = ''; });

      form.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!EHValidate.validateAll(form)) { EH.toast('Fix errors before saving.', 'error'); return; }
        const stock = parseInt(form.stock.value, 10);
        if (!Number.isFinite(stock) || stock < 0) { EHValidate.showError(form.stock, 'Stock must be ≥ 0'); return; }

        const list = EH.getProducts();
        if (isEdit) {
          Object.assign(p, {
            name: form.name.value.trim(),
            brand: form.brand.value.trim(),
            category: form.category.value.trim(),
            price: Number(form.price.value),
            stock,
            image: form.image.value.trim(),
            tagline: form.tagline.value.trim()
          });
          EH.saveProducts(list);
          EH.toast('Product updated', 'success');
        } else {
          list.push({
            id: 'p-' + Date.now().toString().slice(-6),
            name: form.name.value.trim(),
            brand: form.brand.value.trim(),
            category: form.category.value.trim(),
            price: Number(form.price.value),
            stock,
            image: form.image.value.trim(),
            rating: 4.5, reviews: 0,
            tagline: form.tagline.value.trim(),
            features: [], specs: {}, colors: [],
            // stamp with current seller so it shows up in admin & their own dashboard correctly
            seller: sellerName(),
            createdAt: new Date().toISOString()
          });
          EH.saveProducts(list);
          EH.toast('Product created · live in catalog', 'success');
        }
        panel.classList.add('hidden'); panel.innerHTML = '';
        render();
      });
    }

    render();
  }

  /* ---------- ADMIN DASHBOARD ---------- */
  function initAdminDashboard() {
    const root = document.getElementById('adminDash');
    if (!root) return;
    const user = EH.getUser();
    if (!user) {
      EH.renderAuthRequired(root, 'Sign in to access the admin dashboard', 'This area is for administrators only.');
      return;
    }
    if (user.role !== 'admin') {
      EH.renderAuthRequired(root, 'Admin account required', 'Sign in with an administrator account to view this page.');
      return;
    }

    let activeTab = 'overview';

    // Helpers
    const timeAgo = (iso) => {
      if (!iso) return '—';
      const diff = Date.now() - new Date(iso).getTime();
      const m = Math.floor(diff / 60000);
      if (m < 1) return 'just now';
      if (m < 60) return `${m} min ago`;
      const h = Math.floor(m / 60);
      if (h < 24) return `${h} hour${h === 1 ? '' : 's'} ago`;
      const d = Math.floor(h / 24);
      if (d < 30) return `${d} day${d === 1 ? '' : 's'} ago`;
      const mo = Math.floor(d / 30);
      return `${mo} month${mo === 1 ? '' : 's'} ago`;
    };
    const statusPillFor = (status) => {
      const map = {
        approved: 'ok', active: 'ok', resolved: 'ok',
        pending: 'pending', open: 'pending',
        rejected: 'fail', suspended: 'fail', dismissed: 'muted',
        admin: 'info', seller: 'info', customer: 'muted'
      };
      return map[status] || 'muted';
    };
    const userStatusOf = (u) => u.status || 'approved';
    const updateUser = (email, patch) => {
      const list = getUsers();
      const t = list.find(u => u.email === email);
      if (t) { Object.assign(t, patch); saveUsers(list); }
    };
    const updateReport = (id, patch) => {
      const list = EH.getReports();
      const t = list.find(r => r.id === id);
      if (t) { Object.assign(t, patch); EH.saveReports(list); }
    };
    const productCountForSeller = (sellerName) =>
      EH.getProducts().filter(p => (p.seller || p.brand) === sellerName).length;

    function render() {
      const users = getUsers();
      const products = EH.getProducts();
      const orders = EH.getOrders();
      const reports = EH.getReports();
      const me = EH.getUser();
      const totalRev = orders.reduce((s, o) => s + (o.totals?.total || 0), 0);

      // Live computed stats
      const pendingSellers = users.filter(u => u.role === 'seller' && userStatusOf(u) === 'pending');
      const approvedSellers = users.filter(u => u.role === 'seller' && userStatusOf(u) === 'approved');
      const customers = users.filter(u => u.role === 'customer');
      const openReports = reports.filter(r => r.status === 'open' || r.status === 'pending');
      const refundReports = reports.filter(r => r.type === 'Refund');
      const flaggedListings = reports.filter(r => r.type === 'Listing' && (r.status === 'open' || r.status === 'pending'));
      const disputes = reports.filter(r => r.type === 'Dispute');

      root.innerHTML = `
        <div class="dash-layout">
          <aside class="dash-side">
            <div class="who">
              <div class="name">${me ? escapeHtml(me.name) : 'Admin User'}</div>
              <div class="role">Administrator</div>
            </div>
            <nav class="dash-nav">
              <a href="#overview" data-tab="overview" class="${activeTab==='overview'?'active':''}">Overview</a>
              <a href="#users" data-tab="users" class="${activeTab==='users'?'active':''}">Users</a>
              <a href="#sellers" data-tab="sellers" class="${activeTab==='sellers'?'active':''}">Sellers ${pendingSellers.length ? `<span class="status-pill pending" style="margin-left:auto;">${pendingSellers.length}</span>` : ''}</a>
              <a href="#moderation" data-tab="moderation" class="${activeTab==='moderation'?'active':''}">Products</a>
              <a href="#orders" data-tab="orders" class="${activeTab==='orders'?'active':''}">Orders</a>
              <a href="#reports" data-tab="reports" class="${activeTab==='reports'?'active':''}">Reports ${openReports.length ? `<span class="status-pill pending" style="margin-left:auto;">${openReports.length}</span>` : ''}</a>
            </nav>
          </aside>

          <div class="dash-main">
            ${activeTab === 'overview' ? `
              <div class="stat-grid">
                <div class="stat-card"><div class="label">Total revenue</div><div class="value">${EH.formatPrice(totalRev)}</div><div class="delta up">▲ ${orders.length} order${orders.length===1?'':'s'}</div></div>
                <div class="stat-card"><div class="label">Users</div><div class="value">${users.length}</div><div class="delta up">▲ ${customers.length} customers</div></div>
                <div class="stat-card"><div class="label">Sellers</div><div class="value">${approvedSellers.length}</div><div class="delta ${pendingSellers.length ? 'down' : 'muted'}">${pendingSellers.length ? `${pendingSellers.length} pending review` : 'All approved'}</div></div>
                <div class="stat-card"><div class="label">Products</div><div class="value">${products.length}</div><div class="delta muted">${flaggedListings.length ? `${flaggedListings.length} flagged` : 'Listed'}</div></div>
              </div>

              <div class="dash-panel">
                <div class="panel-head">
                  <h3>Pending seller approvals</h3>
                  ${pendingSellers.length ? `<span class="status-pill pending">${pendingSellers.length} pending</span>` : '<span class="status-pill ok">All clear</span>'}
                </div>
                ${pendingSellers.length ? `
                  <table class="table">
                    <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Applied</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody>
                      ${pendingSellers.map(u => `
                        <tr>
                          <td>${escapeHtml(u.name)}</td>
                          <td>${escapeHtml(u.email)}</td>
                          <td>${escapeHtml(u.phone || '—')}</td>
                          <td>${timeAgo(u.appliedAt || u.joinedAt)}</td>
                          <td><span class="status-pill pending">Pending</span></td>
                          <td><div class="row-actions">
                            <button class="btn btn-sm btn-primary" data-approve="${escapeHtml(u.email)}">Approve</button>
                            <button class="btn btn-sm btn-ghost" data-reject="${escapeHtml(u.email)}" style="color:var(--color-danger);">Reject</button>
                          </div></td>
                        </tr>
                      `).join('')}
                    </tbody>
                  </table>
                ` : '<p class="muted">No pending applications.</p>'}
              </div>

              <div class="dash-panel">
                <div class="panel-head"><h3>Recent activity</h3></div>
                <table class="table">
                  <thead><tr><th>Time</th><th>Event</th><th>Status</th></tr></thead>
                  <tbody>
                    ${orders.slice(0, 3).map(o => `
                      <tr><td>${timeAgo(o.date)}</td><td>New order ${escapeHtml(o.id)} by ${escapeHtml(o.customer?.name || '')}</td><td><span class="status-pill ok">${escapeHtml(o.status || 'Confirmed')}</span></td></tr>
                    `).join('')}
                    ${reports.slice(0, 3).map(r => `
                      <tr><td>${timeAgo(r.date)}</td><td>${escapeHtml(r.type)} report — ${escapeHtml(r.subject)}</td><td><span class="status-pill ${statusPillFor(r.status)}">${r.status}</span></td></tr>
                    `).join('')}
                    ${pendingSellers.slice(0, 2).map(u => `
                      <tr><td>${timeAgo(u.appliedAt || u.joinedAt)}</td><td>Seller application from ${escapeHtml(u.name)}</td><td><span class="status-pill pending">Pending</span></td></tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            ` : ''}

            ${activeTab === 'users' ? `
              <div class="dash-panel">
                <div class="panel-head">
                  <h3>All users (${users.length})</h3>
                  <input type="text" id="userSearch" placeholder="Search by name or email" style="padding:8px 12px; border:1px solid var(--color-line); border-radius:999px; font-size:13px;"/>
                </div>
                <table class="table" id="usersTbl">
                  <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
                  <tbody>
                    ${users.map(u => {
                      const st = userStatusOf(u);
                      return `
                      <tr data-search="${escapeHtml((u.name+' '+u.email).toLowerCase())}">
                        <td>${escapeHtml(u.name)}</td>
                        <td>${escapeHtml(u.email)}</td>
                        <td>${escapeHtml(u.phone || '—')}</td>
                        <td><span class="status-pill ${statusPillFor(u.role)}">${u.role}</span></td>
                        <td><span class="status-pill ${statusPillFor(st)}">${st}</span></td>
                        <td class="muted small">${timeAgo(u.joinedAt)}</td>
                        <td><div class="row-actions">
                          ${st === 'suspended'
                            ? `<button class="btn btn-sm btn-ghost" data-reactivate-user="${escapeHtml(u.email)}">Reactivate</button>`
                            : (u.role !== 'admin'
                                ? `<button class="btn btn-sm btn-ghost" style="color:var(--color-danger);" data-suspend-user="${escapeHtml(u.email)}">Suspend</button>`
                                : '<span class="muted small">—</span>')
                          }
                        </div></td>
                      </tr>`;
                    }).join('')}
                  </tbody>
                </table>
              </div>
            ` : ''}

            ${activeTab === 'sellers' ? `
              <div class="dash-panel">
                <div class="panel-head">
                  <h3>Sellers</h3>
                  <div class="row" style="gap:8px;">
                    <span class="status-pill ok">${approvedSellers.length} approved</span>
                    ${pendingSellers.length ? `<span class="status-pill pending">${pendingSellers.length} pending</span>` : ''}
                  </div>
                </div>
                <table class="table">
                  <thead><tr><th>Name</th><th>Email</th><th>Products</th><th>Joined</th><th>Status</th><th>Actions</th></tr></thead>
                  <tbody>
                    ${users.filter(u => u.role === 'seller').map(u => {
                      const st = userStatusOf(u);
                      return `
                      <tr>
                        <td>${escapeHtml(u.name)}</td>
                        <td>${escapeHtml(u.email)}</td>
                        <td>${productCountForSeller(u.name)}</td>
                        <td class="muted small">${timeAgo(u.joinedAt)}</td>
                        <td><span class="status-pill ${statusPillFor(st)}">${st}</span></td>
                        <td><div class="row-actions">
                          ${st === 'pending' ? `
                            <button class="btn btn-sm btn-primary" data-approve="${escapeHtml(u.email)}">Approve</button>
                            <button class="btn btn-sm btn-ghost" data-reject="${escapeHtml(u.email)}" style="color:var(--color-danger);">Reject</button>
                          ` : st === 'approved' ? `
                            <button class="btn btn-sm btn-ghost" data-suspend-user="${escapeHtml(u.email)}" style="color:var(--color-danger);">Suspend</button>
                          ` : st === 'rejected' || st === 'suspended' ? `
                            <button class="btn btn-sm btn-ghost" data-reactivate-user="${escapeHtml(u.email)}">Reactivate</button>
                          ` : '—'}
                        </div></td>
                      </tr>`;
                    }).join('')}
                  </tbody>
                </table>
              </div>
            ` : ''}

            ${activeTab === 'moderation' ? `
              <div class="dash-panel">
                <div class="panel-head"><h3>Product moderation (${products.length})</h3></div>
                <table class="table">
                  <thead><tr><th></th><th>Name</th><th>Seller</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead>
                  <tbody>
                    ${products.map(p => {
                      const flagged = reports.some(r => r.type === 'Listing' && (r.status === 'open' || r.status === 'pending') && (r.productId === p.id));
                      const st = flagged ? 'pending' : 'approved';
                      return `
                      <tr>
                        <td><div class="thumb"><img src="${EH.path(p.image)}" alt=""/></div></td>
                        <td>${escapeHtml(p.name)}</td>
                        <td>${escapeHtml(p.seller || p.brand)}</td>
                        <td class="tabular">${EH.formatPrice(p.price)}</td>
                        <td>${p.stock < 20 ? `<span class="status-pill pending">Low · ${p.stock}</span>` : `<span class="status-pill ok">${p.stock}</span>`}</td>
                        <td><span class="status-pill ${statusPillFor(st)}">${flagged ? 'Flagged' : 'Approved'}</span></td>
                        <td><button class="btn btn-sm btn-ghost" data-takedown="${p.id}" style="color:var(--color-danger);">Take down</button></td>
                      </tr>`;
                    }).join('')}
                  </tbody>
                </table>
              </div>
            ` : ''}

            ${activeTab === 'orders' ? `
              <div class="dash-panel">
                <div class="panel-head"><h3>All orders (${orders.length})</h3></div>
                ${orders.length ? `
                  <table class="table">
                    <thead><tr><th>Order ID</th><th>Customer</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th><th>Date</th></tr></thead>
                    <tbody>
                      ${orders.map(o => `
                        <tr>
                          <td><strong>${escapeHtml(o.id)}</strong></td>
                          <td>${escapeHtml(o.customer?.name || '')}<br/><span class="muted small">${escapeHtml(o.customer?.email || '')}</span></td>
                          <td>${o.items?.length || 0}</td>
                          <td class="tabular">${EH.formatPrice(o.totals?.total || 0)}</td>
                          <td><span class="status-pill muted">${escapeHtml((o.payment || '').toUpperCase())}</span></td>
                          <td><span class="status-pill ok">${escapeHtml(o.status || 'Confirmed')}</span></td>
                          <td class="muted small">${timeAgo(o.date)}</td>
                        </tr>
                      `).join('')}
                    </tbody>
                  </table>
                ` : '<p class="muted">No orders yet. Place an order as a customer to see it here.</p>'}
              </div>
            ` : ''}

            ${activeTab === 'reports' ? `
              <div class="stat-grid">
                <div class="stat-card"><div class="label">Open tickets</div><div class="value">${openReports.length}</div><div class="delta ${openReports.length === 0 ? 'muted' : 'down'}">${openReports.length === 0 ? 'All resolved' : 'Needs attention'}</div></div>
                <div class="stat-card"><div class="label">Flagged listings</div><div class="value">${flaggedListings.length}</div><div class="delta muted">${flaggedListings.length === 0 ? 'No flags' : 'Review pending'}</div></div>
                <div class="stat-card"><div class="label">Refund requests</div><div class="value">${refundReports.length}</div><div class="delta muted">${refundReports.filter(r=>r.status==='pending'||r.status==='open').length} open</div></div>
                <div class="stat-card"><div class="label">Disputes</div><div class="value">${disputes.length}</div><div class="delta muted">${disputes.filter(r=>r.status==='open').length || 0} in progress</div></div>
              </div>
              <div class="dash-panel">
                <div class="panel-head"><h3>All reports (${reports.length})</h3></div>
                <table class="table">
                  <thead><tr><th>Type</th><th>Subject</th><th>Reported by</th><th>Priority</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
                  <tbody>
                    ${reports.map(r => `
                      <tr>
                        <td><strong>${escapeHtml(r.type)}</strong></td>
                        <td>${escapeHtml(r.subject)}</td>
                        <td>${escapeHtml(r.reporter)}</td>
                        <td><span class="status-pill ${r.priority==='high'?'fail':(r.priority==='medium'?'pending':'muted')}">${r.priority || 'low'}</span></td>
                        <td><span class="status-pill ${statusPillFor(r.status)}">${r.status}</span></td>
                        <td class="muted small">${timeAgo(r.date)}</td>
                        <td><div class="row-actions">
                          ${r.status !== 'resolved' && r.status !== 'dismissed' ? `
                            <button class="btn btn-sm btn-primary" data-resolve="${escapeHtml(r.id)}">Resolve</button>
                            <button class="btn btn-sm btn-ghost" data-dismiss="${escapeHtml(r.id)}">Dismiss</button>
                          ` : `
                            <button class="btn btn-sm btn-ghost" data-reopen="${escapeHtml(r.id)}">Reopen</button>
                          `}
                        </div></td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            ` : ''}
          </div>
        </div>
      `;

      // Wire interactions
      root.querySelectorAll('[data-tab]').forEach(a => a.addEventListener('click', (e) => {
        e.preventDefault();
        activeTab = a.dataset.tab;
        render();
      }));
      root.querySelectorAll('[data-approve]').forEach(b => b.addEventListener('click', () => {
        updateUser(b.dataset.approve, { status: 'approved', approvedAt: new Date().toISOString() });
        EH.toast('Seller approved', 'success');
        render();
      }));
      root.querySelectorAll('[data-reject]').forEach(b => b.addEventListener('click', () => {
        if (!confirm('Reject this seller application?')) return;
        updateUser(b.dataset.reject, { status: 'rejected', rejectedAt: new Date().toISOString() });
        EH.toast('Seller rejected', 'error');
        render();
      }));
      root.querySelectorAll('[data-suspend-user]').forEach(b => b.addEventListener('click', () => {
        if (!confirm('Suspend this user? They will lose access until reactivated.')) return;
        updateUser(b.dataset.suspendUser, { status: 'suspended' });
        EH.toast('User suspended');
        render();
      }));
      root.querySelectorAll('[data-reactivate-user]').forEach(b => b.addEventListener('click', () => {
        updateUser(b.dataset.reactivateUser, { status: 'approved' });
        EH.toast('User reactivated', 'success');
        render();
      }));
      root.querySelectorAll('[data-takedown]').forEach(b => b.addEventListener('click', () => {
        if (!confirm('Take down this product? It will be removed from the catalog.')) return;
        EH.saveProducts(EH.getProducts().filter(p => p.id !== b.dataset.takedown));
        EH.toast('Product taken down');
        render();
      }));
      root.querySelectorAll('[data-resolve]').forEach(b => b.addEventListener('click', () => {
        updateReport(b.dataset.resolve, { status: 'resolved', resolvedAt: new Date().toISOString() });
        EH.toast('Report resolved', 'success');
        render();
      }));
      root.querySelectorAll('[data-dismiss]').forEach(b => b.addEventListener('click', () => {
        updateReport(b.dataset.dismiss, { status: 'dismissed' });
        EH.toast('Report dismissed');
        render();
      }));
      root.querySelectorAll('[data-reopen]').forEach(b => b.addEventListener('click', () => {
        updateReport(b.dataset.reopen, { status: 'open' });
        EH.toast('Report reopened');
        render();
      }));

      const searchInp = document.getElementById('userSearch');
      if (searchInp) {
        searchInp.addEventListener('input', () => {
          const q = searchInp.value.toLowerCase();
          document.querySelectorAll('#usersTbl tbody tr').forEach(tr => {
            tr.style.display = tr.dataset.search.includes(q) ? '' : 'none';
          });
        });
      }
    }
    render();
  }

  document.addEventListener('DOMContentLoaded', () => {
    initSellerDashboard();
    initAdminDashboard();
  });
})();
