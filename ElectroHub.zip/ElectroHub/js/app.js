/* ===================================================================
   ElectroHub — app.js
   Shared bootstrap: data, storage, navbar/footer, toasts, utilities.
   =================================================================== */

(function () {
  'use strict';

  /* ---------- Path helper (works for index + /pages/*) ---------- */
  const inPages = location.pathname.replace(/\\/g, '/').includes('/pages/');
  const ROOT = inPages ? '../' : './';

  window.EH = window.EH || {};
  EH.ROOT = ROOT;
  EH.path = (p) => ROOT + p.replace(/^\//, '');

  /* ---------- Storage helpers ----------
     All app data is stored in sessionStorage — cleared when the browser
     tab/window closes. Includes registered accounts, products, orders,
     reviews, wishlist, cart, compare list, and the signed-in user.
     Both Store and SessionStore aliases back to sessionStorage so existing
     call sites keep working.
  */
  const makeStore = (backing) => ({
    get(key, fallback) {
      try {
        const raw = backing.getItem(key);
        return raw == null ? fallback : JSON.parse(raw);
      } catch { return fallback; }
    },
    set(key, value) { try { backing.setItem(key, JSON.stringify(value)); } catch (e) {} },
    remove(key) { try { backing.removeItem(key); } catch (e) {} }
  });
  const Store = makeStore(sessionStorage);
  const SessionStore = Store; // alias — same backing
  EH.Store = Store;
  EH.SessionStore = SessionStore;

  /* ---------- Currency formatter — INR ---------- */
  EH.formatPrice = (n) =>
    '₹' + Number(n).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 0 });

  /* ---------- Product catalog (seed data) ---------- */
  const seedProducts = [
    {
      id: 'p-001', name: 'ProBook 16" M-Series', brand: 'Nova', category: 'Laptops',
      price: 199990, oldPrice: 214990, rating: 4.8, reviews: 1284,
      image: 'assets/images/laptop-pro.svg',
      tag: 'new', stock: 24, seller: 'Nova Direct',
      colors: ['Space Gray', 'Silver'],
      tagline: 'Workstation-grade performance in a featherweight chassis.',
      features: [
        '16-inch Liquid Retina XDR display',
        'M-series chip with 12-core CPU and 18-core GPU',
        'Up to 22 hours battery life',
        '1080p FaceTime HD camera',
        'Studio-quality six-speaker sound system'
      ],
      specs: {
        Display: '16.2" Liquid Retina XDR, 3456 × 2234',
        Processor: '12-core CPU / 18-core GPU',
        Memory: '18GB Unified',
        Storage: '512GB SSD',
        Battery: 'Up to 22 hours',
        Weight: '2.14 kg',
        Ports: 'Thunderbolt 4 × 3, HDMI, MagSafe',
        OS: 'NovaOS 15',
        Warranty: '2 years (ElectroHub India)'
      }
    },
    {
      id: 'p-002', name: 'AirBook 13" Slim', brand: 'Nova', category: 'Laptops',
      price: 99990, oldPrice: 109990, rating: 4.7, reviews: 894,
      image: 'assets/images/laptop-air.svg',
      tag: null, stock: 50, seller: 'Nova Direct',
      colors: ['Midnight', 'Starlight'],
      tagline: 'Thin, light, all-day battery.',
      features: ['13.6" Liquid Retina display', 'M-series chip', 'Up to 18 hours battery', 'Fanless silent design'],
      specs: { Display: '13.6" Retina', Processor: '8-core CPU', Memory: '8GB', Storage: '256GB', Battery: '18 hr', Weight: '1.24 kg' }
    },
    {
      id: 'p-003', name: 'Echo Pro 15', brand: 'Echo', category: 'Phones',
      price: 134900, oldPrice: 149900, rating: 4.9, reviews: 3421,
      image: 'assets/images/phone-pro.svg',
      tag: 'new', stock: 80, seller: 'Echo Mobility',
      colors: ['Natural Titanium', 'Black Titanium', 'White Titanium'],
      tagline: 'Titanium build. Pro-grade triple camera system.',
      features: ['6.7" Super Retina XDR', 'Triple 48MP camera array', 'Titanium aerospace-grade frame', 'All-day battery'],
      specs: { Display: '6.7" OLED', Chip: 'A-series Bionic', Camera: '48MP + 12MP + 12MP', Storage: '256GB', Battery: '4422 mAh' }
    },
    {
      id: 'p-004', name: 'Echo Mini 14', brand: 'Echo', category: 'Phones',
      price: 79900, rating: 4.6, reviews: 1208,
      image: 'assets/images/phone-mini.svg',
      tag: null, stock: 120, seller: 'Echo Mobility',
      colors: ['Blue', 'White', 'Black', 'Coral'],
      tagline: 'Compact flagship power, one-handed design.',
      features: ['6.1" Super Retina display', 'Dual 12MP cameras', 'Lightweight aluminum frame'],
      specs: { Display: '6.1" OLED', Chip: 'A-series', Camera: '12MP + 12MP', Storage: '128GB' }
    },
    {
      id: 'p-005', name: 'StudioPods Max', brand: 'Nova', category: 'Audio',
      price: 59990, oldPrice: 69990, rating: 4.8, reviews: 2104,
      image: 'assets/images/headphones.svg',
      tag: 'sale', stock: 60, seller: 'Nova Direct',
      colors: ['Space Gray', 'Silver'],
      tagline: 'Over-ear acoustic excellence with adaptive noise cancellation.',
      features: ['Active noise cancellation', 'Spatial audio', '20 hour battery', 'Memory-foam ear cushions'],
      specs: { Driver: '40mm dynamic', Battery: '20 hours', Weight: '384g', Connectivity: 'Bluetooth 5.3' }
    },
    {
      id: 'p-006', name: 'AirPods Pro 3', brand: 'Nova', category: 'Audio',
      price: 26900, rating: 4.7, reviews: 5829,
      image: 'assets/images/earbuds.svg',
      tag: null, stock: 200, seller: 'Nova Direct',
      colors: ['White'],
      tagline: 'In-ear ANC with adaptive transparency.',
      features: ['Active noise cancellation', 'Adaptive transparency', 'Up to 6 hours playback', 'MagSafe charging case'],
      specs: { Battery: '6 hr / 30 hr w/ case', Chip: 'H2', Connectivity: 'Bluetooth 5.3' }
    },
    {
      id: 'p-007', name: 'Watch Series 10', brand: 'Nova', category: 'Wearables',
      price: 44900, oldPrice: 49900, rating: 4.8, reviews: 1894,
      image: 'assets/images/watch.svg',
      tag: 'new', stock: 90, seller: 'Nova Direct',
      colors: ['Midnight', 'Silver', 'Gold'],
      tagline: 'Health, fitness, and connectivity on your wrist.',
      features: ['Always-on Retina display', 'Blood oxygen sensor', 'ECG app', 'GPS + Cellular'],
      specs: { Display: '49mm Retina', Battery: '18 hr', WaterRes: 'WR50', GPS: 'L1/L5' }
    },
    {
      id: 'p-008', name: 'PadPro 11"', brand: 'Nova', category: 'Tablets',
      price: 84900, rating: 4.7, reviews: 967,
      image: 'assets/images/tablet.svg',
      tag: null, stock: 70, seller: 'Nova Direct',
      colors: ['Space Gray', 'Silver'],
      tagline: 'Versatile tablet for creators and pros.',
      features: ['11" Liquid Retina display', 'M-series chip', 'Pro stylus support'],
      specs: { Display: '11" Liquid Retina', Chip: 'M-series', Storage: '128GB', Battery: '10 hr' }
    },
    {
      id: 'p-009', name: 'SoundOrb 360', brand: 'Aria', category: 'Audio',
      price: 34900, oldPrice: 39900, rating: 4.5, reviews: 612,
      image: 'assets/images/speaker.svg',
      tag: 'sale', stock: 40, seller: 'Aria Sound',
      colors: ['Charcoal', 'White'],
      tagline: 'Room-filling 360° sound with deep bass.',
      features: ['Computational audio', '360° spatial sound', 'Multi-room support'],
      specs: { Power: '20W', Connectivity: 'Wi-Fi 6, Bluetooth 5.3', Voice: 'Built-in assistant' }
    },
    {
      id: 'p-010', name: 'Vision UHD TV 55"', brand: 'Vista', category: 'TV',
      price: 139900, rating: 4.6, reviews: 423,
      image: 'assets/images/tv.svg',
      tag: null, stock: 18, seller: 'Vista Home',
      colors: ['Black'],
      tagline: 'Cinema-grade 4K HDR for your living room.',
      features: ['4K UHD OLED', 'HDR10+', 'Dolby Atmos', '120Hz refresh'],
      specs: { Display: '55" OLED', Resolution: '3840 × 2160', HDR: 'HDR10+ / Dolby Vision', Refresh: '120Hz' }
    },
    {
      id: 'p-011', name: 'Lens X Mirrorless', brand: 'Optic', category: 'Cameras',
      price: 174900, rating: 4.9, reviews: 287,
      image: 'assets/images/camera.svg',
      tag: 'new', stock: 12, seller: 'Optic Pro',
      colors: ['Black'],
      tagline: 'Full-frame mirrorless with 8K video.',
      features: ['45MP full-frame sensor', '8K 30p video', 'Dual card slots', 'IBIS stabilization'],
      specs: { Sensor: '45MP Full-frame CMOS', Video: '8K 30p', ISO: '100-51200', Mount: 'X-Mount' }
    },
    {
      id: 'p-012', name: 'UltraSharp 27" 4K Monitor', brand: 'Nova', category: 'Monitors',
      price: 72990, oldPrice: 84990, rating: 4.6, reviews: 521,
      image: 'assets/images/monitor.svg',
      tag: 'sale', stock: 35, seller: 'Nova Direct',
      colors: ['Silver'],
      tagline: '4K precision with factory-calibrated color.',
      features: ['27" 4K UHD IPS', 'P3 wide gamut', 'USB-C 90W power', 'Adjustable stand'],
      specs: { Display: '27" 4K IPS', Resolution: '3840 × 2160', Refresh: '60Hz', Ports: 'USB-C, HDMI × 2, DP' }
    },
    {
      id: 'p-013', name: 'Magic Keyboard Touch', brand: 'Nova', category: 'Accessories',
      price: 15900, rating: 4.5, reviews: 832,
      image: 'assets/images/keyboard.svg',
      tag: null, stock: 100, seller: 'Nova Direct',
      colors: ['White', 'Black'],
      tagline: 'Wireless keyboard with biometric Touch ID.',
      features: ['Touch ID', 'Scissor mechanism', 'Rechargeable, month-long battery'],
      specs: { Layout: 'Full-size', Connectivity: 'Bluetooth', Battery: '1 month' }
    },
    {
      id: 'p-014', name: 'Glide Mouse Pro', brand: 'Nova', category: 'Accessories',
      price: 9900, rating: 4.4, reviews: 712,
      image: 'assets/images/mouse.svg',
      tag: null, stock: 150, seller: 'Nova Direct',
      colors: ['White', 'Black'],
      tagline: 'Multi-touch precision in an ergonomic shell.',
      features: ['Multi-touch surface', 'Optical tracking', 'Rechargeable'],
      specs: { Connectivity: 'Bluetooth', Battery: '1 month', Surface: 'Multi-touch' }
    },
    {
      id: 'p-015', name: 'SkyCam Quad Drone', brand: 'Aero', category: 'Cameras',
      price: 114900, oldPrice: 124900, rating: 4.7, reviews: 198,
      image: 'assets/images/drone.svg',
      tag: 'new', stock: 22, seller: 'Aero Flight',
      colors: ['Gray'],
      tagline: '4K cinematic drone with 46-minute flight time.',
      features: ['4K HDR camera', '46 min flight time', 'Obstacle sensing', '10 km transmission'],
      specs: { Camera: '4K 60p HDR', FlightTime: '46 min', Range: '10 km', Weight: '895g' }
    },
    {
      id: 'p-016', name: 'PlayCube X', brand: 'GameOn', category: 'Gaming',
      price: 54990, rating: 4.8, reviews: 1453,
      image: 'assets/images/console.svg',
      tag: null, stock: 30, seller: 'GameOn Studios',
      colors: ['Black'],
      tagline: '4K gaming console with ray tracing.',
      features: ['4K 120fps', 'Ray tracing', '1TB SSD', 'Backwards compatible'],
      specs: { Resolution: '4K 120Hz', Storage: '1TB NVMe', GPU: 'Custom RDNA' }
    },
    {
      id: 'p-017', name: 'PowerBrick 100W Charger', brand: 'Nova', category: 'Accessories',
      price: 7990, rating: 4.6, reviews: 1289,
      image: 'assets/images/charger.svg',
      tag: null, stock: 250, seller: 'Nova Direct',
      colors: ['White'],
      tagline: 'Fast 100W USB-C charging for laptops and phones.',
      features: ['100W output', 'GaN technology', 'USB-C cable included'],
      specs: { Power: '100W', Ports: 'USB-C', Cable: '2m braided' }
    }
  ];

  const SEED_VERSION = 'v2-inr'; // bump to force re-seed on price changes
  EH.getProducts = function () {
    const version = Store.get('eh_seed_version', null);
    if (version !== SEED_VERSION) {
      Store.set('eh_products', seedProducts);
      Store.set('eh_seed_version', SEED_VERSION);
      return seedProducts;
    }
    return Store.get('eh_products', seedProducts);
  };
  EH.saveProducts = function (p) { Store.set('eh_products', p); };
  EH.findProduct = function (id) { return EH.getProducts().find(p => p.id === id); };

  /* ---------- Cart / Wishlist counts ---------- */
  // Cart lives in sessionStorage — fresh cart per browser session
  EH.getCart = () => SessionStore.get('eh_cart', []);
  EH.saveCart = (c) => { SessionStore.set('eh_cart', c); EH.updateNavBadges(); };
  // Wishlist persists across sessions (users expect this to survive)
  EH.getWishlist = () => Store.get('eh_wishlist', []);
  EH.saveWishlist = (w) => { Store.set('eh_wishlist', w); EH.updateNavBadges(); };

  /* ---------- Company info (India) ---------- */
  EH.COMPANY = {
    name: 'ElectroHub Pvt. Ltd.',
    address: '14th Floor, Prestige Technostar, Bengaluru, Karnataka 560048',
    phone: '+91 1800-123-4567',
    email: 'support@electrohub.in',
    gst: '29AABCE1234F1Z5'
  };

  EH.updateNavBadges = function () {
    const cartCount = EH.getCart().reduce((s, i) => s + (i.qty || 1), 0);
    const wishCount = EH.getWishlist().length;
    document.querySelectorAll('[data-cart-count]').forEach(el => {
      el.textContent = cartCount;
      el.style.display = cartCount > 0 ? '' : 'none';
    });
    document.querySelectorAll('[data-wish-count]').forEach(el => {
      el.textContent = wishCount;
      el.style.display = wishCount > 0 ? '' : 'none';
    });
    EH.renderCompareBar();
  };

  /* ---------- Compare list (max 4 products) ---------- */
  // Compare list is purely transient — sessionStorage
  EH.COMPARE_MAX = 4;
  EH.getCompare = () => SessionStore.get('eh_compare', []);
  EH.saveCompare = (ids) => { SessionStore.set('eh_compare', ids); EH.renderCompareBar(); };
  EH.toggleCompare = function (id) {
    const list = EH.getCompare();
    if (list.includes(id)) {
      EH.saveCompare(list.filter(x => x !== id));
      EH.toast('Removed from compare');
      return false;
    }
    if (list.length >= EH.COMPARE_MAX) {
      EH.toast(`You can compare up to ${EH.COMPARE_MAX} products at a time`, 'error');
      return null;
    }
    list.push(id);
    EH.saveCompare(list);
    EH.toast('Added to compare');
    return true;
  };
  EH.clearCompare = () => { EH.saveCompare([]); };

  EH.renderCompareBar = function () {
    let bar = document.getElementById('ehCompareBar');
    const ids = EH.getCompare();
    if (ids.length === 0) {
      if (bar) bar.classList.remove('open');
      document.body.classList.remove('has-compare-bar');
      return;
    }
    if (!document.body) return; // bail if DOM not ready yet
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'ehCompareBar';
      bar.className = 'compare-bar';
      document.body.appendChild(bar);
    }
    document.body.classList.add('has-compare-bar');
    const slots = [];
    for (let i = 0; i < EH.COMPARE_MAX; i++) {
      const id = ids[i];
      if (id) {
        const p = EH.findProduct(id);
        if (!p) continue;
        slots.push(`
          <div class="compare-slot filled" title="${p.name}">
            <div class="cs-image"><img src="${EH.path(p.image)}" alt=""/></div>
            <div class="cs-info">
              <div class="cs-name">${p.name}</div>
              <div class="cs-brand">${p.brand}</div>
            </div>
            <button class="cs-remove" data-compare-remove="${p.id}" aria-label="Remove from compare">×</button>
          </div>
        `);
      } else {
        slots.push(`<div class="compare-slot empty"><span>Slot ${i + 1}</span></div>`);
      }
    }
    const canCompare = ids.length >= 2;
    bar.innerHTML = `
      <div class="compare-bar-inner">
        <div class="compare-bar-head">
          <div>
            <strong>Comparing ${ids.length} of ${EH.COMPARE_MAX} products</strong>
            <span class="muted small">${canCompare ? 'Ready to compare side by side' : 'Add at least 2 products to compare'}</span>
          </div>
          <div class="row" style="gap:8px;">
            <button type="button" class="btn btn-ghost btn-sm" id="ehCompareClear">Clear</button>
            <a href="${EH.path('pages/compare.html')}" id="ehCompareGo" class="btn btn-primary btn-sm">
              ${canCompare ? 'Compare now →' : 'Add 1 more to compare'}
            </a>
          </div>
        </div>
        <div class="compare-slots">${slots.join('')}</div>
      </div>
    `;
    bar.classList.add('open');

    bar.querySelector('#ehCompareClear').addEventListener('click', () => {
      EH.clearCompare();
      EH.toast('Compare list cleared');
    });
    const goBtn = bar.querySelector('#ehCompareGo');
    if (goBtn && !canCompare) {
      goBtn.addEventListener('click', (e) => {
        e.preventDefault();
        EH.toast('Pick one more product to compare', 'error');
      });
    }
    bar.querySelectorAll('[data-compare-remove]').forEach(b => b.addEventListener('click', () => {
      EH.saveCompare(EH.getCompare().filter(x => x !== b.dataset.compareRemove));
    }));
  };

  /* ---------- Auth state ---------- */
  // Auth state lives in sessionStorage — sign-out on browser close (security best practice)
  EH.getUser = () => SessionStore.get('eh_user', null);
  EH.setUser = (u) => SessionStore.set('eh_user', u);
  EH.logout = () => { SessionStore.remove('eh_user'); location.href = EH.path('index.html'); };

  /* ---------- Auth guards ---------- */
  EH.requireAuth = function (message) {
    const user = EH.getUser();
    if (user) return user;
    EH.toast(message || 'Please sign in to continue', 'error');
    // Remember where to come back to
    try { sessionStorage.setItem('eh_redirect', location.href); } catch (e) {}
    setTimeout(() => { location.href = EH.path('pages/login.html'); }, 700);
    return null;
  };
  EH.requireRole = function (role) {
    const user = EH.getUser();
    if (!user) {
      EH.toast('Please sign in to continue', 'error');
      try { sessionStorage.setItem('eh_redirect', location.href); } catch (e) {}
      setTimeout(() => { location.href = EH.path('pages/login.html'); }, 700);
      return null;
    }
    if (user.role !== role && user.role !== 'admin') {
      EH.toast('You do not have access to this page', 'error');
      setTimeout(() => { location.href = EH.path('index.html'); }, 800);
      return null;
    }
    return user;
  };
  // Render a friendly "sign in required" panel inside a mount element
  EH.renderAuthRequired = function (mount, title, message) {
    if (!mount) return;
    mount.innerHTML = `
      <div class="empty-state">
        <div class="icon">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <rect x="3" y="11" width="18" height="11" rx="2"/>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
          </svg>
        </div>
        <h3>${title || 'Sign in required'}</h3>
        <p>${message || 'Please sign in to your account to continue.'}</p>
        <div class="row" style="justify-content:center; gap:10px; margin-top:18px;">
          <a href="${EH.path('pages/login.html')}" class="btn btn-primary">Sign in</a>
          <a href="${EH.path('pages/register.html')}" class="btn btn-outline">Create account</a>
        </div>
      </div>`;
  };

  /* ---------- Toast ---------- */
  EH.toast = function (msg, type) {
    let stack = document.querySelector('.toast-stack');
    if (!stack) {
      stack = document.createElement('div');
      stack.className = 'toast-stack';
      document.body.appendChild(stack);
    }
    const t = document.createElement('div');
    t.className = 'toast' + (type ? ' ' + type : '');
    t.textContent = msg;
    stack.appendChild(t);
    setTimeout(() => { t.classList.add('fade-out'); setTimeout(() => t.remove(), 260); }, 2400);
  };

  /* ---------- Navbar / Footer rendering ---------- */
  EH.renderNavbar = function (activePage) {
    const user = EH.getUser();
    const isLoggedIn = !!user;
    const role = user?.role || 'customer';

    const userBtn = isLoggedIn
      ? `<div class="nav-icon-btn" title="${user.name}" onclick="EH.logout()" style="background:var(--color-bg-soft);font-size:13px;font-weight:600;width:auto;padding:0 14px;border-radius:999px;height:38px;">${user.name.split(' ')[0]} · Sign out</div>`
      : `<a href="${EH.path('pages/login.html')}" class="btn btn-secondary btn-sm">Sign in</a>`;

    const dashLink = role === 'seller'
      ? `<a href="${EH.path('pages/seller-dashboard.html')}" class="${activePage==='seller'?'active':''}">Seller</a>`
      : role === 'admin'
      ? `<a href="${EH.path('pages/admin-dashboard.html')}" class="${activePage==='admin'?'active':''}">Admin</a>`
      : '';

    const nav = `
      <nav class="navbar">
        <div class="nav-inner">
          <a href="${EH.path('index.html')}" class="brand">
            <span class="brand-mark">E</span>
            ElectroHub
          </a>
          <div class="nav-links">
            <a href="${EH.path('pages/products.html')}" class="${activePage==='products'?'active':''}">Shop</a>
            <a href="${EH.path('pages/products.html?cat=Laptops')}">Laptops</a>
            <a href="${EH.path('pages/products.html?cat=Phones')}">Phones</a>
            <a href="${EH.path('pages/products.html?cat=Audio')}">Audio</a>
            <a href="${EH.path('pages/support.html')}" class="${activePage==='support'?'active':''}">Support</a>
            ${dashLink}
          </div>
          <div class="nav-actions">
            <a href="${EH.path('pages/wishlist.html')}" class="nav-icon-btn" title="Wishlist" aria-label="Wishlist">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z"/></svg>
              <span class="badge" data-wish-count style="display:none">0</span>
            </a>
            <a href="${EH.path('pages/cart.html')}" class="nav-icon-btn" title="Cart" aria-label="Cart">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
              <span class="badge" data-cart-count style="display:none">0</span>
            </a>
            ${userBtn}
            <button class="hamburger" aria-label="Menu" id="ehHam">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
            </button>
          </div>
        </div>
      </nav>
      <div class="mobile-drawer" id="ehDrawer">
        <a href="${EH.path('pages/products.html')}">Shop</a>
        <a href="${EH.path('pages/products.html?cat=Laptops')}">Laptops</a>
        <a href="${EH.path('pages/products.html?cat=Phones')}">Phones</a>
        <a href="${EH.path('pages/products.html?cat=Audio')}">Audio</a>
        <a href="${EH.path('pages/wishlist.html')}">Wishlist</a>
        <a href="${EH.path('pages/cart.html')}">Cart</a>
        <a href="${EH.path('pages/support.html')}">Support</a>
        ${isLoggedIn ? `<a href="javascript:EH.logout()">Sign out</a>` : `<a href="${EH.path('pages/login.html')}">Sign in</a>`}
      </div>
    `;
    const mount = document.querySelector('[data-navbar]');
    if (mount) mount.innerHTML = nav;

    const ham = document.getElementById('ehHam');
    const drawer = document.getElementById('ehDrawer');
    if (ham && drawer) ham.addEventListener('click', () => drawer.classList.toggle('open'));
  };

  EH.renderFooter = function () {
    const f = `
      <footer class="footer">
        <div class="container">
          <div class="footer-grid">
            <div>
              <div class="brand">
                <span class="brand-mark">E</span> ElectroHub
              </div>
              <p>Premium electronics, curated. Built for people who appreciate craft, design, and lasting quality.</p>
            </div>
            <div>
              <h5>Shop</h5>
              <ul>
                <li><a href="${EH.path('pages/products.html?cat=Laptops')}">Laptops</a></li>
                <li><a href="${EH.path('pages/products.html?cat=Phones')}">Phones</a></li>
                <li><a href="${EH.path('pages/products.html?cat=Audio')}">Audio</a></li>
                <li><a href="${EH.path('pages/products.html?cat=Wearables')}">Wearables</a></li>
                <li><a href="${EH.path('pages/compare.html')}">Compare Products</a></li>
              </ul>
            </div>
            <div>
              <h5>Help</h5>
              <ul>
                <li><a href="${EH.path('pages/support.html')}">Support</a></li>
                <li><a href="${EH.path('pages/support.html')}">Shipping</a></li>
                <li><a href="${EH.path('pages/support.html')}">Returns</a></li>
                <li><a href="${EH.path('pages/support.html')}">Warranty</a></li>
              </ul>
            </div>
            <div>
              <h5>Account</h5>
              <ul>
                <li><a href="${EH.path('pages/login.html')}">Sign in</a></li>
                <li><a href="${EH.path('pages/register.html')}">Register</a></li>
                <li><a href="${EH.path('pages/seller-dashboard.html')}">Seller</a></li>
                <li><a href="${EH.path('pages/admin-dashboard.html')}">Admin</a></li>
              </ul>
            </div>
          </div>
          <div class="footer-bottom">
            <span>© 2026 ElectroHub Pvt. Ltd. All rights reserved. GST: 29AABCE1234F1Z5</span>
            <span>Made in India · Designed with care</span>
          </div>
        </div>
      </footer>
    `;
    const mount = document.querySelector('[data-footer]');
    if (mount) mount.innerHTML = f;
  };

  /* ---------- Star renderer ---------- */
  EH.stars = function (r) {
    const full = Math.round(r);
    return '★★★★★'.slice(0, full) + '☆☆☆☆☆'.slice(0, 5 - full);
  };

  /* ---------- Reviews seed for product details ---------- */
  EH.getReviews = function (productId) {
    const all = Store.get('eh_reviews', {});
    if (!all[productId]) {
      const seedSet = [
        { who: 'Alex M.', stars: 5, when: '3 weeks ago', text: 'Build quality is impressive. Light, fast, and the display is gorgeous. Worth every dollar.' },
        { who: 'Priya S.', stars: 4, when: '1 month ago', text: 'Solid product overall. Battery exceeds expectations. Minor learning curve with the new OS.' },
        { who: 'Daniel K.', stars: 5, when: '2 months ago', text: 'Replaced my older device with this. Night and day difference. Highly recommend.' }
      ];
      all[productId] = seedSet;
      Store.set('eh_reviews', all);
    }
    return all[productId];
  };
  EH.addReview = function (productId, review) {
    const all = Store.get('eh_reviews', {});
    if (!all[productId]) all[productId] = [];
    all[productId].unshift(review);
    Store.set('eh_reviews', all);
  };

  /* ---------- Orders (for invoice / dashboards) ---------- */
  EH.getOrders = () => Store.get('eh_orders', []);
  EH.saveOrders = (o) => Store.set('eh_orders', o);
  EH.addOrder = function (order) {
    const orders = EH.getOrders();
    orders.unshift(order);
    EH.saveOrders(orders);
  };

  /* ---------- Reports (admin) ---------- */
  EH.getReports = function () {
    let r = Store.get('eh_reports', null);
    if (!r) {
      r = [
        { id: 'r-001', type: 'Listing', subject: 'Counterfeit charger reported', reporter: 'arjun.k@example.com', status: 'open', priority: 'high', date: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString() },
        { id: 'r-002', type: 'Review', subject: 'Spam content on product review', reporter: 'moderator@electrohub.com', status: 'resolved', priority: 'low', date: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString() },
        { id: 'r-003', type: 'Refund', subject: 'Damaged in transit — refund requested', reporter: 'rohan.s@example.com', status: 'pending', priority: 'medium', date: new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString() },
        { id: 'r-004', type: 'Dispute', subject: 'Order not delivered', reporter: 'priya.m@example.com', status: 'open', priority: 'high', date: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString() }
      ];
      Store.set('eh_reports', r);
    }
    return r;
  };
  EH.saveReports = (r) => Store.set('eh_reports', r);

  /* ---------- Bootstrap on DOM ready ---------- */
  document.addEventListener('DOMContentLoaded', () => {
    EH.getProducts();
    EH.renderNavbar(document.body.dataset.page);
    EH.renderFooter();
    EH.updateNavBadges();
  });
})();
