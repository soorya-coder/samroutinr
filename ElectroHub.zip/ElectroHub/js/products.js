/* ===================================================================
   ElectroHub — products.js
   Listing (filters, sort, search), product card render, details page.
   =================================================================== */

(function () {
  'use strict';

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function tagBadge(tag) {
    if (!tag) return '';
    if (tag === 'new') return '<span class="tag tag-new">New</span>';
    if (tag === 'sale') return '<span class="tag tag-sale">Sale</span>';
    return '';
  }

  /* ---------- Card markup ---------- */
  // Inline-safe compare handler — guaranteed to run even if delegated handlers fail.
  // Returns false to suppress any default link/form behavior in the event chain.
  EH.cardCompareClick = function (ev, id) {
    if (ev) { ev.preventDefault(); ev.stopPropagation(); }
    const wasAdded = EH.toggleCompare(id);
    if (wasAdded === null) return false;
    // Re-sync every visible compare control for this product
    document.querySelectorAll('[data-compare="' + id + '"]').forEach(btn => {
      if (wasAdded) {
        btn.classList.add('active');
        btn.setAttribute('title', 'Remove from compare');
        btn.setAttribute('aria-label', 'Remove from compare');
        // Swap the inner label if it's the text variant
        const lbl = btn.querySelector('[data-compare-label]');
        if (lbl) lbl.textContent = '✓ Added to compare';
      } else {
        btn.classList.remove('active');
        btn.setAttribute('title', 'Add to compare');
        btn.setAttribute('aria-label', 'Add to compare');
        const lbl = btn.querySelector('[data-compare-label]');
        if (lbl) lbl.textContent = '+ Compare';
      }
    });
    return false;
  };

  EH.productCardHTML = function (p, opts) {
    opts = opts || {};
    const wished = EH.getWishlist().includes(p.id);
    const compared = EH.getCompare().includes(p.id);
    const oldPrice = p.oldPrice ? `<span class="price-old">${EH.formatPrice(p.oldPrice)}</span>` : '';
    const tag = tagBadge(p.tag);
    return `
      <div class="product-card" data-id="${p.id}">
        <button class="wish-btn ${wished ? 'active' : ''}" data-wish="${p.id}" aria-label="Add to wishlist" title="Wishlist">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="${wished?'currentColor':'none'}" stroke="currentColor" stroke-width="1.8"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z"/></svg>
        </button>
        <button type="button" class="compare-btn ${compared ? 'active' : ''}" data-compare="${p.id}" aria-label="${compared ? 'Remove from compare' : 'Add to compare'}" title="${compared ? 'Remove from compare' : 'Add to compare'}" onclick="return EH.cardCompareClick(event, '${p.id}')">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <polyline points="17 3 21 7 17 11"/>
            <line x1="3" y1="7" x2="21" y2="7"/>
            <polyline points="7 21 3 17 7 13"/>
            <line x1="21" y1="17" x2="3" y2="17"/>
          </svg>
        </button>
        <a href="${EH.path('pages/product-details.html?id=' + p.id)}" class="product-media">
          <img src="${EH.path(p.image)}" alt="${escapeHtml(p.name)}"/>
        </a>
        <div class="product-body">
          <div class="row" style="justify-content:space-between;">
            <span class="brand">${escapeHtml(p.brand)}</span>
            ${tag}
          </div>
          <a href="${EH.path('pages/product-details.html?id=' + p.id)}" class="name">${escapeHtml(p.name)}</a>
          <div class="rating"><span class="stars">${EH.stars(p.rating)}</span> ${p.rating.toFixed(1)} · ${p.reviews.toLocaleString()} reviews</div>
          <div class="price-row">
            <span class="price">${EH.formatPrice(p.price)}</span>
            ${oldPrice}
          </div>
          <div class="product-actions">
            <button class="btn btn-primary btn-sm btn-block" data-add="${p.id}">Add to Cart</button>
            <button type="button" class="btn btn-outline btn-sm btn-block compare-text-btn ${compared ? 'active' : ''}" data-compare="${p.id}" onclick="return EH.cardCompareClick(event, '${p.id}')" style="margin-top:6px;">
              <span data-compare-label>${compared ? '✓ Added to compare' : '+ Compare'}</span>
            </button>
          </div>
        </div>
      </div>
    `;
  };

  /* ---------- Card events (delegated) ---------- */
  function bindCardEvents(scope) {
    scope = scope || document;
    scope.addEventListener('click', (e) => {
      const addBtn = e.target.closest('[data-add]');
      if (addBtn) {
        e.preventDefault();
        if (!EH.requireAuth('Please sign in to add items to your cart')) return;
        EHCart.add(addBtn.dataset.add, 1);
        return;
      }
      // Compare buttons handle clicks via their inline onclick (EH.cardCompareClick).
      // The inline handler stopsPropagation, so this delegated branch is a safety net only.
      const compBtn = e.target.closest('[data-compare]');
      if (compBtn) {
        e.preventDefault();
        EH.cardCompareClick(e, compBtn.dataset.compare);
        return;
      }
      const wishBtn = e.target.closest('[data-wish]');
      if (wishBtn) {
        e.preventDefault();
        if (!EH.requireAuth('Please sign in to use your wishlist')) return;
        const id = wishBtn.dataset.wish;
        const wl = EH.getWishlist();
        if (wl.includes(id)) {
          EH.saveWishlist(wl.filter(x => x !== id));
          wishBtn.classList.remove('active');
          wishBtn.querySelector('svg').setAttribute('fill', 'none');
          EH.toast('Removed from wishlist');
        } else {
          wl.push(id);
          EH.saveWishlist(wl);
          wishBtn.classList.add('active');
          wishBtn.querySelector('svg').setAttribute('fill', 'currentColor');
          EH.toast('Saved to wishlist');
        }
      }
    });
  }

  /* ---------- Products listing page ---------- */
  function initListing() {
    const grid = document.getElementById('productGrid');
    if (!grid) return;

    const products = EH.getProducts();
    const categories = Array.from(new Set(products.map(p => p.category))).sort();
    const brands = Array.from(new Set(products.map(p => p.brand))).sort();

    // Render filter checkboxes
    const catBox = document.getElementById('filterCategories');
    const brandBox = document.getElementById('filterBrands');
    if (catBox) {
      catBox.innerHTML = categories.map(c => `
        <label class="checkbox"><input type="checkbox" value="${escapeHtml(c)}" data-filter="cat"> ${escapeHtml(c)}</label>
      `).join('');
    }
    if (brandBox) {
      brandBox.innerHTML = brands.map(b => `
        <label class="checkbox"><input type="checkbox" value="${escapeHtml(b)}" data-filter="brand"> ${escapeHtml(b)}</label>
      `).join('');
    }

    // URL param prefilters
    const params = new URLSearchParams(location.search);
    const presetCat = params.get('cat');
    if (presetCat && catBox) {
      const cb = catBox.querySelector(`input[value="${presetCat}"]`);
      if (cb) cb.checked = true;
    }
    const presetSearch = params.get('q');
    const searchInp = document.getElementById('searchInput');
    if (presetSearch && searchInp) searchInp.value = presetSearch;

    function getState() {
      const selCats = Array.from(document.querySelectorAll('[data-filter="cat"]:checked')).map(i => i.value);
      const selBrands = Array.from(document.querySelectorAll('[data-filter="brand"]:checked')).map(i => i.value);
      const minP = parseFloat(document.getElementById('minPrice')?.value) || 0;
      const maxP = parseFloat(document.getElementById('maxPrice')?.value) || Infinity;
      const rating = parseFloat(document.querySelector('[data-filter="rating"]:checked')?.value || '0');
      const search = (searchInp?.value || '').trim().toLowerCase();
      const sort = document.getElementById('sortBy')?.value || 'featured';
      return { selCats, selBrands, minP, maxP, rating, search, sort };
    }

    function render() {
      const s = getState();
      let list = products.filter(p => {
        if (s.selCats.length && !s.selCats.includes(p.category)) return false;
        if (s.selBrands.length && !s.selBrands.includes(p.brand)) return false;
        if (p.price < s.minP || p.price > s.maxP) return false;
        if (p.rating < s.rating) return false;
        if (s.search && !(p.name.toLowerCase().includes(s.search) || p.brand.toLowerCase().includes(s.search) || p.category.toLowerCase().includes(s.search))) return false;
        return true;
      });
      switch (s.sort) {
        case 'price-asc': list.sort((a, b) => a.price - b.price); break;
        case 'price-desc': list.sort((a, b) => b.price - a.price); break;
        case 'rating': list.sort((a, b) => b.rating - a.rating); break;
        case 'newest': list.sort((a, b) => (b.tag === 'new') - (a.tag === 'new')); break;
        default: break;
      }
      const countEl = document.querySelector('[data-count]');
      if (countEl) countEl.textContent = `${list.length} product${list.length === 1 ? '' : 's'}`;

      if (!list.length) {
        grid.innerHTML = `
          <div class="empty-state" style="grid-column:1/-1;">
            <div class="icon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></div>
            <h3>No products match your filters</h3>
            <p>Try clearing some filters or changing your search.</p>
          </div>`;
      } else {
        grid.innerHTML = list.map(p => EH.productCardHTML(p)).join('');
      }
    }

    // Wire events
    document.querySelectorAll('input[type="checkbox"][data-filter], input[type="radio"][data-filter]')
      .forEach(el => el.addEventListener('change', render));
    document.querySelectorAll('#minPrice, #maxPrice').forEach(el => el.addEventListener('input', render));
    document.getElementById('sortBy')?.addEventListener('change', render);
    if (searchInp) {
      searchInp.addEventListener('input', () => {
        // search validation
        if (!EHValidate.searchInput(searchInp.value)) {
          searchInp.style.borderColor = 'var(--color-danger)';
          return;
        }
        searchInp.style.borderColor = '';
        render();
      });
    }
    document.getElementById('clearFilters')?.addEventListener('click', () => {
      document.querySelectorAll('[data-filter]:checked').forEach(i => i.checked = false);
      const minP = document.getElementById('minPrice'); if (minP) minP.value = '';
      const maxP = document.getElementById('maxPrice'); if (maxP) maxP.value = '';
      if (searchInp) searchInp.value = '';
      render();
    });

    render();
  }

  /* ---------- Product details page ---------- */
  function initDetails() {
    const root = document.getElementById('productDetails');
    if (!root) return;

    const id = new URLSearchParams(location.search).get('id') || EH.getProducts()[0].id;
    const p = EH.findProduct(id);
    if (!p) {
      root.innerHTML = '<div class="empty-state"><h3>Product not found</h3><p>This item may have been removed.</p></div>';
      return;
    }

    // Crumbs + title
    document.title = p.name + ' · ElectroHub';
    const crumbs = document.getElementById('crumbs');
    if (crumbs) crumbs.innerHTML = `<a href="${EH.path('index.html')}">Home</a><span class="sep">/</span><a href="${EH.path('pages/products.html')}">Shop</a><span class="sep">/</span><a href="${EH.path('pages/products.html?cat=' + p.category)}">${p.category}</a><span class="sep">/</span>${escapeHtml(p.name)}`;

    const oldPrice = p.oldPrice ? `<span class="price-old">${EH.formatPrice(p.oldPrice)}</span>` : '';
    const saveAmt = p.oldPrice ? `<span class="save">Save ${EH.formatPrice(p.oldPrice - p.price)}</span>` : '';

    const colors = p.colors || [];
    const features = p.features || [];

    const specsRows = Object.entries(p.specs || {}).map(([k, v]) => `<tr><th>${escapeHtml(k)}</th><td>${escapeHtml(v)}</td></tr>`).join('');

    const wished = EH.getWishlist().includes(p.id);

    root.innerHTML = `
      <div class="pd-layout">
        <div class="pd-gallery">
          <div class="pd-main-image" id="pdMain"><img src="${EH.path(p.image)}" alt="${escapeHtml(p.name)}"/></div>
          <div class="pd-thumbs">
            <div class="pd-thumb active"><img src="${EH.path(p.image)}" alt=""/></div>
            <div class="pd-thumb"><img src="${EH.path(p.image)}" alt="" style="transform:scale(0.92);"/></div>
            <div class="pd-thumb"><img src="${EH.path(p.image)}" alt="" style="transform:scaleX(-1);"/></div>
            <div class="pd-thumb"><img src="${EH.path(p.image)}" alt="" style="opacity:.85;"/></div>
          </div>
        </div>
        <div class="pd-info">
          <div class="brand">${escapeHtml(p.brand)} · ${escapeHtml(p.category)}</div>
          <h1>${escapeHtml(p.name)}</h1>
          <div class="rating-row"><span class="stars">${EH.stars(p.rating)}</span> ${p.rating.toFixed(1)} · ${p.reviews.toLocaleString()} reviews · <span class="status-pill ok">In stock</span></div>
          <p class="muted" style="font-size:15px; margin-bottom:8px;">${escapeHtml(p.tagline || '')}</p>
          <div class="pd-price">
            <span class="price">${EH.formatPrice(p.price)}</span>
            ${oldPrice}
            ${saveAmt}
          </div>
          <ul class="pd-feat-list">${features.map(f => `<li>${escapeHtml(f)}</li>`).join('')}</ul>
          <div class="pd-options">
            ${colors.length ? `<div>
              <span class="opt-label">Color</span>
              <div class="swatches" id="pdSwatches">
                ${colors.map((c, i) => `<button class="swatch ${i===0?'active':''}" data-color="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join('')}
              </div>
            </div>` : ''}
            <div>
              <span class="opt-label">Quantity</span>
              <div class="qty-stepper">
                <button id="qtyDown" aria-label="Decrease">−</button>
                <span class="qty" id="qtyVal">1</span>
                <button id="qtyUp" aria-label="Increase">+</button>
              </div>
            </div>
          </div>
          <div class="pd-cta">
            <button class="btn btn-primary btn-lg" id="pdAdd">Add to Cart</button>
            <button class="btn btn-outline btn-lg" id="pdBuy">Buy Now</button>
            <button class="icon-btn ${wished?'active':''}" id="pdWish" title="Wishlist" style="width:48px;height:48px;border:1px solid var(--color-line);">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="${wished?'currentColor':'none'}" stroke="currentColor" stroke-width="1.8"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z"/></svg>
            </button>
            <button type="button" class="icon-btn pd-compare-btn ${EH.getCompare().includes(p.id)?'active':''}" id="pdCompare" title="${EH.getCompare().includes(p.id) ? 'Remove from compare' : 'Add to compare'}" style="width:48px;height:48px;border:1px solid var(--color-line);">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <polyline points="17 3 21 7 17 11"/>
                <line x1="3" y1="7" x2="21" y2="7"/>
                <polyline points="7 21 3 17 7 13"/>
                <line x1="21" y1="17" x2="3" y2="17"/>
              </svg>
            </button>
          </div>
          <div class="pd-meta">
            <div class="meta-row">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
              <div><h5>Free delivery</h5><p>2–4 business days</p></div>
            </div>
            <div class="meta-row">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
              <div><h5>2-year warranty</h5><p>Included free</p></div>
            </div>
            <div class="meta-row">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>
              <div><h5>30-day returns</h5><p>Hassle-free</p></div>
            </div>
            <div class="meta-row">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 12h18M3 6h18M3 18h18"/></svg>
              <div><h5>Installation &amp; Setup</h5><p>Free for 30 days</p></div>
            </div>
          </div>
        </div>
      </div>

      <div class="pd-tabs">
        <div class="pd-tab-nav">
          <button class="active" data-tab="desc">Description</button>
          <button data-tab="specs">Specifications</button>
          <button data-tab="reviews">Reviews</button>
          <button data-tab="install">Installation &amp; Setup</button>
        </div>
        <div class="pd-tab active" data-tab-pane="desc">
          <p style="font-size:15px; line-height:1.7; color:var(--color-ink-soft); max-width:780px;">
            ${escapeHtml(p.tagline || '')} The ${escapeHtml(p.name)} delivers refined performance in a thoughtfully engineered package. Each component is precision-tuned for everyday reliability and premium feel, with materials and finish that hold up over years of use.
          </p>
        </div>
        <div class="pd-tab" data-tab-pane="specs">
          <table class="spec-table">${specsRows}</table>
        </div>
        <div class="pd-tab" data-tab-pane="reviews" id="reviewsPane"></div>
        <div class="pd-tab" data-tab-pane="install" id="installPane">
          <!-- Service overview cards -->
          <div class="grid grid-3" style="margin-bottom:32px; gap:16px;">
            <div class="card-flat" style="text-align:center; padding:20px 16px;">
              <div style="font-size:28px; margin-bottom:8px;">🔧</div>
              <h4 style="margin-bottom:4px; font-size:14px;">Physical Installation</h4>
              <p class="muted small">Mounting, cabling, and hardware setup at your location.</p>
            </div>
            <div class="card-flat" style="text-align:center; padding:20px 16px;">
              <div style="font-size:28px; margin-bottom:8px;">⚙️</div>
              <h4 style="margin-bottom:4px; font-size:14px;">Device Configuration</h4>
              <p class="muted small">OS setup, accounts, Wi-Fi, software, and data migration.</p>
            </div>
            <div class="card-flat" style="text-align:center; padding:20px 16px;">
              <div style="font-size:28px; margin-bottom:8px;">📋</div>
              <h4 style="margin-bottom:4px; font-size:14px;">Walkthrough & Demo</h4>
              <p class="muted small">Technician explains features and answers your questions.</p>
            </div>
          </div>

          <h3 style="margin-bottom:4px;">Book Installation &amp; Setup</h3>
          <p class="muted small" style="margin-bottom:24px;">Available in 500+ cities across India · Certified technicians · Same-week slots</p>

          <form id="installForm" class="form" novalidate style="max-width:580px;">

            <!-- Service type -->
            <div class="field">
              <label>Service type</label>
              <select name="serviceType" required>
                <option value="">Choose a service…</option>
                <option value="install">Physical installation only</option>
                <option value="config">Device configuration &amp; setup only</option>
                <option value="both">Full installation + configuration</option>
                <option value="demo">Walkthrough &amp; demo only</option>
                <option value="migrate">Data migration assistance</option>
              </select>
              <div class="error"></div>
            </div>

            <!-- Configuration options (shown for config/both) -->
            <div id="configOptions" style="background:var(--color-bg-soft); border-radius:var(--radius-md); padding:16px; margin-bottom:4px;">
              <p style="font-size:13px; font-weight:500; margin-bottom:12px; color:var(--color-ink-soft);">Configuration options (select all that apply)</p>
              <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                <label class="checkbox"><input type="checkbox" name="cfg_os"/> OS installation &amp; updates</label>
                <label class="checkbox"><input type="checkbox" name="cfg_accounts"/> Account sign-in &amp; sync</label>
                <label class="checkbox"><input type="checkbox" name="cfg_wifi"/> Wi-Fi &amp; network setup</label>
                <label class="checkbox"><input type="checkbox" name="cfg_apps"/> App installation</label>
                <label class="checkbox"><input type="checkbox" name="cfg_migrate"/> Data transfer / migration</label>
                <label class="checkbox"><input type="checkbox" name="cfg_security"/> Security &amp; antivirus</label>
                <label class="checkbox"><input type="checkbox" name="cfg_peripherals"/> Peripheral pairing</label>
                <label class="checkbox"><input type="checkbox" name="cfg_backup"/> Backup configuration</label>
              </div>
            </div>

            <div class="field-row">
              <div class="field">
                <label>Preferred date</label>
                <input type="date" name="installDate" data-validate="date-future" required/>
                <div class="error"></div>
              </div>
              <div class="field">
                <label>Preferred time slot</label>
                <select name="timeSlot" required>
                  <option value="">Select slot…</option>
                  <option>9:00 AM – 12:00 PM</option>
                  <option>12:00 PM – 3:00 PM</option>
                  <option>3:00 PM – 6:00 PM</option>
                  <option>6:00 PM – 9:00 PM</option>
                </select>
                <div class="error"></div>
              </div>
            </div>

            <div class="field">
              <label>Full address</label>
              <textarea name="addr" data-validate="address" required placeholder="Flat / House no., Street, Area, Landmark…"></textarea>
              <div class="error"></div>
            </div>

            <div class="field-row">
              <div class="field">
                <label>City</label>
                <input type="text" name="city" data-validate="required-text" required placeholder="e.g. Bengaluru"/>
                <div class="error"></div>
              </div>
              <div class="field">
                <label>PIN code</label>
                <input type="text" name="pin" data-validate="pin" required inputmode="numeric" maxlength="6" placeholder="6-digit PIN"/>
                <div class="error"></div>
              </div>
            </div>

            <div class="field">
              <label>Mobile number</label>
              <input type="tel" name="phone" data-validate="phone" required placeholder="+91 XXXXX XXXXX"/>
              <div class="error"></div>
            </div>

            <div class="field">
              <label>Special instructions <span class="muted">(optional)</span></label>
              <textarea name="notes" placeholder="e.g. 2nd floor, call before arriving…" style="min-height:64px;"></textarea>
            </div>

            <div style="background:var(--color-accent-soft); border-radius:var(--radius-md); padding:14px 16px; font-size:13px; color:var(--color-ink-soft); margin-bottom:4px;">
              <strong style="color:var(--color-ink);">Free with purchase.</strong> Installation &amp; configuration is complimentary for 30 days after delivery. After that, standard service charges apply.
            </div>

            <button class="btn btn-primary btn-lg" type="submit" data-submit>Confirm Booking</button>
          </form>
        </div>
      </div>
    `;

    // Min date for installation — must be today or future
    const dateInp = root.querySelector('input[name="installDate"]');
    if (dateInp) dateInp.min = new Date().toISOString().split('T')[0];

    // Show/hide configuration options based on service type
    const svcSelect = root.querySelector('select[name="serviceType"]');
    const cfgOpts   = root.querySelector('#configOptions');
    if (svcSelect && cfgOpts) {
      const toggleCfg = () => {
        const show = ['config', 'both', 'migrate'].includes(svcSelect.value);
        cfgOpts.style.display = show ? '' : 'none';
      };
      toggleCfg();
      svcSelect.addEventListener('change', toggleCfg);
    }

    // Thumbs swap
    root.querySelectorAll('.pd-thumb').forEach((t, i) => {
      t.addEventListener('click', () => {
        root.querySelectorAll('.pd-thumb').forEach(x => x.classList.remove('active'));
        t.classList.add('active');
      });
    });

    // Swatches
    root.querySelectorAll('#pdSwatches .swatch').forEach(s => s.addEventListener('click', () => {
      root.querySelectorAll('#pdSwatches .swatch').forEach(x => x.classList.remove('active'));
      s.classList.add('active');
    }));

    // Quantity
    let qty = 1;
    const qtyVal = document.getElementById('qtyVal');
    document.getElementById('qtyDown').addEventListener('click', () => { qty = Math.max(1, qty - 1); qtyVal.textContent = qty; });
    document.getElementById('qtyUp').addEventListener('click', () => { qty = Math.min(99, qty + 1); qtyVal.textContent = qty; });

    document.getElementById('pdAdd').addEventListener('click', () => {
      if (!EH.requireAuth('Please sign in to add items to your cart')) return;
      EHCart.add(p.id, qty);
    });
    document.getElementById('pdBuy').addEventListener('click', () => {
      if (!EH.requireAuth('Please sign in to continue to checkout')) return;
      EHCart.add(p.id, qty);
      setTimeout(() => location.href = 'checkout.html', 300);
    });
    document.getElementById('pdCompare').addEventListener('click', (e) => {
      e.preventDefault();
      const btn = e.currentTarget;
      const wasAdded = EH.toggleCompare(p.id);
      if (wasAdded === null) return;
      if (wasAdded) {
        btn.classList.add('active');
        btn.setAttribute('title', 'Remove from compare');
      } else {
        btn.classList.remove('active');
        btn.setAttribute('title', 'Add to compare');
      }
    });
    document.getElementById('pdWish').addEventListener('click', (e) => {
      if (!EH.requireAuth('Please sign in to use your wishlist')) return;
      const wl = EH.getWishlist();
      const btn = e.currentTarget;
      if (wl.includes(p.id)) {
        EH.saveWishlist(wl.filter(x => x !== p.id));
        btn.classList.remove('active');
        btn.querySelector('svg').setAttribute('fill', 'none');
      } else {
        wl.push(p.id);
        EH.saveWishlist(wl);
        btn.classList.add('active');
        btn.querySelector('svg').setAttribute('fill', 'currentColor');
      }
    });

    // Tabs
    root.querySelectorAll('.pd-tab-nav button').forEach(btn => btn.addEventListener('click', () => {
      root.querySelectorAll('.pd-tab-nav button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      root.querySelectorAll('.pd-tab').forEach(pane => pane.classList.remove('active'));
      root.querySelector(`[data-tab-pane="${btn.dataset.tab}"]`).classList.add('active');
    }));

    // Reviews pane
    renderReviews(p);

    // Install form bind
    const instForm = document.getElementById('installForm');
    if (instForm) {
      EHValidate.bind(instForm);
      instForm.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!EH.requireAuth('Please sign in to book installation')) return;

        // Validate required selects manually
        const svc = instForm.serviceType;
        if (!svc.value) {
          svc.style.borderColor = 'var(--color-danger)';
          EH.toast('Please choose a service type.', 'error');
          return;
        }
        svc.style.borderColor = '';

        const slot = instForm.timeSlot;
        if (!slot.value) {
          slot.style.borderColor = 'var(--color-danger)';
          EH.toast('Please select a time slot.', 'error');
          return;
        }
        slot.style.borderColor = '';

        if (!EHValidate.validateAll(instForm)) {
          EH.toast('Please correct the highlighted fields.', 'error');
          return;
        }

        const svcLabels = {
          install: 'Physical Installation',
          config: 'Device Configuration',
          both: 'Full Installation + Configuration',
          demo: 'Walkthrough & Demo',
          migrate: 'Data Migration'
        };
        const cfgSelected = Array.from(instForm.querySelectorAll('input[name^="cfg_"]:checked'))
          .map(cb => cb.closest('label').textContent.trim()).join(', ');

        EH.toast(`Booking confirmed! ${svcLabels[svc.value]} on ${instForm.installDate.value} (${instForm.timeSlot.value}). We'll SMS you within 2 hours.`, 'success');
        instForm.reset();
        if (instForm.querySelector('#configOptions')) instForm.querySelector('#configOptions').style.display = 'none';
      });
    }
  }

  function renderReviews(p) {
    const pane = document.getElementById('reviewsPane');
    if (!pane) return;
    const reviews = EH.getReviews(p.id);
    const total = reviews.length;
    const buckets = [0,0,0,0,0];
    reviews.forEach(r => buckets[5 - r.stars] = (buckets[5 - r.stars]||0) + 1);
    const avg = total ? (reviews.reduce((s, r) => s + r.stars, 0) / total) : 0;

    pane.innerHTML = `
      <div class="review-summary">
        <div class="big-score">
          <div class="n">${avg.toFixed(1)}</div>
          <div class="stars">${EH.stars(avg)}</div>
          <div class="count">${total} review${total===1?'':'s'}</div>
        </div>
        <div class="review-bars">
          ${[5,4,3,2,1].map(star => {
            const count = reviews.filter(r => r.stars === star).length;
            const pct = total ? (count / total * 100) : 0;
            return `<div class="review-bar"><span>${star}★</span><div class="track"><div class="fill" style="width:${pct}%"></div></div><span>${count}</span></div>`;
          }).join('')}
        </div>
      </div>

      <form class="form" id="reviewForm" novalidate style="margin-bottom:24px;">
        <h4 style="margin-bottom:12px;">Write a review</h4>
        <div class="field">
          <label>Your rating</label>
          <div id="ratingPick" style="display:flex;gap:4px;font-size:24px;color:#d2d2d7;cursor:pointer;">
            <span data-r="1">★</span><span data-r="2">★</span><span data-r="3">★</span><span data-r="4">★</span><span data-r="5">★</span>
          </div>
        </div>
        <div class="field">
          <label>Your review</label>
          <textarea name="text" data-validate="required-text" required minlength="10"></textarea>
          <div class="error"></div>
        </div>
        <button class="btn btn-primary" data-submit>Submit Review</button>
      </form>

      <div class="review-list">
        ${reviews.map(r => `
          <div class="review">
            <div class="review-head"><span class="who">${r.who}</span><span class="when">${r.when}</span></div>
            <div class="stars">${EH.stars(r.stars)}</div>
            <p>${r.text}</p>
          </div>
        `).join('')}
      </div>
    `;

    const form = document.getElementById('reviewForm');
    EHValidate.bind(form);
    let chosen = 0;
    const pick = document.getElementById('ratingPick');
    pick.querySelectorAll('span').forEach(sp => {
      sp.addEventListener('click', () => {
        chosen = parseInt(sp.dataset.r, 10);
        pick.querySelectorAll('span').forEach(s2 => {
          s2.style.color = parseInt(s2.dataset.r, 10) <= chosen ? '#b8860b' : '#d2d2d7';
        });
      });
    });
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!EH.requireAuth('Please sign in to write a review')) return;
      if (!chosen) { EH.toast('Please select a rating.', 'error'); return; }
      if (!EHValidate.validateAll(form)) { EH.toast('Review text required.', 'error'); return; }
      const user = EH.getUser();
      EH.addReview(p.id, {
        who: user ? user.name : 'Guest',
        stars: chosen,
        when: 'just now',
        text: form.text.value.trim()
      });
      EH.toast('Thanks for your review!', 'success');
      renderReviews(p);
    });
  }

  /* ---------- COMPARE PAGE ---------- */
  function initComparePage() {
    const root = document.getElementById('comparePage');
    if (!root) return;

    function render() {
      const ids = EH.getCompare();
      const items = ids.map(id => EH.findProduct(id)).filter(Boolean);

      if (items.length === 0) {
        root.innerHTML = `
          <div class="empty-state">
            <div class="icon">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 6h18"/><path d="M6 6l-3 9h6L6 6z"/><path d="M18 6l-3 9h6L18 6z"/><path d="M12 4v17"/><path d="M8 21h8"/></svg>
            </div>
            <h3>Nothing to compare yet</h3>
            <p>Add at least two products to your compare list — look for the compare icon on any product card.</p>
            <a href="products.html" class="btn btn-primary" style="margin-top:16px;">Browse products</a>
          </div>`;
        return;
      }

      // Collect union of all spec keys, preserving order
      const specKeys = [];
      items.forEach(p => {
        Object.keys(p.specs || {}).forEach(k => {
          if (!specKeys.includes(k)) specKeys.push(k);
        });
      });

      // Helper to determine if values in a row are all equal (so we can highlight diffs)
      const rowDiffers = (values) => {
        const first = values[0];
        return values.some(v => v !== first);
      };

      const headerCells = items.map(p => `
        <th class="compare-prod-cell">
          <button class="compare-prod-remove" data-cp-remove="${p.id}" title="Remove">×</button>
          <div class="compare-prod-img"><img src="${EH.path(p.image)}" alt=""/></div>
          <div class="compare-prod-brand">${p.brand}</div>
          <a href="product-details.html?id=${p.id}" class="compare-prod-name">${p.name}</a>
          <div class="compare-prod-rating"><span style="color:#b8860b;">${EH.stars(p.rating)}</span> <span class="muted small">${p.rating.toFixed(1)}</span></div>
          <div class="compare-prod-price">${EH.formatPrice(p.price)}</div>
          <button class="btn btn-primary btn-sm btn-block" data-cp-add="${p.id}" style="margin-top:8px;">Add to Cart</button>
        </th>
      `).join('');

      // Build spec rows
      const priceRow = `
        <tr>
          <th class="spec-key">Price</th>
          ${items.map(p => `<td class="${rowDiffers(items.map(x=>x.price)) ? 'diff' : ''}"><strong>${EH.formatPrice(p.price)}</strong>${p.oldPrice ? `<br/><span class="muted small" style="text-decoration:line-through;">${EH.formatPrice(p.oldPrice)}</span>` : ''}</td>`).join('')}
        </tr>`;
      const categoryRow = `
        <tr>
          <th class="spec-key">Category</th>
          ${items.map(p => `<td class="${rowDiffers(items.map(x=>x.category)) ? 'diff' : ''}">${p.category}</td>`).join('')}
        </tr>`;
      const ratingRow = `
        <tr>
          <th class="spec-key">Rating</th>
          ${items.map(p => `<td class="${rowDiffers(items.map(x=>x.rating)) ? 'diff' : ''}">${p.rating.toFixed(1)} <span class="muted small">(${p.reviews.toLocaleString()})</span></td>`).join('')}
        </tr>`;
      const stockRow = `
        <tr>
          <th class="spec-key">Availability</th>
          ${items.map(p => `<td>${p.stock > 0 ? `<span class="status-pill ok">In stock · ${p.stock}</span>` : '<span class="status-pill fail">Out</span>'}</td>`).join('')}
        </tr>`;
      const sellerRow = `
        <tr>
          <th class="spec-key">Sold by</th>
          ${items.map(p => `<td class="${rowDiffers(items.map(x=>x.seller||'')) ? 'diff' : ''}">${p.seller || p.brand}</td>`).join('')}
        </tr>`;
      const colorsRow = `
        <tr>
          <th class="spec-key">Colors</th>
          ${items.map(p => `<td>${(p.colors || []).join(', ') || '—'}</td>`).join('')}
        </tr>`;
      const featuresRow = `
        <tr>
          <th class="spec-key">Key features</th>
          ${items.map(p => `<td><ul class="compare-feat">${(p.features || []).slice(0, 4).map(f => `<li>${f}</li>`).join('')}</ul></td>`).join('')}
        </tr>`;

      const specRows = specKeys.map(k => {
        const vals = items.map(p => (p.specs && p.specs[k]) ? p.specs[k] : '—');
        const cells = vals.map(v => `<td class="${rowDiffers(vals) ? 'diff' : ''}">${v}</td>`).join('');
        return `<tr><th class="spec-key">${k}</th>${cells}</tr>`;
      }).join('');

      root.innerHTML = `
        <div class="row-between" style="margin-bottom:18px; flex-wrap:wrap; gap:12px;">
          <p class="muted small mt-0">
            Comparing <strong style="color:var(--color-ink);">${items.length}</strong> product${items.length === 1 ? '' : 's'} · differences are highlighted
          </p>
          <div class="row" style="gap:8px;">
            <a href="products.html" class="btn btn-outline btn-sm">+ Add more</a>
            <button class="btn btn-ghost btn-sm" id="cpClear" style="color:var(--color-danger);">Clear all</button>
          </div>
        </div>

        <div class="compare-table-wrap">
          <table class="compare-table">
            <thead>
              <tr>
                <th class="spec-key"></th>
                ${headerCells}
              </tr>
            </thead>
            <tbody>
              ${priceRow}
              ${categoryRow}
              ${ratingRow}
              ${stockRow}
              ${sellerRow}
              ${colorsRow}
              ${featuresRow}
              ${specRows}
            </tbody>
          </table>
        </div>
      `;

      // Wire actions
      root.querySelectorAll('[data-cp-remove]').forEach(b => b.addEventListener('click', () => {
        EH.saveCompare(EH.getCompare().filter(x => x !== b.dataset.cpRemove));
        render();
      }));
      root.querySelectorAll('[data-cp-add]').forEach(b => b.addEventListener('click', () => {
        if (!EH.requireAuth('Please sign in to add items to your cart')) return;
        EHCart.add(b.dataset.cpAdd, 1);
      }));
      document.getElementById('cpClear')?.addEventListener('click', () => {
        if (!confirm('Remove all products from compare?')) return;
        EH.clearCompare();
        render();
      });
    }

    render();
  }

  /* ---------- Home featured ---------- */
  function initHomeFeatured() {
    const featured = document.getElementById('featuredGrid');
    if (!featured) return;
    const products = EH.getProducts().slice(0, 8);
    featured.innerHTML = products.map(p => EH.productCardHTML(p)).join('');
  }

  /* ---------- Init ---------- */
  document.addEventListener('DOMContentLoaded', () => {
    bindCardEvents(document);
    initListing();
    initDetails();
    initHomeFeatured();
    initComparePage();
  });
})();
