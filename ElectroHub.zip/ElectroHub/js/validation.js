/* ===================================================================
   ElectroHub — validation.js
   Reusable validators + real-time form binding.
   =================================================================== */

(function () {
  'use strict';

  const V = {};
  window.EHValidate = V;

  /* ---------- Core checks ---------- */
  V.required = (v) => v != null && String(v).trim().length > 0;

  V.name = (v) => {
    const s = String(v || '').trim();
    return s.length >= 2 && /^[a-zA-Z][a-zA-Z\s.''-]{1,48}$/.test(s);
  };

  V.email = (v) => {
    const s = String(v || '').trim();
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s) && s.length <= 254;
  };

  V.phone = (v) => {
    const digits = String(v || '').replace(/\D/g, '');
    return digits.length >= 10 && digits.length <= 15;
  };

  V.address = (v) => String(v || '').trim().length >= 8;

  V.pin = (v) => /^\d{5,6}$/.test(String(v || '').trim());

  V.password = (v) => String(v || '').length >= 8;

  V.passwordStrength = function (v) {
    const s = String(v || '');
    let score = 0;
    if (s.length >= 8) score++;
    if (/[A-Z]/.test(s) && /[a-z]/.test(s)) score++;
    if (/\d/.test(s)) score++;
    if (/[^A-Za-z0-9]/.test(s)) score++;
    return score; // 0..4
  };

  V.match = (a, b) => a != null && String(a) === String(b) && String(a).length > 0;

  V.price = (v) => {
    const n = Number(v);
    return Number.isFinite(n) && n > 0 && n < 10000000;
  };

  V.quantity = (v) => {
    const n = Number(v);
    return Number.isInteger(n) && n >= 1 && n <= 999;
  };

  V.upi = (v) => /^[a-zA-Z0-9._-]{2,}@[a-zA-Z]{2,}$/.test(String(v || '').trim());

  V.cardNumber = function (v) {
    const s = String(v || '').replace(/\s+/g, '');
    if (!/^\d{13,19}$/.test(s)) return false;
    // Luhn
    let sum = 0, alt = false;
    for (let i = s.length - 1; i >= 0; i--) {
      let n = parseInt(s.charAt(i), 10);
      if (alt) { n *= 2; if (n > 9) n -= 9; }
      sum += n; alt = !alt;
    }
    return sum % 10 === 0;
  };

  V.cvv = (v) => /^\d{3,4}$/.test(String(v || '').trim());

  V.expiryFuture = function (mm, yy) {
    const m = parseInt(mm, 10);
    let y = parseInt(yy, 10);
    if (!Number.isFinite(m) || !Number.isFinite(y)) return false;
    if (m < 1 || m > 12) return false;
    if (y < 100) y += 2000; // YY -> 20YY
    const now = new Date();
    const expEnd = new Date(y, m, 0, 23, 59, 59); // last day of expiry month
    return expEnd >= new Date(now.getFullYear(), now.getMonth(), 1);
  };

  V.notPast = function (dateStr) {
    if (!dateStr) return false;
    const d = new Date(dateStr);
    if (isNaN(d)) return false;
    const today = new Date(); today.setHours(0,0,0,0);
    return d >= today;
  };

  V.notFuture = function (dateStr) {
    if (!dateStr) return false;
    const d = new Date(dateStr);
    if (isNaN(d)) return false;
    const today = new Date(); today.setHours(23,59,59,999);
    return d <= today;
  };

  V.validDate = function (dateStr) {
    if (!dateStr) return false;
    const d = new Date(dateStr);
    return !isNaN(d.getTime());
  };

  V.searchInput = (v) => {
    const s = String(v || '').trim();
    // allow empty (no search); reject only weird control chars
    return s.length <= 100 && !/[<>]/.test(s);
  };

  /* ---------- DOM helpers ---------- */
  function showError(input, msg) {
    const field = input.closest('.field');
    if (!field) return;
    field.classList.add('error');
    field.classList.remove('valid');
    const err = field.querySelector('.error');
    if (err) err.textContent = msg;
  }
  function showValid(input) {
    const field = input.closest('.field');
    if (!field) return;
    field.classList.remove('error');
    field.classList.add('valid');
    const err = field.querySelector('.error');
    if (err) err.textContent = '';
  }
  function reset(input) {
    const field = input.closest('.field');
    if (!field) return;
    field.classList.remove('error');
    field.classList.remove('valid');
    const err = field.querySelector('.error');
    if (err) err.textContent = '';
  }
  V.showError = showError;
  V.showValid = showValid;
  V.reset = reset;

  /* ---------- Generic field-binding by data-validate attribute ----- */
  V.bind = function (form, opts) {
    opts = opts || {};
    const checks = {};

    form.querySelectorAll('[data-validate]').forEach((input) => {
      const rule = input.dataset.validate;
      const matchTarget = input.dataset.match;
      const check = function () {
        const val = input.value;
        let ok = true, msg = '';

        if (input.required && !V.required(val)) { ok = false; msg = 'This field is required.'; }
        else if (val === '' && !input.required) { reset(input); return true; }
        else {
          switch (rule) {
            case 'name': ok = V.name(val); msg = 'Enter a valid name (letters only, 2+ chars).'; break;
            case 'email': ok = V.email(val); msg = 'Enter a valid email address.'; break;
            case 'phone': ok = V.phone(val); msg = 'Enter a valid phone number (10–15 digits).'; break;
            case 'address': ok = V.address(val); msg = 'Address must be at least 8 characters.'; break;
            case 'pin': ok = V.pin(val); msg = 'Enter a valid 5–6 digit PIN code.'; break;
            case 'password': ok = V.password(val); msg = 'Password must be at least 8 characters.'; break;
            case 'price': ok = V.price(val); msg = 'Enter a valid price greater than 0.'; break;
            case 'quantity': ok = V.quantity(val); msg = 'Quantity must be 1–999.'; break;
            case 'upi': ok = V.upi(val); msg = 'Enter a valid UPI ID (e.g. name@bank).'; break;
            case 'card': ok = V.cardNumber(val); msg = 'Enter a valid card number.'; break;
            case 'cvv': ok = V.cvv(val); msg = 'CVV must be 3 or 4 digits.'; break;
            case 'expiry':
              {
                const parts = val.split('/');
                ok = parts.length === 2 && V.expiryFuture(parts[0].trim(), parts[1].trim());
                msg = 'Card expiry must be MM/YY and not in the past.';
              }
              break;
            case 'date-future': ok = V.notPast(val); msg = 'Date cannot be in the past.'; break;
            case 'date-past': ok = V.notFuture(val); msg = 'Date cannot be in the future.'; break;
            case 'search': ok = V.searchInput(val); msg = 'Search query is invalid.'; break;
            case 'match':
              {
                const other = matchTarget ? form.querySelector('[name="' + matchTarget + '"]') : null;
                ok = other ? V.match(val, other.value) : false;
                msg = 'Values do not match.';
              }
              break;
            case 'required-text': ok = V.required(val); msg = 'This field is required.'; break;
            default:
              ok = true;
          }
        }

        if (ok) showValid(input); else showError(input, msg);
        return ok;
      };

      checks[input.name || input.id || Math.random()] = check;

      input.addEventListener('input', () => {
        check();
        V.refreshSubmit(form);
      });
      input.addEventListener('blur', () => { check(); V.refreshSubmit(form); });
    });

    // Card expiry MM/YY auto-format
    form.querySelectorAll('[data-format="expiry"]').forEach((inp) => {
      inp.addEventListener('input', () => {
        let v = inp.value.replace(/\D/g, '').slice(0, 4);
        if (v.length >= 3) v = v.slice(0, 2) + '/' + v.slice(2);
        inp.value = v;
      });
    });
    // Card number auto-format with spaces
    form.querySelectorAll('[data-format="card"]').forEach((inp) => {
      inp.addEventListener('input', () => {
        let v = inp.value.replace(/\D/g, '').slice(0, 19);
        inp.value = v.replace(/(\d{4})(?=\d)/g, '$1 ');
      });
    });

    form._ehChecks = checks;
    V.refreshSubmit(form);
  };

  V.validateAll = function (form) {
    if (!form._ehChecks) return true;
    let ok = true;
    Object.values(form._ehChecks).forEach(fn => { if (!fn()) ok = false; });
    return ok;
  };

  V.refreshSubmit = function (form) {
    const submitBtn = form.querySelector('[data-submit]');
    if (!submitBtn || !form._ehChecks) return;
    // Required fields all filled?
    let allRequiredFilled = true;
    form.querySelectorAll('[required]').forEach(inp => {
      if (!V.required(inp.value)) allRequiredFilled = false;
    });
    // No visible errors?
    const hasError = form.querySelector('.field.error');
    submitBtn.disabled = !allRequiredFilled || !!hasError;
  };

  /* ---------- Password strength meter binding ---------- */
  V.bindPasswordMeter = function (input, meter, label) {
    input.addEventListener('input', () => {
      const s = V.passwordStrength(input.value);
      meter.className = 'password-strength lvl-' + s;
      if (label) {
        label.textContent = ['Too weak', 'Weak', 'Fair', 'Good', 'Strong'][s] || '';
      }
    });
  };
})();
