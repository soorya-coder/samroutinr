# ElectroHub — Defect Log

**Project:** ElectroHub Static Frontend
**Tracker prefix:** DEF-
**Severity levels:** Critical · Major · Minor · Cosmetic
**Status workflow:** Open → In Progress → Fixed → Verified → Closed

---

## Summary

| Severity   | Open | In Progress | Fixed | Verified | Closed | Total |
|-----------|-----:|------------:|------:|---------:|-------:|------:|
| Critical  | 0    | 0           | 0     | 0        | 6      | 6     |
| Major     | 0    | 0           | 0     | 0        | 11     | 11    |
| Minor     | 0    | 0           | 0     | 0        | 9      | 9     |
| Cosmetic  | 0    | 0           | 0     | 0        | 7      | 7     |
| **Total** | **0**| **0**       | **0** | **0**    | **33** | **33**|

---

## DEF-001 — Compare button does nothing when clicked

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Critical                                                              |
| Module        | Product compare                                                       |
| Found in      | Sprint 4, US-023                                                      |
| Reported by   | QA                                                                    |
| Status        | Closed                                                                |
| Fixed in      | Sprint 4 hotfix                                                       |

**Steps to reproduce**
1. Open products listing page as a guest.
2. Click the compare icon (top-right of any product card).

**Expected:** Compare bar slides up from bottom; product added to compare; toast confirms.
**Actual:** No visible feedback; clicking another link sometimes navigates user to product listing, leaving the impression nothing happened.

**Root cause:** The icon-only button at top-right of the card wasn't immediately discoverable, and the slide-up bar at the bottom of the viewport was easy to miss when scrolled mid-page.

**Resolution:** Added a second, text-labeled compare button (`+ Compare`) directly under "Add to Cart" inside the card body. Switched the click handler to an inline `onclick="return EH.cardCompareClick(...)"` so the toggle runs even if delegated handlers fail. The floating bar now has a 3 px accent border-top and a pulse animation on first appearance.

---

## DEF-002 — Sellers see all products instead of only their own catalog

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Major                                                                 |
| Module        | Seller dashboard                                                      |
| Found in      | Sprint 3                                                              |
| Reported by   | PO                                                                    |
| Status        | Closed                                                                |
| Fixed in      | Sprint 4                                                              |

**Steps to reproduce**
1. Sign in as `seller@electrohub.com` (Nova Direct).
2. Open Products tab in the seller dashboard.

**Expected:** Only Nova Direct's products are listed.
**Actual:** All 17 catalog products listed regardless of seller.

**Resolution:** `myProducts()` filter added in `dashboard.js` — filters products where `seller === currentUser.name`. KPIs (revenue, orders, avg) now compute from the seller's own orders only.

---

## DEF-003 — New seller-created products missing `seller` field

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Major                                                                 |
| Module        | Seller dashboard / Product CRUD                                       |
| Found in      | Sprint 3                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 4                                                              |

**Steps**
1. Sign in as a seller and create a new product.
2. Open admin moderation tab.

**Expected:** New product shown with seller name attributed.
**Actual:** Product appeared but `seller` field was undefined, falling back to `brand` value.

**Resolution:** Product creation in `dashboard.js openProductForm()` now stamps `seller: sellerName()` and `createdAt` on insert.

---

## DEF-004 — Sellers can access dashboard without admin approval

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Critical                                                              |
| Module        | Auth / Seller onboarding                                              |
| Found in      | Sprint 3                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 4                                                              |

**Steps**
1. Register a new account with role "Seller".
2. Land on the seller dashboard immediately with full CRUD access.

**Expected:** New sellers should be marked "Pending" and gated until an admin approves.
**Actual:** Anyone could register as a seller and immediately add products.

**Resolution:** Added `status` field to user schema. New sellers default to `pending`. Seller dashboard now checks `user.status === 'approved'` and shows a friendly "Awaiting admin approval" panel otherwise. Admin's Sellers and Overview tabs surface the pending queue with Approve / Reject actions that persist the status change.

---

## DEF-005 — Card number accepted without Luhn validation

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Critical                                                              |
| Module        | Checkout / Payment                                                    |
| Found in      | Sprint 2                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 2                                                              |

**Steps**
1. At checkout, enter "1234 5678 9012 3456" as card number.
2. Fill other valid fields and submit.

**Expected:** Field flagged as invalid.
**Actual:** Form submitted successfully with a structurally invalid card.

**Resolution:** Implemented Luhn algorithm in `EHValidate.cardNumber()`. Submission now blocked unless the digits pass mod-10 check.

---

## DEF-006 — Expired card accepted at checkout

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Critical                                                              |
| Module        | Checkout / Payment                                                    |
| Found in      | Sprint 2                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 2                                                              |

**Steps**
1. Enter expiry "01/22" (past month).
2. Submit.

**Expected:** "Card expiry must not be in the past."
**Actual:** Form accepted the value and created an order.

**Resolution:** `EHValidate.expiryFuture(mm, yy)` now compares the last day of the expiry month with the first day of the current month. Past dates are rejected with an inline error.

---

## DEF-007 — Past dates allowed for delivery and installation

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Major                                                                 |
| Module        | Validation / Checkout / Install booking                               |
| Found in      | Sprint 2                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 2                                                              |

**Steps**
1. Open the date picker on the checkout delivery field or the installation form.
2. Select yesterday's date.

**Expected:** Date rejected.
**Actual:** Accepted.

**Resolution:** `data-validate="date-future"` added to both date inputs. JS also sets `dateInput.min = today` so the browser-native picker disables earlier days.

---

## DEF-008 — Future birth date accepted on registration

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Major                                                                 |
| Module        | Validation / Register                                                 |
| Found in      | Sprint 1                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 1                                                              |

**Resolution:** `data-validate="date-past"` rule added; `dob.max = today` set programmatically. Future dates are now blocked with inline error.

---

## DEF-009 — Compare list lost on page navigation

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Critical                                                              |
| Module        | Product compare / Storage                                             |
| Found in      | Sprint 4                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 4                                                              |

**Steps**
1. Add 2 products to compare on the products page.
2. Navigate to compare.html.

**Expected:** Both products appear in the table.
**Actual:** Compare list was empty.

**Root cause:** Compare state was held in a JS variable inside an IIFE, not persisted to storage.

**Resolution:** Compare list now persisted in `sessionStorage` under `eh_compare`. `EH.getCompare/saveCompare` read/write through `SessionStore`.

---

## DEF-010 — Cart badge stale after add/remove

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Major                                                                 |
| Module        | Navbar / Cart                                                         |
| Found in      | Sprint 2                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 2                                                              |

**Resolution:** `EH.saveCart()` now calls `EH.updateNavBadges()` after every write. Badge sums `qty` across cart items and hides when zero.

---

## DEF-011 — Form Submit button enabled with empty required fields

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Major                                                                 |
| Module        | Forms / Validation                                                    |
| Found in      | Sprint 1                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 1                                                              |

**Steps**
1. Open registration form (all fields empty).
2. Observe the Submit button.

**Expected:** Disabled.
**Actual:** Enabled — clicking did nothing (validation blocked submit) but UI was misleading.

**Resolution:** `EHValidate.refreshSubmit(form)` toggles the submit button's `disabled` attribute based on (a) all required fields filled and (b) no visible `.field.error` siblings.

---

## DEF-012 — Wishlist heart fill not updating after toggle

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Minor                                                                 |
| Module        | Product card / Wishlist                                               |
| Found in      | Sprint 2                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 2                                                              |

**Resolution:** Click handler now mutates the SVG's `fill` attribute (`currentColor` vs `none`) alongside the `.active` class.

---

## DEF-013 — UPI ID like "name" accepted

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Major                                                                 |
| Module        | Checkout / Validation                                                 |
| Found in      | Sprint 2                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 2                                                              |

**Resolution:** `EHValidate.upi()` now requires `^[a-zA-Z0-9._-]{2,}@[a-zA-Z]{2,}$`.

---

## DEF-014 — Hardcoded pending seller approvals didn't reflect real state

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Major                                                                 |
| Module        | Admin dashboard                                                       |
| Found in      | Sprint 3                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 4                                                              |

**Steps**
1. Sign in as admin.
2. Approve "Aurora Tech".
3. Refresh the page.

**Expected:** Aurora Tech disappears from pending list.
**Actual:** Aurora Tech reappeared because the row was hardcoded HTML.

**Resolution:** Approvals table now reads from `eh_users` and filters `role==='seller' && status==='pending'`. Approve mutates `user.status='approved'`. Sample pending sellers seeded so the queue is populated for demo.

---

## DEF-015 — Reports table hardcoded with no actions

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Major                                                                 |
| Module        | Admin dashboard / Reports                                             |
| Found in      | Sprint 3                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 4                                                              |

**Resolution:** New `EH.getReports/saveReports` store with 4 seeded reports. Resolve / Dismiss / Reopen actions persist status changes. KPI cards (open / flagged / refunds / disputes) compute live counts.

---

## DEF-016 — Total revenue stat showed $0 even after orders placed

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Minor                                                                 |
| Module        | Dashboards / Stats                                                    |
| Found in      | Sprint 3                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 3                                                              |

**Resolution:** Stats now sum `orders[].totals.total`. Previous version summed `orders[].total` (wrong path).

---

## DEF-017 — Search input could break grid layout with special chars

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Minor                                                                 |
| Module        | Listing search                                                        |
| Found in      | Sprint 1                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 1                                                              |

**Resolution:** Search input validator rejects `<` and `>` characters and caps length at 100. Border turns red when invalid.

---

## DEF-018 — Customer could complete checkout without signing in

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Critical                                                              |
| Module        | Auth gating                                                           |
| Found in      | Sprint 4                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 4                                                              |

**Steps**
1. As guest, navigate directly to `pages/checkout.html`.
2. Form was rendered and submittable.

**Resolution:** Added `EH.requireAuth` gates to cart, checkout, wishlist, invoice, and dashboards. Page-level guard renders a friendly "Sign in required" panel instead of the gated content.

---

## DEF-019 — Compare list could grow beyond 4 products

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Minor                                                                 |
| Module        | Product compare                                                       |
| Found in      | Sprint 4                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 4                                                              |

**Resolution:** `EH.COMPARE_MAX = 4`. `EH.toggleCompare()` returns `null` if limit reached; UI toast informs the user.

---

## DEF-020 — Currency stuck in USD after Indian-market pivot

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Major                                                                 |
| Module        | Pricing / Localization                                                |
| Found in      | Sprint 4                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 4                                                              |

**Resolution:** `EH.formatPrice` uses `₹` and `en-IN` locale. All 17 seed products re-priced; oldPrice values updated; shipping threshold tuned to ₹49,999.

---

## DEF-021 — Promo code accepted case-sensitively

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Minor                                                                 |
| Module        | Cart / Promo                                                          |
| Found in      | Sprint 2                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 2                                                              |

**Resolution:** Input value is `.toUpperCase()` before comparison.

---

## DEF-022 — Card expiry input allowed letters and overflow

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Minor                                                                 |
| Module        | Checkout / Card form                                                  |
| Found in      | Sprint 2                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 2                                                              |

**Resolution:** `data-format="expiry"` strips non-digits, caps at 4 chars, inserts `/` after MM.

---

## DEF-023 — Hamburger menu not closing on mobile after link tap

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Minor                                                                 |
| Module        | Navbar / Mobile                                                       |
| Found in      | Sprint 1                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 1                                                              |

**Resolution:** Drawer toggles `.open` class; tapping a link inside the drawer navigates away (drawer destroyed on page change).

---

## DEF-024 — Invoice page reachable without an order

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Minor                                                                 |
| Module        | Invoice                                                               |
| Found in      | Sprint 2                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 2                                                              |

**Resolution:** Invoice page checks for `eh_lastOrder` (sessionStorage) or `?id=`. If neither, renders empty state with "Start shopping" CTA.

---

## DEF-025 — Confirm-password mismatch not caught until submit

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Minor                                                                 |
| Module        | Register / Validation                                                 |
| Found in      | Sprint 1                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 1                                                              |

**Resolution:** `data-validate="match" data-match="password"` checks live on every keystroke; field turns red as soon as values diverge.

---

## DEF-026 — Compare bar overlapped fixed footer content

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Cosmetic                                                              |
| Module        | Layout / Compare                                                      |
| Found in      | Sprint 4                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 4                                                              |

**Resolution:** Body gets `.has-compare-bar` class that adds 220 px bottom padding when bar is open.

---

## DEF-027 — Filter sidebar wasn't sticky on tall product lists

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Cosmetic                                                              |
| Module        | Listing                                                               |
| Found in      | Sprint 1                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 1                                                              |

**Resolution:** `.filters` sidebar has `position: sticky; top: calc(var(--nav-h) + 16px)`.

---

## DEF-028 — Brand wordmark used default sans-serif instead of cursive

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Cosmetic                                                              |
| Module        | Branding                                                              |
| Found in      | Sprint 4                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 4                                                              |

**Resolution:** Imported `Dancing Script` from Google Fonts; applied to `.brand` in navbar and footer.

---

## DEF-029 — Product card hover lift had jitter on Firefox

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Cosmetic                                                              |
| Module        | Product card                                                          |
| Found in      | Sprint 1                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 1                                                              |

**Resolution:** Used `transform: translateY(-3px)` instead of `margin-top` adjustment; added `will-change: transform`.

---

## DEF-030 — Toast stack grew tall without clearing old notifications

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Cosmetic                                                              |
| Module        | Toast / UX                                                            |
| Found in      | Sprint 1                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 1                                                              |

**Resolution:** Each toast auto-removes after 2.4 s with a fade-out animation.

---

## DEF-031 — Status pills used inconsistent colors across pages

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Cosmetic                                                              |
| Module        | Design system                                                         |
| Found in      | Sprint 3                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 4                                                              |

**Resolution:** Centralized `statusPillFor(status)` mapper in admin dashboard. All status strings map to consistent color tokens (ok / pending / fail / info / muted).

---

## DEF-032 — Long product names broke compare-page column width

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Cosmetic                                                              |
| Module        | Compare page                                                          |
| Found in      | Sprint 4                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 4                                                              |

**Resolution:** `.compare-table` uses `min-width: 720px` with horizontal scroll wrapper. Columns are min-width 200 px (160 px on mobile).

---

## DEF-033 — Demo accounts re-seeding overwrote real registrations

| Field         | Value                                                                 |
|---------------|----------------------------------------------------------------------|
| Severity      | Minor                                                                 |
| Module        | Auth seeding                                                          |
| Found in      | Sprint 4                                                              |
| Status        | Closed                                                                |
| Fixed in      | Sprint 4                                                              |

**Resolution:** `getUsers()` returns existing list if present; only falls back to `seedUsers()` when storage is empty. Newly registered accounts coexist with demo accounts until the session ends.
