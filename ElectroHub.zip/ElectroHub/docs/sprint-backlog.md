# ElectroHub — Sprint Backlog

**Product:** ElectroHub — Premium Electronics Storefront
**Methodology:** Scrum · 2-week sprints
**Team capacity:** 40 story points / sprint

Story point scale: 1 (trivial) · 2 (small) · 3 (medium) · 5 (large) · 8 (very large)

---

## Sprint 1 — Foundation & Catalog (Sprint Goal: customer can browse the storefront)

**Duration:** 2 weeks · **Committed:** 38 SP · **Delivered:** 38 SP

### US-001 — As a visitor, I want to see a polished homepage so I get a clear sense of what ElectroHub sells. *(5 SP)*

**Acceptance criteria**
- Hero section with headline, lead copy, two CTAs (Shop now / Explore laptops)
- Feature strip (free shipping, returns, warranty, support)
- Category grid (Laptops, Phones, Audio, Wearables, Tablets, TV)
- Featured products carousel of 8 items
- Footer with shop, help, account columns

**Tasks**
- T-001.1 Build hero markup & CSS (1 SP)
- T-001.2 Create SVG hero illustration (1 SP)
- T-001.3 Implement category tiles grid (1 SP)
- T-001.4 Wire featured products section to data source (1 SP)
- T-001.5 Build reusable footer component (1 SP)

---

### US-002 — As a customer, I want to register and sign in so I can have a personal account. *(5 SP)*

**Acceptance criteria**
- Registration form: full name, email, phone, DOB, password, confirm password
- Real-time validation on every field
- Password strength meter (4 levels)
- Role selector: Customer / Seller / Admin
- Sign-in form with email + password
- 3 seeded demo accounts auto-loaded

**Tasks**
- T-002.1 Build register.html markup (1 SP)
- T-002.2 Build login.html markup (1 SP)
- T-002.3 Implement validation.js with all 15+ rules (2 SP)
- T-002.4 Wire auth.js to register/login/logout (1 SP)

---

### US-003 — As a customer, I want to browse all products with filters and sorting so I can find what I need quickly. *(8 SP)*

**Acceptance criteria**
- Product listing page shows all products as cards
- Sidebar filters: category, brand, price range, rating
- Toolbar: search input, sort dropdown (5 sort orders)
- Live filtering — results update as I change filters
- Empty state when no results match
- URL params support (`?cat=Laptops`)

**Tasks**
- T-003.1 Build products.html layout (filters sidebar + grid) (2 SP)
- T-003.2 Implement live filter logic in products.js (3 SP)
- T-003.3 Implement sort dropdown handler (1 SP)
- T-003.4 Wire search input with validation (1 SP)
- T-003.5 Handle URL query params for pre-filter (1 SP)

---

### US-004 — As a customer, I want to view detailed product information so I can make an informed decision. *(8 SP)*

**Acceptance criteria**
- Product detail page with gallery (1 main image + 4 thumbs)
- Brand, name, rating, review count
- Price with original price strikethrough + savings
- Feature bullet list
- Color swatch selector
- Quantity stepper
- Tabs: Description, Specifications, Reviews, Installation
- Breadcrumb navigation

**Tasks**
- T-004.1 Build product-details.html template (1 SP)
- T-004.2 Implement gallery thumbnail switching (1 SP)
- T-004.3 Render specs table dynamically from product data (1 SP)
- T-004.4 Build tab-pane component (1 SP)
- T-004.5 Implement quantity stepper (1 SP)
- T-004.6 Wire color swatch picker (1 SP)
- T-004.7 Build breadcrumbs component (1 SP)
- T-004.8 Build meta-row (delivery, warranty, returns, install) (1 SP)

---

### US-005 — As a developer, I want a single design system so the UI is consistent across all pages. *(8 SP)*

**Acceptance criteria**
- Single style.css with CSS variables for color, type, spacing
- Reusable component classes: buttons, cards, forms, tables, modals
- Apple-inspired minimal aesthetic (matte black, soft gray, white)
- Responsive breakpoints: 1024 / 768 / 480 px
- Cursive brand font via Google Fonts

**Tasks**
- T-005.1 Define design tokens (colors, radii, shadows, transitions) (2 SP)
- T-005.2 Build typography scale (1 SP)
- T-005.3 Build button system (primary / secondary / ghost / outline / danger) (1 SP)
- T-005.4 Build form field components with state styles (2 SP)
- T-005.5 Build card variants (1 SP)
- T-005.6 Implement responsive media queries (1 SP)

---

### US-006 — As a developer, I want premium product imagery without external dependencies so the site loads fast and works offline. *(4 SP)*

**Acceptance criteria**
- 17+ unique product SVG illustrations stored locally
- 6 category tile SVGs
- 1 composite hero SVG
- 1 favicon SVG
- Apple-style minimal aesthetic

**Tasks**
- T-006.1 Design laptop, phone, watch SVGs (1 SP)
- T-006.2 Design audio SVGs (headphones, earbuds, speaker) (1 SP)
- T-006.3 Design accessory & gaming SVGs (1 SP)
- T-006.4 Design category tiles & hero composite (1 SP)

---

## Sprint 2 — Cart, Checkout & Order Flow (Sprint Goal: customer can place a full order end-to-end)

**Duration:** 2 weeks · **Committed:** 36 SP · **Delivered:** 36 SP

### US-007 — As a customer, I want to add items to my cart and manage quantities. *(5 SP)*

**Acceptance criteria**
- "Add to Cart" button on every product card and detail page
- Cart page lists all items with image, name, price, qty stepper
- Live order summary (subtotal, shipping, tax, total)
- Free shipping threshold visible
- Remove-item action with confirmation
- Empty-cart state
- Cart badge in navbar reflects live count

**Tasks**
- T-007.1 Build cart.html layout (1 SP)
- T-007.2 Implement cart state in cart.js (1 SP)
- T-007.3 Wire qty +/− buttons with bounds (1 SP)
- T-007.4 Compute totals with tax & shipping (1 SP)
- T-007.5 Implement navbar cart badge updates (1 SP)

---

### US-008 — As a customer, I want to save items to a wishlist so I can buy them later. *(3 SP)*

**Acceptance criteria**
- Heart icon on every product card toggles wishlist
- Wishlist page shows all saved items
- Wishlist badge in navbar
- Active state on heart (red fill) when item is saved
- Empty-wishlist state

**Tasks**
- T-008.1 Build wishlist.html (1 SP)
- T-008.2 Wire heart-toggle on cards and details page (1 SP)
- T-008.3 Persist wishlist state (1 SP)

---

### US-009 — As a customer, I want to apply promo codes to get a discount. *(2 SP)*

**Acceptance criteria**
- Promo input on cart page
- `WELCOME10` gives 10%, `NOVA20` gives 20%
- Discount line shows in green when applied
- Invalid codes show error toast

**Tasks**
- T-009.1 Implement promo logic & UI (2 SP)

---

### US-010 — As a customer, I want to complete checkout with three payment options. *(8 SP)*

**Acceptance criteria**
- Checkout page with contact, shipping, payment sections
- Three payment methods: Card, UPI, Cash on Delivery
- Card: number (Luhn validated), name, expiry MM/YY (future only), CVV
- UPI: ID validated (e.g. `name@bank`)
- COD: adds ₹15 fee to total
- Delivery date picker (no past dates)
- Submit blocked until all required fields valid
- Order created and saved on successful submit

**Tasks**
- T-010.1 Build checkout.html with payment selector (2 SP)
- T-010.2 Implement card validation (Luhn + expiry + CVV) (2 SP)
- T-010.3 Implement UPI ID validation (1 SP)
- T-010.4 COD fee logic (1 SP)
- T-010.5 Form-level submit validation gating (1 SP)
- T-010.6 Create order object & persist (1 SP)

---

### US-011 — As a customer, I want to view and print my invoice after ordering. *(5 SP)*

**Acceptance criteria**
- Invoice page renders order details, customer info, line items, totals
- Status pill shows "Confirmed"
- "Print invoice" button triggers browser print
- Print CSS hides nav/footer
- Order persists for later viewing via `?id=`

**Tasks**
- T-011.1 Build invoice.html template (2 SP)
- T-011.2 Render invoice from order object (1 SP)
- T-011.3 Implement print CSS (1 SP)
- T-011.4 Wire query-param lookup (1 SP)

---

### US-012 — As a customer, I want to leave ratings and reviews. *(3 SP)*

**Acceptance criteria**
- Review form on product detail page (Reviews tab)
- Click-to-select star rating (1–5)
- Validated review text
- Submitted review appears immediately at top of list
- Review summary panel shows avg score and star histogram
- Pre-seeded review for each product

**Tasks**
- T-012.1 Build review form UI (1 SP)
- T-012.2 Render review list and histogram (1 SP)
- T-012.3 Persist reviews per product (1 SP)

---

### US-013 — As a customer, I want to book installation/configuration for products that need setup. *(2 SP)*

**Acceptance criteria**
- "Installation" tab on product detail page
- Form: date (future only), address, PIN code, phone
- All fields validated
- Confirmation toast on submit

**Tasks**
- T-013.1 Build installation form & validation (2 SP)

---

### US-014 — As a customer, I want a support page with FAQs and a contact form. *(3 SP)*

**Acceptance criteria**
- FAQ accordion with 7 common questions
- Contact form: name, email, subject (dropdown), message
- FAQs visible to everyone
- Contact form requires sign-in
- Phone & email displayed

**Tasks**
- T-014.1 Build support.html layout (1 SP)
- T-014.2 Implement FAQ accordion (1 SP)
- T-014.3 Wire contact form validation & gate (1 SP)

---

## Sprint 3 — Seller & Admin Operations (Sprint Goal: sellers can list products; admins can moderate the platform)

**Duration:** 2 weeks · **Committed:** 39 SP · **Delivered:** 39 SP

### US-015 — As a seller, I want a dashboard with my KPIs so I understand business health. *(5 SP)*

**Acceptance criteria**
- KPI cards: revenue, orders, products listed, avg order value
- Recent orders panel
- Top products panel
- Sidebar navigation: Overview, Products, Orders, Analytics

**Tasks**
- T-015.1 Build seller dashboard layout (2 SP)
- T-015.2 Compute KPIs from orders & products (2 SP)
- T-015.3 Filter data to current seller's catalog only (1 SP)

---

### US-016 — As a seller, I want to add, edit, and delete my products. *(8 SP)*

**Acceptance criteria**
- "+ Add Product" opens an inline form
- Form fields: name, brand, category, price, stock, image path, tagline
- Real-time validation on every field
- Edit reuses the form pre-populated
- Delete asks for confirmation
- Changes reflect immediately in the seller catalog table
- New products stamped with seller's name

**Tasks**
- T-016.1 Build product form UI (2 SP)
- T-016.2 Wire CRUD actions to products store (3 SP)
- T-016.3 Stamp seller field on creation (1 SP)
- T-016.4 Validation: price > 0, stock ≥ 0 (1 SP)
- T-016.5 Delete confirmation modal (1 SP)

---

### US-017 — As a seller, I want to see sales analytics. *(3 SP)*

**Acceptance criteria**
- Analytics tab with 4 metric cards
- CSS bar chart: sales by month (12 bars)
- Category mix breakdown with progress bars

**Tasks**
- T-017.1 Build analytics tab (2 SP)
- T-017.2 Implement CSS bar chart (1 SP)

---

### US-018 — As an admin, I want a platform-wide dashboard. *(5 SP)*

**Acceptance criteria**
- KPI cards: total revenue, users, sellers, products
- Sidebar: Overview, Users, Sellers, Products, Orders, Reports
- Badge counters on Sellers (pending) and Reports (open)
- Recent activity panel pulling from orders, reports, applications

**Tasks**
- T-018.1 Build admin dashboard layout (2 SP)
- T-018.2 Wire dynamic stat computation (2 SP)
- T-018.3 Build recent activity feed (1 SP)

---

### US-019 — As an admin, I want to approve or reject seller applications. *(8 SP)*

**Acceptance criteria**
- New seller registrations default to `pending` status
- Pending applications appear in admin's approval queue with applicant name, email, phone, time
- Approve / Reject buttons mutate user status persistently
- Approved sellers gain full dashboard access on next sign-in
- Pending sellers see a "Awaiting approval" gate when accessing seller dashboard
- Rejected sellers see a rejection message

**Tasks**
- T-019.1 Add `status` field to user schema (1 SP)
- T-019.2 Update register flow to set pending for sellers (1 SP)
- T-019.3 Build pending-approvals table (2 SP)
- T-019.4 Wire approve/reject actions with persistence (2 SP)
- T-019.5 Build seller-dashboard approval gate (1 SP)
- T-019.6 Refresh stored user.status on login (1 SP)

---

### US-020 — As an admin, I want to manage users (suspend, reactivate). *(3 SP)*

**Acceptance criteria**
- Users tab lists all accounts with name, email, phone, role, status, joined date
- Search by name or email (live filter)
- Suspend / Reactivate buttons
- Admin accounts cannot be suspended
- Status pill reflects current state

**Tasks**
- T-020.1 Build users table with search (2 SP)
- T-020.2 Wire suspend/reactivate actions (1 SP)

---

### US-021 — As an admin, I want to moderate the product catalog. *(2 SP)*

**Acceptance criteria**
- All products visible with image, name, seller, price, stock, status
- Status pill shows Approved or Flagged (linked to listing reports)
- Low-stock indicator
- Take-down button removes the product

**Tasks**
- T-021.1 Build moderation table (1 SP)
- T-021.2 Wire takedown action (1 SP)

---

### US-022 — As an admin, I want a reports inbox so I can act on flagged content and disputes. *(5 SP)*

**Acceptance criteria**
- Reports tab lists all reports with type, subject, reporter, priority, status, date
- KPI cards: open tickets, flagged listings, refund requests, disputes
- Resolve / Dismiss / Reopen actions
- 4 seeded reports for demo
- Priority pill (high / medium / low)

**Tasks**
- T-022.1 Build reports data store with seed (1 SP)
- T-022.2 Build reports table & KPI cards (2 SP)
- T-022.3 Wire status transitions (resolve/dismiss/reopen) (2 SP)

---

## Sprint 4 — Polish, Compare, Localization (Sprint Goal: portfolio-ready polish)

**Duration:** 2 weeks · **Committed:** 32 SP · **Delivered:** 32 SP

### US-023 — As a customer, I want to compare up to 4 products side by side. *(8 SP)*

**Acceptance criteria**
- Compare icon on every product card (top-right) and as a text button below "Add to Cart"
- Floating compare bar appears when 1+ products added — pinned to bottom on every page
- Bar shows 4 slots (filled or empty)
- "Compare now →" button enabled when 2+ products selected
- Compare page renders side-by-side spec table
- Differences highlighted with soft amber background
- Remove per-product from bar or compare page
- "Clear all" action
- Public — no login required for compare itself

**Tasks**
- T-023.1 Add compare state store (sessionStorage) (1 SP)
- T-023.2 Build floating compare bar component (2 SP)
- T-023.3 Wire compare toggles on cards and details (2 SP)
- T-023.4 Build compare.html spec-diff table (2 SP)
- T-023.5 Inline-onclick fallback for reliable click handling (1 SP)

---

### US-024 — As a developer, I want INR pricing and Indian locations so the site fits the target market. *(3 SP)*

**Acceptance criteria**
- All prices formatted in ₹ using `en-IN` locale (lakhs notation)
- Phone numbers and addresses are Indian
- Invoice "from" address is Bengaluru-based
- Free shipping threshold updated to ₹49,999

**Tasks**
- T-024.1 Update formatPrice to ₹ + en-IN (1 SP)
- T-024.2 Convert all 17 seed products to INR prices (1 SP)
- T-024.3 Update locations & contact info (1 SP)

---

### US-025 — As a developer, I want sessionStorage so demo state resets cleanly. *(2 SP)*

**Acceptance criteria**
- All `eh_*` keys in sessionStorage
- Demo accounts re-seed on each new browser session
- Product catalog re-seeds with current price version

**Tasks**
- T-025.1 Refactor Store to use sessionStorage (1 SP)
- T-025.2 Document storage policy in README (1 SP)

---

### US-026 — As a visitor, I want authentication gates on the right pages so I get a clear sign-in prompt. *(5 SP)*

**Acceptance criteria**
- Browse/view product details: public
- FAQs: public
- Add to cart, wishlist, checkout, invoice, reviews, install booking, contact form: require sign-in
- Seller dashboard: requires seller or admin role
- Admin dashboard: requires admin role
- Friendly "Sign-in required" panel instead of broken layouts
- After login, return to original URL

**Tasks**
- T-026.1 Build `EH.requireAuth` and `EH.requireRole` helpers (1 SP)
- T-026.2 Add page-level gates to cart/checkout/wishlist/invoice (1 SP)
- T-026.3 Add action-level gates (add to cart, wishlist, review) (1 SP)
- T-026.4 Role-gate seller & admin dashboards (1 SP)
- T-026.5 Implement post-login redirect to original page (1 SP)

---

### US-027 — As a customer, I want the site to feel premium with cursive branding. *(2 SP)*

**Acceptance criteria**
- Brand wordmark "ElectroHub" in cursive font (Dancing Script)
- Brand mark "E" remains as a black tile
- Used in navbar and footer

**Tasks**
- T-027.1 Add Google Font import & update brand CSS (2 SP)

---

### US-028 — As a developer, I want subtle UX touches that make the site feel polished. *(7 SP)*

**Acceptance criteria**
- Toast notifications for actions (cart add, wishlist save, etc.)
- Smooth slide-in for compare bar with subtle pulse animation
- Hover lift on product cards
- Sticky filter sidebar on listing page
- Sticky order summary on cart and checkout
- Hamburger drawer on mobile
- Backdrop-blur on navbar
- Loading & empty states everywhere

**Tasks**
- T-028.1 Build toast system (1 SP)
- T-028.2 Add hover/press transitions to buttons & cards (1 SP)
- T-028.3 Sticky sidebar + summary CSS (1 SP)
- T-028.4 Build mobile hamburger drawer (1 SP)
- T-028.5 Implement navbar backdrop-blur (1 SP)
- T-028.6 Add empty states across all pages (2 SP)

---

### US-029 — As a developer, I want test coverage and bug-fix documentation. *(5 SP)*

**Acceptance criteria**
- Manual test cases documented for every major flow
- Defect log captures bugs found and resolved
- Quality log tracks QA activities, browser testing, accessibility checks

**Tasks**
- T-029.1 Write quality log (2 SP)
- T-029.2 Write defect log (2 SP)
- T-029.3 Cross-browser smoke test (1 SP)

---

## Summary

| Sprint | Goal | Committed | Delivered | Velocity |
|---|---|---:|---:|---:|
| 1 | Foundation & Catalog | 38 | 38 | 38 |
| 2 | Cart, Checkout & Order Flow | 36 | 36 | 36 |
| 3 | Seller & Admin Operations | 39 | 39 | 39 |
| 4 | Polish, Compare, Localization | 32 | 32 | 32 |
| **Total** | | **145** | **145** | — |

**Average velocity:** 36.25 SP / sprint
**Stories completed:** 29
**Tasks completed:** 99
