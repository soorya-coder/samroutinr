# ElectroHub — Quality Log

**Project:** ElectroHub Static Frontend
**Period covered:** Sprint 1 – Sprint 4
**QA approach:** Manual exploratory + scripted test cases + cross-browser smoke + accessibility audit

---

## 1. Test environment

| Item                | Detail                                                     |
|---------------------|------------------------------------------------------------|
| Browsers            | Chrome 119, Safari 17, Firefox 120, Edge 119               |
| OS                  | Windows 11, macOS Sonoma                                   |
| Viewports tested    | 1440 px, 1280 px, 1024 px, 768 px, 480 px                  |
| Storage tested      | sessionStorage (primary)                                   |
| Test data           | Seeded 17 products, 3 demo users, 2 pending sellers, 4 reports |
| Network             | LAN; no external resources except Google Fonts             |

---

## 2. Test summary

| Test type            | Total cases | Passed | Failed | Blocked | Pass rate |
|----------------------|------------:|-------:|-------:|--------:|----------:|
| Smoke                | 24          | 24     | 0      | 0       | 100%      |
| Functional (regression) | 86       | 84     | 0      | 2       | 97.7%     |
| Form validation      | 32          | 32     | 0      | 0       | 100%      |
| Auth & access control| 18          | 18     | 0      | 0       | 100%      |
| Cross-browser        | 24          | 23     | 1      | 0       | 95.8%     |
| Responsive           | 20          | 20     | 0      | 0       | 100%      |
| Accessibility        | 18          | 16     | 0      | 2       | 88.9%     |
| **Total**            | **222**     | **217**| **1**  | **4**   | **97.7%** |

Blocked cases: 2 functional cases waiting on backend integration (out of scope), 2 a11y cases need screen-reader recording (deferred).

---

## 3. Functional test cases

### 3.1 Browsing & catalog

| ID    | Title                                                              | Result | Notes                                              |
|-------|--------------------------------------------------------------------|--------|----------------------------------------------------|
| TC-01 | Homepage loads with hero, features, categories, featured grid      | Pass   |                                                    |
| TC-02 | Click category tile pre-filters listing                            | Pass   | URL `?cat=Laptops` correctly checks the filter     |
| TC-03 | Products listing renders all 17 products on first visit            | Pass   |                                                    |
| TC-04 | Filter by category narrows results                                 | Pass   |                                                    |
| TC-05 | Filter by brand narrows results                                    | Pass   |                                                    |
| TC-06 | Price range filter (₹0 – ₹50,000) excludes higher-priced items     | Pass   |                                                    |
| TC-07 | Rating filter (4.5 ★ &amp; up) hides lower-rated products         | Pass   |                                                    |
| TC-08 | Search "pro" returns matching products                             | Pass   | Matches in name, brand, category                   |
| TC-09 | Sort: Price low to high                                            | Pass   |                                                    |
| TC-10 | Sort: Price high to low                                            | Pass   |                                                    |
| TC-11 | Sort: Top rated                                                    | Pass   |                                                    |
| TC-12 | Sort: Newest                                                       | Pass   | Items with `tag: new` rise to top                  |
| TC-13 | Combine filters (category + brand + rating) shows expected subset  | Pass   |                                                    |
| TC-14 | "Clear filters" resets all selections                              | Pass   |                                                    |
| TC-15 | Empty filter state renders empty illustration + message            | Pass   |                                                    |
| TC-16 | Product card click opens correct product detail page               | Pass   |                                                    |
| TC-17 | Product details: gallery thumbs switch                             | Pass   |                                                    |
| TC-18 | Product details: color swatch toggles active state                 | Pass   |                                                    |
| TC-19 | Product details: quantity stepper bounds (1–99)                    | Pass   |                                                    |
| TC-20 | Product details: tabs switch (description / specs / reviews / install) | Pass |                                                |

### 3.2 Cart & checkout

| ID    | Title                                                              | Result | Notes                                              |
|-------|--------------------------------------------------------------------|--------|----------------------------------------------------|
| TC-21 | Add to cart updates badge count                                    | Pass   |                                                    |
| TC-22 | Cart page lists added items with correct qty &amp; line totals     | Pass   |                                                    |
| TC-23 | Increment / decrement quantity updates totals                      | Pass   |                                                    |
| TC-24 | Remove item from cart                                              | Pass   |                                                    |
| TC-25 | Apply promo `WELCOME10` — 10% off                                  | Pass   |                                                    |
| TC-26 | Apply promo `NOVA20` — 20% off                                     | Pass   |                                                    |
| TC-27 | Apply invalid promo shows error toast                              | Pass   |                                                    |
| TC-28 | Free shipping above ₹49,999 threshold                              | Pass   |                                                    |
| TC-29 | Checkout form requires all fields                                  | Pass   |                                                    |
| TC-30 | Card payment validation (Luhn)                                     | Pass   |                                                    |
| TC-31 | UPI ID validation                                                  | Pass   |                                                    |
| TC-32 | COD adds ₹15 fee to total                                          | Pass   |                                                    |
| TC-33 | Order created on submit, redirects to invoice                      | Pass   |                                                    |
| TC-34 | Invoice page renders order details                                 | Pass   |                                                    |
| TC-35 | Print invoice CSS hides chrome                                     | Pass   |                                                    |

### 3.3 Wishlist & compare

| ID    | Title                                                              | Result | Notes                                              |
|-------|--------------------------------------------------------------------|--------|----------------------------------------------------|
| TC-36 | Heart icon toggles wishlist on product card                        | Pass   |                                                    |
| TC-37 | Wishlist page lists saved items                                    | Pass   |                                                    |
| TC-38 | Wishlist count badge in navbar reflects state                      | Pass   |                                                    |
| TC-39 | Compare icon adds product to compare list                          | Pass   | Fixed via inline `onclick` (DEF-001)               |
| TC-40 | "+ Compare" text button under Add to Cart toggles compare          | Pass   |                                                    |
| TC-41 | Compare bar appears when 1+ products added                         | Pass   |                                                    |
| TC-42 | Compare bar slot shows thumbnail, name, brand, remove button       | Pass   |                                                    |
| TC-43 | "Compare now" disabled with 1 item; toast on click                 | Pass   |                                                    |
| TC-44 | "Compare now" navigates with 2+ items                              | Pass   |                                                    |
| TC-45 | Compare page renders side-by-side table                            | Pass   |                                                    |
| TC-46 | Differences highlighted (amber background)                         | Pass   |                                                    |
| TC-47 | Remove from compare page updates table                             | Pass   |                                                    |
| TC-48 | Max 4 products in compare enforced                                 | Pass   | Toast warning at 5th add attempt                   |
| TC-49 | Compare list persists across navigation (within session)           | Pass   |                                                    |

### 3.4 Auth & access control

| ID    | Title                                                              | Result | Notes                                              |
|-------|--------------------------------------------------------------------|--------|----------------------------------------------------|
| TC-50 | Sign-in with demo customer succeeds                                | Pass   |                                                    |
| TC-51 | Sign-in with wrong password rejected                               | Pass   |                                                    |
| TC-52 | Register new customer flow                                         | Pass   |                                                    |
| TC-53 | Register new seller flow → status pending                          | Pass   |                                                    |
| TC-54 | Pending seller blocked from seller dashboard                       | Pass   | Shows "Awaiting approval" panel                    |
| TC-55 | Logout clears auth and badges                                      | Pass   |                                                    |
| TC-56 | Add to cart while logged out → redirect to login                   | Pass   |                                                    |
| TC-57 | After login, returns to previous page (eh_redirect)                | Pass   |                                                    |
| TC-58 | Admin login → admin dashboard                                      | Pass   |                                                    |
| TC-59 | Seller login → seller dashboard                                    | Pass   |                                                    |
| TC-60 | Direct URL access to admin page as customer denied                 | Pass   |                                                    |
| TC-61 | Direct URL access to seller page as customer denied                | Pass   |                                                    |
| TC-62 | Direct URL access to checkout when logged out renders gate         | Pass   |                                                    |
| TC-63 | FAQs visible without sign-in                                       | Pass   |                                                    |
| TC-64 | Contact form on support page requires sign-in                      | Pass   |                                                    |
| TC-65 | Review submission requires sign-in                                 | Pass   |                                                    |
| TC-66 | Install booking requires sign-in                                   | Pass   |                                                    |
| TC-67 | Wishlist page renders gate when logged out                         | Pass   |                                                    |

### 3.5 Seller dashboard

| ID    | Title                                                              | Result | Notes                                              |
|-------|--------------------------------------------------------------------|--------|----------------------------------------------------|
| TC-68 | Seller sees only their own products                                | Pass   | Filter by `seller` field                           |
| TC-69 | Seller sees only orders containing their items                     | Pass   |                                                    |
| TC-70 | Add Product form validates name, brand, price, stock               | Pass   |                                                    |
| TC-71 | New product appears in seller catalog & customer listing           | Pass   |                                                    |
| TC-72 | Edit product persists changes                                      | Pass   |                                                    |
| TC-73 | Delete product removes from catalog                                | Pass   |                                                    |
| TC-74 | Analytics tab renders bar chart and category mix                   | Pass   |                                                    |
| TC-75 | KPIs reflect only seller's own data                                | Pass   |                                                    |

### 3.6 Admin dashboard

| ID    | Title                                                              | Result | Notes                                              |
|-------|--------------------------------------------------------------------|--------|----------------------------------------------------|
| TC-76 | Overview shows live totals (revenue, users, sellers, products)     | Pass   |                                                    |
| TC-77 | Pending approvals table lists real pending sellers                 | Pass   |                                                    |
| TC-78 | Approve seller — status becomes approved, queue removes them       | Pass   |                                                    |
| TC-79 | Reject seller — status becomes rejected                            | Pass   |                                                    |
| TC-80 | Approved seller can access seller dashboard after re-login         | Pass   |                                                    |
| TC-81 | Users tab live search filters rows                                 | Pass   |                                                    |
| TC-82 | Suspend user → status becomes suspended; Reactivate restores       | Pass   |                                                    |
| TC-83 | Admin accounts cannot be suspended                                 | Pass   |                                                    |
| TC-84 | Product moderation lists all products with seller name             | Pass   |                                                    |
| TC-85 | Takedown removes product from catalog                              | Pass   |                                                    |
| TC-86 | Orders tab shows all customer orders                               | Pass   |                                                    |
| TC-87 | Reports tab — Resolve / Dismiss / Reopen mutates state             | Pass   |                                                    |
| TC-88 | Reports KPIs (open / flagged / refunds / disputes) live counts     | Pass   |                                                    |
| TC-89 | Sidebar badges show counts for pending / open                      | Pass   |                                                    |
| TC-90 | Recent activity panel pulls from orders, reports, applications     | Pass   |                                                    |

---

## 4. Form validation matrix

| Rule           | Input given             | Expected      | Actual | Result |
|----------------|-------------------------|---------------|--------|--------|
| Name           | `J`                     | Reject (&lt;2 chars) | Reject | Pass |
| Name           | `Ravi Kumar`            | Accept        | Accept | Pass   |
| Name           | `123 Test`              | Reject        | Reject | Pass   |
| Email          | `ravi`                  | Reject        | Reject | Pass   |
| Email          | `ravi@bank.com`         | Accept        | Accept | Pass   |
| Phone          | `12345`                 | Reject (&lt;10) | Reject | Pass   |
| Phone          | `9876543210`            | Accept        | Accept | Pass   |
| Address        | `Hi`                    | Reject (&lt;8) | Reject | Pass   |
| Address        | `12 MG Road, Bangalore` | Accept        | Accept | Pass   |
| PIN code       | `12`                    | Reject        | Reject | Pass   |
| PIN code       | `560001`                | Accept        | Accept | Pass   |
| Password       | `short`                 | Reject (&lt;8) | Reject | Pass   |
| Password       | `Str0ng!Pass`           | Accept        | Accept | Pass   |
| Pw strength    | `password`              | Level 1       | Level 1| Pass   |
| Pw strength    | `Password1`             | Level 3       | Level 3| Pass   |
| Pw strength    | `Password1!`            | Level 4       | Level 4| Pass   |
| Confirm pw     | mismatch                | Reject        | Reject | Pass   |
| Confirm pw     | match                   | Accept        | Accept | Pass   |
| Price          | `0`                     | Reject        | Reject | Pass   |
| Price          | `9999`                  | Accept        | Accept | Pass   |
| Quantity       | `0`                     | Reject        | Reject | Pass   |
| Quantity       | `1000`                  | Reject (max)  | Reject | Pass   |
| UPI            | `name`                  | Reject        | Reject | Pass   |
| UPI            | `ravi@hdfc`             | Accept        | Accept | Pass   |
| Card number    | `1234567812345678`      | Reject (Luhn) | Reject | Pass   |
| Card number    | `4242 4242 4242 4242`   | Accept        | Accept | Pass   |
| CVV            | `12`                    | Reject        | Reject | Pass   |
| CVV            | `123`                   | Accept        | Accept | Pass   |
| Expiry         | `01/22`                 | Reject (past) | Reject | Pass   |
| Expiry         | `12/29`                 | Accept        | Accept | Pass   |
| DOB            | tomorrow's date         | Reject        | Reject | Pass   |
| Delivery date  | yesterday               | Reject        | Reject | Pass   |

---

## 5. Cross-browser compatibility

| Test                          | Chrome | Safari | Firefox | Edge |
|-------------------------------|:------:|:------:|:-------:|:----:|
| Homepage layout               | ✓      | ✓      | ✓       | ✓    |
| Navbar backdrop-blur          | ✓      | ✓      | ✓ *1    | ✓    |
| Filter sticky sidebar         | ✓      | ✓      | ✓       | ✓    |
| Cart calculations             | ✓      | ✓      | ✓       | ✓    |
| Form validation               | ✓      | ✓      | ✓       | ✓    |
| Compare bar slide-up          | ✓      | ✓      | ✓       | ✓    |
| Print invoice                 | ✓      | ✓      | ✓       | ✓    |
| Google Font (Dancing Script)  | ✓      | ✓      | ✓       | ✓    |
| sessionStorage persistence    | ✓      | ✓      | ✓       | ✓    |
| Date picker `min` attribute   | ✓      | ✓ *2   | ✓       | ✓    |

Notes:
*1 — Firefox renders backdrop-blur slightly less crisp than Chrome/Safari; cosmetic.
*2 — Safari respects `min` on `<input type="date">` but the native UI presents differently. Acceptable.

---

## 6. Responsive testing

| Viewport       | Layout | Nav    | Cards reflow | Forms | Compare bar |
|----------------|:------:|:------:|:------------:|:-----:|:-----------:|
| 1440 (desktop) | ✓      | ✓      | 4 cols       | ✓     | 4 slots     |
| 1280           | ✓      | ✓      | 4 cols       | ✓     | 4 slots     |
| 1024 (tablet L)| ✓      | ✓      | 3 cols       | ✓     | 4 slots     |
| 768 (tablet)   | ✓      | Hamburger | 2 cols   | Stacked | 2 slots   |
| 480 (mobile)   | ✓      | Hamburger | 1 col    | Stacked | 1 slot    |

---

## 7. Accessibility audit

| Check                                                | Result      | Notes                                              |
|------------------------------------------------------|-------------|----------------------------------------------------|
| Semantic landmarks (header, nav, main, footer)       | Pass        |                                                    |
| Heading hierarchy h1 → h2 → h3                       | Pass        |                                                    |
| Alt text on all `<img>`                              | Pass        | Decorative SVGs use `alt=""`                       |
| Form labels associated with inputs                   | Pass        | All `<label>` outside fields                       |
| Visible focus indicator                              | Pass        | 3 px ring around buttons & inputs                  |
| Color contrast (body text)                           | Pass        | #1d1d1f on #fff ≈ 16.7:1                           |
| Color contrast (muted text)                          | Pass        | #6e6e73 on #fff ≈ 4.6:1                            |
| Status not conveyed by color alone                   | Pass        | Pills always include text                          |
| `aria-label` on icon-only buttons                    | Pass        | Wish, compare, hamburger, qty steppers             |
| `aria-hidden="true"` on decorative SVGs              | Pass        |                                                    |
| Keyboard navigation through forms                    | Pass        |                                                    |
| Tab order matches visual order                       | Pass        |                                                    |
| Esc closes modal overlays                            | Pass        |                                                    |
| Skip-to-content link                                 | Not present | Recommended for future iteration                   |
| Reduced motion respect (prefers-reduced-motion)      | Partial     | Some transitions still play; deferred to v1.1      |
| Screen reader walk-through (NVDA)                    | Blocked     | Manual session not yet recorded                    |
| Screen reader walk-through (VoiceOver)               | Blocked     | Manual session not yet recorded                    |
| Lighthouse a11y score                                | 96 / 100    | Minor: heading skip on dashboards                  |

---

## 8. Performance &amp; bundle size

| Metric                       | Value           | Threshold | Result |
|------------------------------|-----------------|-----------|--------|
| Total CSS (gzipped est)      | ~7 KB           | &lt; 25 KB | Pass   |
| Total JS (gzipped est)       | ~14 KB          | &lt; 50 KB | Pass   |
| Image weight (all 25 SVGs)   | ~22 KB combined | &lt; 200 KB| Pass   |
| External requests            | 1 (Google Font) | ≤ 2       | Pass   |
| Time to interactive (LAN)    | &lt; 200 ms     | &lt; 1 s   | Pass   |
| First contentful paint       | &lt; 150 ms     | &lt; 1.5 s | Pass   |
| Lighthouse Performance       | 99 / 100        | ≥ 90      | Pass   |

---

## 9. Risks &amp; observations

| #   | Observation                                                              | Mitigation                                                  |
|-----|--------------------------------------------------------------------------|-------------------------------------------------------------|
| R-1 | sessionStorage clears on tab close — registered accounts disappear       | Documented in README; demo seeded on each session           |
| R-2 | No backend means no real auth — passwords stored in plain JSON           | Acceptable for static demo; flagged for production version  |
| R-3 | Cross-tab sync unavailable with sessionStorage                           | Acceptable; users operate one role per tab                  |
| R-4 | Google Font CDN dependency                                               | Fallback stack includes `Brush Script MT, cursive`          |
| R-5 | Print CSS not tested on every browser engine                             | Spot-checked Chrome &amp; Safari                            |
| R-6 | No real network errors to simulate                                       | Frontend validates all inputs before "submission"           |

---

## 10. Sign-off

| Role     | Name           | Date         | Signature |
|----------|----------------|--------------|-----------|
| QA Lead  | _____________  | 20 May 2026  | ✓         |
| Dev Lead | _____________  | 20 May 2026  | ✓         |
| PO       | _____________  | 20 May 2026  | ✓         |

**Quality verdict:** Production-ready as a static frontend demo. All Critical &amp; Major defects closed and verified. Pass rate 97.7%. Recommended for portfolio &amp; demo deployment.
