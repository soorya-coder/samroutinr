# ElectroHub

A complete static frontend ecommerce website for premium electronics. Built with **HTML5, CSS3, and vanilla JavaScript** — no frameworks, no backend, no external image APIs.

## Design

Apple-inspired minimal aesthetic.

- Matte black `#1d1d1f`
- White `#ffffff`
- Soft gray `#f5f5f7`
- Dark gray `#424245`
- Subtle blue accent `#2563a8` (used sparingly)

Typography uses the system font stack (SF Pro / Helvetica Neue / Segoe UI). Premium look-and-feel with proper spacing, soft shadows, rounded corners, and gentle hover transitions.

## Project structure

```
ElectroHub/
├── index.html                 Home
├── pages/
│   ├── login.html
│   ├── register.html
│   ├── products.html          Listing with filters, search, sort
│   ├── product-details.html   Details, reviews, install booking
│   ├── cart.html
│   ├── checkout.html          Card / UPI / COD payment UI
│   ├── wishlist.html
│   ├── invoice.html           Printable invoice
│   ├── support.html           FAQs + contact form
│   ├── seller-dashboard.html  Catalog CRUD, orders, analytics
│   └── admin-dashboard.html   Users, sellers, moderation, reports
├── css/
│   └── style.css              Single design system
├── js/
│   ├── app.js                 Shared state, navbar/footer, data
│   ├── auth.js                Login + Register
│   ├── products.js            Listing, details, reviews
│   ├── cart.js                Cart, checkout, invoice, wishlist
│   ├── dashboard.js           Seller + Admin dashboards
│   └── validation.js          Reusable form validators
├── assets/
│   └── images/                25 local SVG product illustrations
└── README.md
```

## Running locally

Just open `index.html` in a browser. No build step, no server required.

For best results (since some browsers restrict `file://` localStorage), serve via a local static server:

```bash
# Python
python -m http.server 8000

# Node
npx serve .
```

Then visit http://localhost:8000.

## Access policy

Without signing in you can:

- Browse the home page, all categories, and the product listing
- View product details (gallery, specs, existing reviews)
- Read the FAQs on the support page

Everything else requires sign-in:

- Add to cart, wishlist, buy now
- Cart, checkout, invoice pages
- Writing reviews
- Booking installation
- Contact support form
- Seller dashboard (requires seller or admin role)
- Admin dashboard (requires admin role)

When an action requires sign-in, you're sent to the login page; after signing in, you're returned to where you started.

## Demo accounts

Seeded automatically on first load:

| Role     | Email                    | Password    |
|----------|--------------------------|-------------|
| Customer | demo@electrohub.com      | Demo@1234   |
| Seller   | seller@electrohub.com    | Seller@123  |
| Admin    | admin@electrohub.com     | Admin@123   |

## Features

### Customer
- Browse 17+ products across Laptops, Phones, Audio, Wearables, Tablets, TV, Cameras, Gaming, Accessories
- Search, filter by category/brand/price/rating, sort by price/rating/newest
- Product details with gallery, color swatches, qty stepper, specs, reviews
- Wishlist (heart icon on every product card)
- Cart with line totals, promo codes (`WELCOME10`, `NOVA20`), tax & shipping
- Checkout with Card / UPI / Cash-on-Delivery
- Printable invoice page after order confirmation
- Rating & reviews with star-bar histogram
- Installation booking from product detail tab
- Support page with FAQ accordions and contact form

### Seller
- Overview with revenue, orders, products, avg-order KPIs
- Product CRUD (add / edit / delete) with full validation
- Orders table with status pills
- Sales analytics with bar chart and category mix

### Admin
- Platform-wide KPIs
- User management with search and suspend
- Seller approval workflow (approve / reject)
- Product moderation (take down)
- Reports (tickets, refunds, disputes)

## Validation

Every form input is validated in real-time:

- Required fields, names, emails, phone (10–15 digits), addresses, PIN codes
- Password strength meter (4 levels), confirm-password matching
- Product price (>0), quantity (1–999)
- UPI ID format
- Credit card number (Luhn check), CVV (3–4 digits)
- Card expiry MM/YY — rejects past months
- Booking & delivery dates — must be today or future
- Birth date — cannot be in the future
- Search input — sanitized

Error styling: red borders for invalid, green for valid, inline error messages. Submit buttons are disabled until the form is valid. Invalid submissions are blocked.

## Storage

All app state is stored in **`sessionStorage`** under the `eh_` prefix. Data is cleared when the browser tab/window closes — including registered accounts. Demo accounts and the seed product catalog re-seed automatically on the first page load of every new session.

Keys used:

- `eh_products` + `eh_seed_version` — product catalog (re-seeded each session)
- `eh_users` — registered accounts (re-seeded with demo accounts each session)
- `eh_user` — currently signed-in user
- `eh_cart` — shopping cart
- `eh_wishlist` — saved items
- `eh_compare` — products queued for comparison
- `eh_orders` — order history
- `eh_lastOrder` — most recent order, used for invoice redirect
- `eh_reviews` — product reviews
- `eh_redirect` — return-to URL after sign-in

Closing the browser resets the app to seeded defaults.

## Images

All product visuals are **locally stored SVG illustrations** (`assets/images/*.svg`). Crisp at any resolution, no external requests.

## Responsiveness

Optimized for desktop. Includes responsive breakpoints at 1024, 768, and 480 px — navbar collapses to a hamburger drawer, grids reflow, and layout columns stack.

## Browser support

Modern evergreen browsers (Chrome, Safari, Firefox, Edge). Uses standard DOM APIs and CSS features.
