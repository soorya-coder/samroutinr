class Config:
    SCHOOL_NAME = "Mount Zion Schools"
    SECRET_KEY = "dev-only-not-secret"
    DEBUG = True
    # Hard-coded "logged-in" student until auth is added
    DEFAULT_STUDENT_ID = 1
