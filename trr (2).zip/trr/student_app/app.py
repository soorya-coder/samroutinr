import os
import sys
from datetime import date

# Make `shared/` importable
_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from flask import Flask

from config import Config
from shared.db.database import ensure_db_ready
from modules.dashboard.routes import dashboard_bp


def create_app():
    ensure_db_ready()  # create + seed DB on first run

    app = Flask(__name__)
    app.config.from_object(Config)

    app.register_blueprint(dashboard_bp, url_prefix="/")

    @app.context_processor
    def inject_globals():
        return {
            "school_name": app.config["SCHOOL_NAME"],
            "today": date.today().strftime("%A, %d %B %Y"),
        }

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(host="127.0.0.1", port=5001, debug=True)
