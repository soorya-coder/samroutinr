from flask import Blueprint, render_template, request, current_app, abort

from shared.db.database import get_db
from shared.db import queries as q
from shared.geo import haversine_km, eta_minutes

dashboard_bp = Blueprint("dashboard", __name__, template_folder="../../templates")


@dashboard_bp.route("/")
def index():
    requested = request.args.get("sid", type=int)
    sid = requested or current_app.config["DEFAULT_STUDENT_ID"]

    with get_db() as conn:
        student = q.get_student(conn, sid)
        if not student or not student.get("bus_id"):
            student = q.get_student(conn, current_app.config["DEFAULT_STUDENT_ID"])
        if not student or not student.get("bus_id"):
            abort(404)
        bus = q.get_bus(conn, student["bus_id"])
        school = q.get_school(conn)
        roster = q.student_roster(conn, bus_only=True)

    bus_to_pickup_km = haversine_km(
        bus["lat"], bus["lng"], student["pickup_lat"], student["pickup_lng"]
    )
    bus_to_school_km = haversine_km(
        bus["lat"], bus["lng"], school["lat"], school["lng"]
    )
    metrics = {
        "bus_to_pickup_km": round(bus_to_pickup_km, 2),
        "bus_to_pickup_min": eta_minutes(bus_to_pickup_km),
        "bus_to_school_km": round(bus_to_school_km, 2),
        "bus_to_school_min": eta_minutes(bus_to_school_km),
    }

    return render_template(
        "dashboard.html",
        student=student,
        bus=bus,
        school=school,
        metrics=metrics,
        roster=roster,
    )
