from flask import Blueprint, render_template, request, abort

from shared.db.database import get_db
from shared.db import queries as q
from modules.reports.generator import build_report

bus_bp = Blueprint("bus", __name__, template_folder="../../templates")


@bus_bp.route("/")
def list_buses():
    with get_db() as conn:
        buses = q.all_buses(conn)
    return render_template("bus/list.html", buses=buses, active_tab="bus")


@bus_bp.route("/<int:bus_id>")
def detail(bus_id):
    with get_db() as conn:
        bus = q.get_bus(conn, bus_id)
        if not bus:
            abort(404)
        students = q.students_for_bus(conn, bus_id)
    return render_template("bus/detail.html", bus=bus, students=students, active_tab="bus")


@bus_bp.route("/report")
def report():
    fmt = request.args.get("fmt", "pdf")
    with get_db() as conn:
        buses = q.all_buses(conn)
    headers = ["Bus No.", "Plate", "Start Location", "Route", "Driver", "Status"]
    rows = [[b["number"], b["plate"], b["start_location"], b["route"],
             b["driver"], b["status"]] for b in buses]
    return build_report("Bus Day Wise Report", headers, rows, fmt)


@bus_bp.route("/<int:bus_id>/report")
def detail_report(bus_id):
    fmt = request.args.get("fmt", "pdf")
    with get_db() as conn:
        bus = q.get_bus(conn, bus_id)
        if not bus:
            abort(404)
        students = q.students_for_bus(conn, bus_id)
    headers = ["Student Name", "SPR No", "Class", "Gender", "Boarding Status"]
    rows = [[s["name"], s["spr_no"], s["class_name"], s["gender"], s["boarding_status"]]
            for s in students]
    return build_report(f"{bus['number']} Student Report", headers, rows, fmt)
