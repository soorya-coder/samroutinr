from flask import Blueprint, render_template, request

from shared.db.database import get_db
from shared.db import queries as q
from modules.reports.generator import build_report

live_bp = Blueprint("live", __name__, template_folder="../../templates")


@live_bp.route("/")
def index():
    with get_db() as conn:
        buses = q.all_buses(conn)
        stats = q.live_stats(conn)
    return render_template("live.html", buses=buses, stats=stats, active_tab="live")


@live_bp.route("/report")
def report():
    fmt = request.args.get("fmt", "pdf")
    with get_db() as conn:
        buses = q.all_buses(conn)
    headers = ["Bus", "Plate", "Route", "Driver", "Status", "Lat", "Lng"]
    rows = [[b["number"], b["plate"], b["route"], b["driver"],
             b["status"], b["lat"], b["lng"]] for b in buses]
    return build_report("Live Day Wise Report", headers, rows, fmt)
