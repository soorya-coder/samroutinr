from datetime import date

from flask import Blueprint, render_template, request, abort

from shared.db.database import get_db
from shared.db import queries as q
from modules.reports.generator import build_report

classes_bp = Blueprint("classes", __name__, template_folder="../../templates")


@classes_bp.route("/")
def index():
    with get_db() as conn:
        classes = q.class_summary(conn)
        overview = q.class_overview_totals(conn)
        absentees = q.absent_students_today(conn)
    today_short = date.today().strftime("%d %b").upper()
    return render_template("classes.html",
                           classes=classes,
                           overview=overview,
                           absentees=absentees,
                           today_short=today_short,
                           active_tab="classes")


@classes_bp.route("/<int:class_id>")
def detail(class_id):
    with get_db() as conn:
        cls = q.get_class(conn, class_id)
        if not cls:
            abort(404)
        students = q.students_for_class(conn, class_id)
    return render_template("class_detail.html", cls=cls, students=students,
                           active_tab="classes")


@classes_bp.route("/report")
def report():
    fmt = request.args.get("fmt", "pdf")
    with get_db() as conn:
        classes = q.class_summary(conn)
        overview = q.class_overview_totals(conn)
    headers = ["Class", "Teacher", "Total", "Bus Users", "Present",
               "Boarded", "Not Boarded", "Absent"]
    rows = [[c["name"], c["teacher"], c["total"], c["bus_users"],
             c["present"], c["boarded"], c["not_boarded"], c["absent"]]
            for c in classes]
    rows.append(["ALL CLASSES", "", overview["total"], overview["bus_users"],
                 overview["present"], overview["boarded"],
                 overview["not_boarded"], overview["absent"]])
    return build_report("Class Day Wise Report", headers, rows, fmt)


@classes_bp.route("/<int:class_id>/report")
def detail_report(class_id):
    fmt = request.args.get("fmt", "pdf")
    with get_db() as conn:
        cls = q.get_class(conn, class_id)
        if not cls:
            abort(404)
        students = q.students_for_class(conn, class_id)
    headers = ["Student Name", "SPR No", "Section", "Gender", "Bus", "Boarding Status"]
    rows = [[s["name"], s["spr_no"], s.get("section") or "", s["gender"],
             s["bus_number"] or "—", s["boarding_status"]]
            for s in students]
    return build_report(f"{cls['name']} Report", headers, rows, fmt)
