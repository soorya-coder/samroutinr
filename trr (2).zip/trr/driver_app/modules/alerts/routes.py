from datetime import datetime

from flask import Blueprint, render_template, request

from shared.db.database import get_db
from shared.db import queries as q
from modules.reports.generator import build_report

alerts_bp = Blueprint("alerts", __name__, template_folder="../../templates")


def _short_time(ts):
    try:
        return datetime.strptime(ts, "%Y-%m-%d %H:%M").strftime("%I:%M %p").lstrip("0")
    except Exception:
        return ts


def _decorate(alerts):
    for a in alerts:
        a["timestamp_short"] = _short_time(a["timestamp"])
    return alerts


@alerts_bp.route("/")
def index():
    with get_db() as conn:
        alerts = _decorate(q.all_alerts(conn))
    return render_template("alerts.html", alerts=alerts, active_tab="alerts")


@alerts_bp.route("/report")
def report():
    fmt = request.args.get("fmt", "pdf")
    with get_db() as conn:
        alerts = q.all_alerts(conn)
    headers = ["Severity", "Title", "Description", "Context", "Timestamp"]
    rows = [[a["severity"].title(), a["title"], a.get("description") or "",
             a["context"], a["timestamp"]]
            for a in alerts]
    return build_report("Alerts Day Wise Report", headers, rows, fmt)
