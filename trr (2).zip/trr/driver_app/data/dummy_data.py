"""Re-export shim. Real data lives in shared/data/dummy_data.py."""
import os
import sys

_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from shared.data.dummy_data import *  # noqa: F401,F403
