class Config:
    SCHOOL_NAME = "Mount Zion Schools"
    SECRET_KEY = "dev-only-not-secret"
    DEBUG = True
