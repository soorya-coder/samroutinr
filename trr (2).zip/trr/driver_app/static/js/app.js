// Search filter — filters rows in any [data-searchable] containing [data-search-item]
document.addEventListener('DOMContentLoaded', () => {
  const search = document.getElementById('global-search');
  if (search) {
    search.addEventListener('input', (e) => {
      const q = e.target.value.trim().toLowerCase();
      document.querySelectorAll('[data-search-item]').forEach(el => {
        const hay = (el.dataset.searchText || el.textContent).toLowerCase();
        el.style.display = !q || hay.includes(q) ? '' : 'none';
      });
    });
  }

  // Download dropdown
  const dl = document.querySelector('.dl-wrap');
  if (dl) {
    const btn = dl.querySelector('.btn-dl');
    const menu = dl.querySelector('.dl-menu');
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.classList.toggle('show');
    });
    document.addEventListener('click', () => menu.classList.remove('show'));
  }
});
