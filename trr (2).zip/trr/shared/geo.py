"""Pure geo helpers — used by route handlers without touching dummy data."""
import math

AVG_BUS_SPEED_KMH = 25.0


def haversine_km(lat1, lng1, lat2, lng2):
    R = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))


def eta_minutes(distance_km, speed_kmh=AVG_BUS_SPEED_KMH):
    if speed_kmh <= 0:
        return 0
    return int(round((distance_km / speed_kmh) * 60))
