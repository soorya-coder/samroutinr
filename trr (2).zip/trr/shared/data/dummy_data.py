"""Mock data shared by driver_app and student_app. Edit freely."""
import math
import random

# Fixed school location (Bengaluru, MG Road area)
SCHOOL = {
    "name": "Mount Zion Schools",
    "lat": 12.9755,
    "lng": 77.6066,
}

CLASSES = [
    {"id": "5A", "name": "Grade 5A", "teacher": "Ms. Iyer"},
    {"id": "5B", "name": "Grade 5B", "teacher": "Mr. Rao"},
    {"id": "6A", "name": "Grade 6A", "teacher": "Ms. Fernandes"},
    {"id": "6B", "name": "Grade 6B", "teacher": "Mr. Kapoor"},
    {"id": "7A", "name": "Grade 7A", "teacher": "Ms. Pillai"},
    {"id": "7B", "name": "Grade 7B", "teacher": "Mr. Joshi"},
]

BUSES = [
    {"id": 1, "number": "Bus 1", "plate": "KA-01-AA-1101", "route": "Indiranagar Loop",
     "start_location": "Indiranagar Depot", "driver": "Ravi Kumar",
     "lat": 12.9719, "lng": 77.6412, "status": "Departed"},
    {"id": 2, "number": "Bus 2", "plate": "KA-01-AB-2202", "route": "Koramangala Express",
     "start_location": "Koramangala Hub", "driver": "Suresh M.",
     "lat": 12.9352, "lng": 77.6245, "status": "In Transit"},
    {"id": 3, "number": "Bus 3", "plate": "KA-01-AC-3303", "route": "Whitefield Line",
     "start_location": "Whitefield Yard", "driver": "Mohammed Arif",
     "lat": 12.9698, "lng": 77.7500, "status": "Delayed"},
    {"id": 4, "number": "Bus 4", "plate": "KA-01-AD-4404", "route": "Jayanagar Route",
     "start_location": "Jayanagar 4th Block", "driver": "Lakshmi N.",
     "lat": 12.9250, "lng": 77.5938, "status": "Not Departed"},
    {"id": 5, "number": "Bus 5", "plate": "KA-01-AE-5505", "route": "HSR Layout Pickup",
     "start_location": "HSR Sector 2", "driver": "Anil Reddy",
     "lat": 12.9116, "lng": 77.6473, "status": "Departed"},
    {"id": 6, "number": "Bus 6", "plate": "KA-01-AF-6606", "route": "Hebbal Connector",
     "start_location": "Hebbal Depot", "driver": "Priya S.",
     "lat": 13.0356, "lng": 77.5970, "status": "In Transit"},
    {"id": 7, "number": "Bus 7", "plate": "KA-01-AG-7707", "route": "Electronic City",
     "start_location": "EC Phase 1", "driver": "Vikram Singh",
     "lat": 12.8456, "lng": 77.6603, "status": "Departed"},
    {"id": 8, "number": "Bus 8", "plate": "KA-01-AH-8808", "route": "Marathahalli Round",
     "start_location": "Marathahalli Bridge", "driver": "Deepa K.",
     "lat": 12.9591, "lng": 77.6974, "status": "Not Departed"},
]


def _make_students():
    first_names = ["Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Reyansh",
                   "Ayaan", "Krishna", "Ishaan", "Ananya", "Diya", "Saanvi", "Aadhya",
                   "Pari", "Myra", "Anika", "Navya", "Kiara", "Riya"]
    last_names = ["Sharma", "Verma", "Iyer", "Reddy", "Nair", "Patel", "Singh",
                  "Khan", "Das", "Pillai"]
    genders = ["Male", "Female"]
    statuses = ["Boarded", "Boarded", "Boarded", "Not Boarded"]
    fees_choices = [0, 0, 0, 4500, 8200, 12500, 1800]

    rnd = random.Random(42)
    students = []
    sid = 1
    for i in range(80):
        fn = rnd.choice(first_names)
        ln = rnd.choice(last_names)
        bus = BUSES[i % len(BUSES)]
        cls = CLASSES[i % len(CLASSES)]
        # ~20% of students don't use the school bus at all (every 5th)
        uses_bus = (i % 5 != 4)
        # Pickup point: small offset around the bus start area (~0.5-2 km)
        pickup_lat = bus["lat"] + rnd.uniform(-0.018, 0.018)
        pickup_lng = bus["lng"] + rnd.uniform(-0.018, 0.018)
        fees = rnd.choice(fees_choices)
        is_present = rnd.random() > 0.15  # ~85% present
        students.append({
            "id": sid,
            "name": f"{fn} {ln}",
            "spr_no": f"SPR{1000 + sid}",
            "class_id": cls["id"],
            "class_name": cls["name"],
            "gender": rnd.choice(genders),
            "bus_id": bus["id"] if uses_bus else None,
            "bus_number": bus["number"] if uses_bus else None,
            "boarding_status": rnd.choice(statuses) if uses_bus else "Not Boarded",
            "pickup_lat": round(pickup_lat, 6),
            "pickup_lng": round(pickup_lng, 6),
            "fees_balance": fees,
            "fees_status": "Paid" if fees == 0 else "Outstanding",
            "is_present": is_present,
            "section": rnd.choice(["A", "B"]),
        })
        sid += 1
    return students


STUDENTS = _make_students()

ALERTS = [
    {"id": 1, "severity": "warning", "title": "Bus 3 delayed by 15 min",
     "context": "Bus 3 — Whitefield Line",
     "description": "Traffic on Whitefield Line. ETA pushed by 15 minutes for 42 students.",
     "timestamp": "2026-05-22 07:42"},
    {"id": 2, "severity": "critical", "title": "Student missed pickup — Bus 2",
     "context": "Bus 2 — Koramangala Express",
     "description": "Pickup confirmed missed at Koramangala 5th block stop.",
     "timestamp": "2026-05-22 07:35"},
    {"id": 3, "severity": "info", "title": "Driver swap requested",
     "context": "Bus 5 — HSR Layout Pickup",
     "description": "Substitute driver assigned for the afternoon return trip.",
     "timestamp": "2026-05-22 07:10"},
    {"id": 4, "severity": "warning", "title": "Bus 7 stuck in traffic",
     "context": "Bus 7 — Electronic City",
     "description": "Heavy traffic on Hosur Road. ETA updated to 8:10 AM for 38 students.",
     "timestamp": "2026-05-22 07:50"},
    {"id": 5, "severity": "success", "title": "Bus 1 arrived safely",
     "context": "Bus 1 — Indiranagar Loop",
     "description": "48 students dropped at Mount Zion Schools main gate. On time.",
     "timestamp": "2026-05-22 08:15"},
    {"id": 6, "severity": "critical", "title": "Bus 8 hasn't departed",
     "context": "Bus 8 — Marathahalli Round",
     "description": "Departure delayed by mechanical check. Awaiting confirmation.",
     "timestamp": "2026-05-22 07:55"},
    {"id": 7, "severity": "info", "title": "Route updated for Bus 6",
     "context": "Bus 6 — Hebbal Connector",
     "description": "Detour via Bellary Road due to ongoing maintenance work.",
     "timestamp": "2026-05-22 06:48"},
    {"id": 8, "severity": "warning", "title": "Low fuel reported",
     "context": "Bus 4 — Jayanagar Route",
     "description": "Fuel level at 12%. Refuel scheduled before afternoon trip.",
     "timestamp": "2026-05-22 07:20"},
    {"id": 9, "severity": "success", "title": "All clear on Bus 5",
     "context": "Bus 5 — HSR Layout Pickup",
     "description": "HSR Layout pickup completed without incident. 36 students aboard.",
     "timestamp": "2026-05-22 08:02"},
    {"id": 10, "severity": "critical", "title": "Emergency brake test failed",
     "context": "Bus 3 — Whitefield Line",
     "description": "Scheduled pre-trip brake test failed. Bus pulled for inspection.",
     "timestamp": "2026-05-22 06:30"},
]


# ---------- helpers ----------
AVG_BUS_SPEED_KMH = 25.0


def haversine_km(lat1, lng1, lat2, lng2):
    """Great-circle distance between two lat/lng points in kilometers."""
    R = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))


def eta_minutes(distance_km, speed_kmh=AVG_BUS_SPEED_KMH):
    if speed_kmh <= 0:
        return 0
    return int(round((distance_km / speed_kmh) * 60))


def get_bus(bus_id):
    return next((b for b in BUSES if b["id"] == int(bus_id)), None)


def get_student(student_id):
    return next((s for s in STUDENTS if s["id"] == int(student_id)), None)


def students_for_bus(bus_id):
    return [s for s in STUDENTS if s["bus_id"] == int(bus_id)]


def students_for_class(class_id):
    return [s for s in STUDENTS if s["class_id"] == class_id]


def get_class(class_id):
    return next((c for c in CLASSES if c["id"] == class_id), None)


def class_summary():
    rows = []
    for c in CLASSES:
        kids = students_for_class(c["id"])
        boarded = sum(1 for s in kids if s["boarding_status"] == "Boarded")
        absent = len(kids) - boarded
        rows.append({**c, "total": len(kids), "boarded": boarded, "absent": absent})
    return rows


def live_stats():
    active = sum(1 for b in BUSES if b["status"] in ("Departed", "In Transit"))
    boarded = sum(1 for s in STUDENTS if s["boarding_status"] == "Boarded")
    absent = sum(1 for s in STUDENTS if s["boarding_status"] == "Not Boarded")
    return {"active_buses": active, "boarded": boarded, "absent": absent}
