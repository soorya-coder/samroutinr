"""Reusable SELECTs. Columns are aliased to match existing template field names
so templates keep working without changes.
"""

BUS_COLS = """
  id,
  bus_number        AS number,
  number_plate      AS plate,
  route_name        AS route,
  starting_location AS start_location,
  driver_name       AS driver,
  current_lat       AS lat,
  current_lng       AS lng,
  departure_status  AS status
"""

STUDENT_COLS = """
  s.id              AS id,
  s.name            AS name,
  s.spr_number      AS spr_no,
  s.class_id        AS class_id,
  c.name            AS class_name,
  s.gender          AS gender,
  s.bus_id          AS bus_id,
  b.bus_number      AS bus_number,
  s.boarding_status AS boarding_status,
  s.pickup_lat      AS pickup_lat,
  s.pickup_lng      AS pickup_lng,
  s.fees_balance    AS fees_balance,
  s.fees_status     AS fees_status,
  s.is_present      AS is_present,
  s.section         AS section
"""


def rows(cur):
    """Return current cursor's results as a list of plain dicts."""
    return [dict(r) for r in cur.fetchall()]


def one(cur):
    r = cur.fetchone()
    return dict(r) if r else None


# ---------- bus ----------

def all_buses(conn):
    return rows(conn.execute(f"SELECT {BUS_COLS} FROM bus ORDER BY id"))


def get_bus(conn, bus_id):
    return one(conn.execute(f"SELECT {BUS_COLS} FROM bus WHERE id = ?", (bus_id,)))


def students_for_bus(conn, bus_id):
    return rows(conn.execute(
        f"""SELECT {STUDENT_COLS}
            FROM student s
            JOIN school_class c ON s.class_id = c.id
            LEFT JOIN bus b ON s.bus_id = b.id
            WHERE s.bus_id = ?
            ORDER BY s.id""",
        (bus_id,),
    ))


# ---------- student ----------

def all_students(conn):
    return rows(conn.execute(
        f"""SELECT {STUDENT_COLS}
            FROM student s
            JOIN school_class c ON s.class_id = c.id
            LEFT JOIN bus b ON s.bus_id = b.id
            ORDER BY s.id"""
    ))


def get_student(conn, student_id):
    return one(conn.execute(
        f"""SELECT {STUDENT_COLS}
            FROM student s
            JOIN school_class c ON s.class_id = c.id
            LEFT JOIN bus b ON s.bus_id = b.id
            WHERE s.id = ?""",
        (student_id,),
    ))


def student_roster(conn, bus_only=False):
    sql = "SELECT id, name, spr_number AS spr_no FROM student"
    if bus_only:
        sql += " WHERE bus_id IS NOT NULL"
    sql += " ORDER BY id"
    return rows(conn.execute(sql))


# ---------- class ----------

def class_summary(conn):
    return rows(conn.execute(
        """SELECT
             c.id,
             c.name,
             c.teacher,
             COUNT(s.id) AS total,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL                                                   THEN 1 ELSE 0 END), 0) AS bus_users,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1                              THEN 1 ELSE 0 END), 0) AS present,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1
                                AND s.boarding_status = 'Boarded'                                         THEN 1 ELSE 0 END), 0) AS boarded,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1
                                AND s.boarding_status != 'Boarded'                                        THEN 1 ELSE 0 END), 0) AS not_boarded,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 0                             THEN 1 ELSE 0 END), 0) AS absent
           FROM school_class c
           LEFT JOIN student s ON s.class_id = c.id
           GROUP BY c.id ORDER BY c.id"""
    ))


def class_overview_totals(conn):
    """Aggregated totals across all classes for the Classes-page header strip."""
    return one(conn.execute(
        """SELECT
             COUNT(s.id) AS total,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL                                                   THEN 1 ELSE 0 END), 0) AS bus_users,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1                              THEN 1 ELSE 0 END), 0) AS present,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1
                                AND s.boarding_status = 'Boarded'                                         THEN 1 ELSE 0 END), 0) AS boarded,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 1
                                AND s.boarding_status != 'Boarded'                                        THEN 1 ELSE 0 END), 0) AS not_boarded,
             COALESCE(SUM(CASE WHEN s.bus_id IS NOT NULL AND s.is_present = 0                             THEN 1 ELSE 0 END), 0) AS absent
           FROM student s"""
    ))


def absent_students_today(conn):
    return rows(conn.execute(
        """SELECT s.id, s.name, s.section,
                  c.name       AS class_name,
                  b.bus_number AS bus_number
           FROM student s
           JOIN school_class c ON s.class_id = c.id
           LEFT JOIN bus b ON s.bus_id = b.id
           WHERE s.is_present = 0
           ORDER BY c.id, s.name"""
    ))


def get_class(conn, class_id):
    return one(conn.execute(
        "SELECT id, name, teacher FROM school_class WHERE id = ?", (class_id,)
    ))


def students_for_class(conn, class_id):
    return rows(conn.execute(
        f"""SELECT {STUDENT_COLS}
            FROM student s
            JOIN school_class c ON s.class_id = c.id
            LEFT JOIN bus b ON s.bus_id = b.id
            WHERE s.class_id = ?
            ORDER BY s.id""",
        (class_id,),
    ))


# ---------- alerts ----------

def all_alerts(conn):
    return rows(conn.execute(
        """SELECT a.id,
                  a.message     AS title,
                  a.description AS description,
                  a.severity    AS severity,
                  a.timestamp   AS timestamp,
                  COALESCE(b.bus_number || ' — ' || b.route_name, '') AS context
           FROM alert a
           LEFT JOIN bus b ON a.bus_id = b.id
           ORDER BY a.timestamp DESC"""
    ))


# ---------- live stats ----------

def live_stats(conn):
    return one(conn.execute(
        """SELECT
             (SELECT COUNT(*) FROM bus     WHERE departure_status != 'Not Departed') AS active_buses,
             (SELECT COUNT(*) FROM student WHERE boarding_status   = 'Boarded')      AS boarded,
             (SELECT COUNT(*) FROM student WHERE boarding_status   = 'Not Boarded')  AS absent"""
    ))


# ---------- school ----------

def get_school(conn):
    return one(conn.execute("SELECT id, name, lat, lng FROM school LIMIT 1"))
