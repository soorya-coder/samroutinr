"""SQLite connection helpers + lifecycle."""
import os
import sqlite3
from contextlib import contextmanager

DB_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(DB_DIR, "transport.db")


def _connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


@contextmanager
def get_db():
    """Yield a sqlite3 connection with row_factory = Row. Auto-closes."""
    conn = _connect()
    try:
        yield conn
    finally:
        conn.close()


def init_db():
    """Create tables if they don't exist (no data)."""
    from shared.db.schema import SCHEMA_SQL
    with _connect() as conn:
        conn.executescript(SCHEMA_SQL)
        conn.commit()


def ensure_db_ready():
    """First-run guard: create + seed if the DB file is missing."""
    if not os.path.exists(DB_PATH):
        from shared.db.seed import seed
        seed()
