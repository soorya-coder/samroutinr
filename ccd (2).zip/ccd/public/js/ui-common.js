// Shared UI: light/dark theme toggle (persisted) + change-password modal.
// Depends on api.js (for api.post) and, optionally, toast() if present.
(function () {
  // ---- Light theme overrides (dark is the markup default) ----------------
  const LIGHT_CSS = `
    html:not(.dark) body { background:#eef2f6 !important; color:#0f172a; }
    html:not(.dark) .bg-slate-950,
    html:not(.dark) .bg-slate-950\\/80,
    html:not(.dark) .bg-slate-950\\/60 { background-color:#ffffff !important; }
    html:not(.dark) .bg-slate-900,
    html:not(.dark) .bg-slate-900\\/70,
    html:not(.dark) .bg-slate-900\\/60,
    html:not(.dark) .bg-slate-900\\/40 { background-color:#ffffff !important; }
    html:not(.dark) aside.bg-slate-950\\/80 { background-color:#ffffff !important; }
    html:not(.dark) header { background-color:#ffffffcc !important; }
    html:not(.dark) .border-slate-800,
    html:not(.dark) .border-slate-700,
    html:not(.dark) .border-b.border-slate-800 { border-color:#e2e8f0 !important; }
    html:not(.dark) .divide-slate-800\\/70 > :not([hidden]) ~ :not([hidden]) { border-color:#e5e9f0 !important; }
    html:not(.dark) .text-slate-100,
    html:not(.dark) .text-slate-200,
    html:not(.dark) .text-slate-300 { color:#0f172a !important; }
    html:not(.dark) .text-slate-400 { color:#475569 !important; }
    html:not(.dark) .text-slate-500 { color:#64748b !important; }
    html:not(.dark) input,
    html:not(.dark) select,
    html:not(.dark) textarea { background-color:#f8fafc !important; border-color:#cbd5e1 !important; color:#0f172a !important; }
    html:not(.dark) .hover\\:bg-slate-900:hover,
    html:not(.dark) .hover\\:bg-slate-800:hover { background-color:#eef2f6 !important; }
    html:not(.dark) .nav-link.active { background:linear-gradient(90deg, rgba(34,211,238,.18), rgba(139,92,246,.12)) !important; color:#0f172a !important; }
    html:not(.dark) ::-webkit-scrollbar-thumb { background:#cbd5e1 !important; }
  `;

  function injectStyle() {
    if (document.getElementById('light-theme-css')) return;
    const style = document.createElement('style');
    style.id = 'light-theme-css';
    style.textContent = LIGHT_CSS;
    document.head.appendChild(style);
  }

  function applyTheme(theme) {
    if (theme === 'light') document.documentElement.classList.remove('dark');
    else document.documentElement.classList.add('dark');
  }

  function currentTheme() {
    return localStorage.getItem('theme') === 'light' ? 'light' : 'dark';
  }

  function notify(msg, isErr) {
    if (typeof toast === 'function') toast(msg, isErr);
    else alert(msg);
  }

  // ---- Header controls ---------------------------------------------------
  function buildControls() {
    const header = document.querySelector('header');
    if (!header) return; // e.g. login page — theme still applies, no controls
    const controls = header.querySelector(':scope > div:last-child') || header;

    const wrap = document.createElement('div');
    wrap.className = 'flex items-center gap-2';

    const themeBtn = document.createElement('button');
    themeBtn.id = 'theme-toggle';
    themeBtn.title = 'Toggle light / dark theme';
    themeBtn.className = 'w-9 h-9 rounded-lg border border-slate-700 flex items-center justify-center text-slate-300 hover:bg-slate-800 transition';
    const paintIcon = () => { themeBtn.textContent = currentTheme() === 'dark' ? '☀️' : '🌙'; };
    paintIcon();
    themeBtn.addEventListener('click', () => {
      const next = currentTheme() === 'dark' ? 'light' : 'dark';
      localStorage.setItem('theme', next);
      applyTheme(next);
      paintIcon();
    });

    const pwdBtn = document.createElement('button');
    pwdBtn.id = 'change-pwd-btn';
    pwdBtn.className = 'px-3 py-1.5 rounded-lg border border-slate-700 text-slate-300 text-xs font-medium hover:bg-slate-800 transition';
    pwdBtn.textContent = 'Change Password';
    pwdBtn.addEventListener('click', openPwdModal);

    wrap.appendChild(themeBtn);
    wrap.appendChild(pwdBtn);
    controls.insertBefore(wrap, controls.firstChild);
  }

  // ---- Change-password modal --------------------------------------------
  function openPwdModal() {
    if (document.getElementById('pwd-modal')) return;
    const modal = document.createElement('div');
    modal.id = 'pwd-modal';
    modal.className = 'fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4';
    modal.innerHTML = `
      <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 w-full max-w-md">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-base font-semibold text-slate-100">Change Password</h3>
          <button id="pwd-close" class="text-slate-500 hover:text-slate-200">&#10005;</button>
        </div>
        <form id="pwd-form" class="space-y-3">
          <div>
            <label class="block text-sm text-slate-300 mb-1.5">Current Password</label>
            <input id="pwd-current" type="password" required
              class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/60 focus:border-cyan-500" />
          </div>
          <div>
            <label class="block text-sm text-slate-300 mb-1.5">New Password</label>
            <input id="pwd-new" type="password" required minlength="6"
              class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/60 focus:border-cyan-500" />
          </div>
          <div>
            <label class="block text-sm text-slate-300 mb-1.5">Confirm New Password</label>
            <input id="pwd-confirm" type="password" required minlength="6"
              class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/60 focus:border-cyan-500" />
          </div>
          <div class="flex justify-end gap-3 pt-2">
            <button type="button" id="pwd-cancel" class="px-4 py-2 rounded-lg border border-slate-700 text-slate-300 text-sm hover:bg-slate-800">Cancel</button>
            <button type="submit" class="px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-violet-600 text-slate-950 font-semibold text-sm hover:opacity-90 transition">Update Password</button>
          </div>
        </form>
      </div>`;
    document.body.appendChild(modal);

    const close = () => modal.remove();
    modal.querySelector('#pwd-close').addEventListener('click', close);
    modal.querySelector('#pwd-cancel').addEventListener('click', close);
    modal.addEventListener('click', (e) => { if (e.target === modal) close(); });

    modal.querySelector('#pwd-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const currentPassword = modal.querySelector('#pwd-current').value;
      const newPassword = modal.querySelector('#pwd-new').value;
      const confirm = modal.querySelector('#pwd-confirm').value;
      if (newPassword !== confirm) return notify('New password and confirmation do not match', true);
      try {
        await api.post('/api/auth/change-password', { currentPassword, newPassword });
        notify('Password updated successfully');
        close();
      } catch (err) {
        notify(err.message, true);
      }
    });
  }

  // ---- Init --------------------------------------------------------------
  injectStyle();
  applyTheme(currentTheme());
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', buildControls);
  } else {
    buildControls();
  }
})();
