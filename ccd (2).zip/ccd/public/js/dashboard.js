let CURRENT_USER = null;

const NAV = [
  { key: 'overview', label: 'Overview', icon: '&#9670;', roles: 'all' },
  { key: 'add-user', label: 'Add User', icon: '&#43;', roles: ['admin'] },
  { key: 'bulk-upload', label: 'Bulk Upload', icon: '&#8613;', roles: ['admin'] },
  { key: 'all-users', label: 'All Users', icon: '&#9776;', roles: ['admin'] },
  { key: 'semester', label: 'Semester Setup', icon: '&#128197;', roles: ['admin'] },
  { key: 'attendance', label: 'Attendance', icon: '&#128200;', roles: ['admin', 'hod', 'faculty_advisor', 'class_coordinator', 'coordinator'] },
  { key: 'compose', label: 'Send Task / Message', icon: '&#9993;', roles: ['coordinator'] },
  { key: 'sent', label: 'Sent Items', icon: '&#128228;', roles: ['coordinator'] },
  { key: 'dept-leave', label: 'Dept Leave (Coordinator)', icon: '&#128218;', roles: ['coordinator'] },
  { key: 'dept-od', label: 'Dept ODs (Coordinator)', icon: '&#128218;', roles: ['coordinator'] },
  { key: 'inbox', label: 'Inbox', icon: '&#128276;', roles: ['hod', 'faculty_advisor', 'student', 'class_coordinator'] },
  { key: 'hod-mapping', label: 'Student Mapping', icon: '&#128101;', roles: ['hod'] },
  { key: 'reports', label: 'Reports', icon: '&#128196;', roles: ['hod', 'faculty_advisor', 'class_coordinator', 'admin'] },
  { key: 'apply-od', label: 'Apply for OD', icon: '&#128197;', roles: ['student'] },
  { key: 'my-od', label: 'My OD Requests', icon: '&#128203;', roles: ['student'] },
  { key: 'apply-leave', label: 'Apply for Leave', icon: '&#9992;', roles: ['student'] },
  { key: 'my-leave', label: 'My Leave Requests', icon: '&#128203;', roles: ['student'] },
  { key: 'od-queue', label: 'OD Approvals', icon: '&#9989;', roles: ['faculty_advisor'] },
  { key: 'leave-fa-queue', label: 'Leave Approvals', icon: '&#9989;', roles: ['faculty_advisor'] },
  { key: 'fa-mapping', label: 'Faculty Advisor Mapping', icon: '&#128101;', roles: ['faculty_advisor'] },
  { key: 'leave-cc-queue', label: 'Leave Records', icon: '&#128218;', roles: ['class_coordinator'] },
  { key: 'cc-mapping', label: 'Class Coordinator Mapping', icon: '&#128101;', roles: ['class_coordinator'] }
];

const DEPARTMENTS = ['CSE', 'CIVIL', 'MECH', 'EEE', 'ECE', 'AI&DS', 'IT', 'MBA'];
const YEARS = ['I Year', 'II Year', 'III Year', 'IV Year'];
const SECTIONS = ['A', 'B'];

const ROLE_LABELS = {
  admin: 'Admin',
  coordinator: 'Counselling Coordinator',
  hod: 'HOD',
  class_coordinator: 'Class Coordinator',
  faculty_advisor: 'Faculty Advisor',
  student: 'Student'
};

async function boot() {
  try {
    const { user } = await api.get('/api/auth/me');
    CURRENT_USER = user;
  } catch (err) {
    window.location.href = '/index.html';
    return;
  }

  document.getElementById('user-name').textContent = CURRENT_USER.name;
  const badgeRoles = (CURRENT_USER.roles && CURRENT_USER.roles.length ? CURRENT_USER.roles : [CURRENT_USER.role]);
  document.getElementById('user-role-badge').textContent = badgeRoles.map((r) => ROLE_LABELS[r] || r).join(' + ');
  document.getElementById('avatar').textContent = CURRENT_USER.name.charAt(0).toUpperCase();

  renderNav();
  navigateTo('overview');

  document.getElementById('logout-btn').addEventListener('click', async () => {
    await api.post('/api/auth/logout');
    window.location.href = '/index.html';
  });
}

function renderNav() {
  const myRoles = (CURRENT_USER.roles && CURRENT_USER.roles.length ? CURRENT_USER.roles : [CURRENT_USER.role]);
  const items = NAV.filter((n) => n.roles === 'all' || n.roles.some((r) => myRoles.includes(r)));
  const nav = document.getElementById('nav-links');
  nav.innerHTML = items.map((n) => `
    <a href="#${n.key}" data-key="${n.key}"
       class="nav-link flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-900 transition">
      <span class="w-5 text-center">${n.icon}</span>${n.label}
    </a>`).join('');

  nav.querySelectorAll('.nav-link').forEach((a) => {
    a.addEventListener('click', (e) => {
      e.preventDefault();
      navigateTo(a.dataset.key);
    });
  });
}

function setActiveNav(key) {
  document.querySelectorAll('.nav-link').forEach((a) => a.classList.toggle('active', a.dataset.key === key));
}

const RENDERERS = {
  overview: renderOverview,
  'add-user': renderAddUser,
  'bulk-upload': renderBulkUpload,
  'all-users': renderAllUsers,
  compose: renderCompose,
  sent: renderSent,
  inbox: renderInbox,
  'apply-od': renderApplyOd,
  'my-od': renderMyOd,
  'apply-leave': renderApplyLeave,
  'my-leave': renderMyLeave,
  'od-queue': renderOdQueue,
  'leave-fa-queue': renderLeaveFaQueue,
  'fa-mapping': renderFaMapping,
  'leave-cc-queue': renderLeaveCcQueue,
  'cc-mapping': renderCcMapping,
  'hod-mapping': renderHodMapping,
  'reports': renderReports,
  'semester': renderSemesterSetup,
  'attendance': renderAttendance,
  'dept-leave': renderCoordDeptLeave,
  'dept-od': renderCoordDeptOd
};

const TITLES = {
  overview: 'Overview',
  'add-user': 'Add User',
  'bulk-upload': 'Bulk Upload Users',
  'all-users': 'All Users',
  compose: 'Send Task / Message',
  sent: 'Sent Items',
  inbox: 'Inbox',
  'apply-od': 'Apply for On-Duty (OD)',
  'my-od': 'My OD Requests',
  'apply-leave': 'Apply for Leave',
  'my-leave': 'My Leave Requests',
  'od-queue': 'OD Approvals',
  'leave-fa-queue': 'Leave Approvals',
  'fa-mapping': 'Faculty Advisor Mapping',
  'leave-cc-queue': 'Leave Records',
  'cc-mapping': 'Class Coordinator Mapping',
  'hod-mapping': 'Student Mapping (HOD)',
  'reports': 'Reports',
  'semester': 'Semester Setup',
  'attendance': 'Attendance Report',
  'dept-leave': 'Department Leaves',
  'dept-od': 'Department ODs'
};

async function navigateTo(key) {
  setActiveNav(key);
  document.getElementById('page-title').textContent = TITLES[key] || '';
  const content = document.getElementById('content');
  content.innerHTML = `<div class="text-slate-500 text-sm">Loading...</div>`;
  try {
    await RENDERERS[key]();
  } catch (err) {
    content.innerHTML = `<div class="text-rose-400 text-sm">${err.message}</div>`;
  }
}

function card(inner, extraClasses = '') {
  return `<div class="bg-slate-900/60 border border-slate-800 rounded-xl p-6 ${extraClasses}">${inner}</div>`;
}

function input(label, id, type = 'text', required = true) {
  return `
    <div>
      <label class="block text-sm text-slate-300 mb-1.5">${label}</label>
      <input id="${id}" type="${type}" ${required ? 'required' : ''}
        class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/60 focus:border-cyan-500" />
    </div>`;
}

function textarea(label, id, required = true) {
  return `
    <div>
      <label class="block text-sm text-slate-300 mb-1.5">${label}</label>
      <textarea id="${id}" rows="3" ${required ? 'required' : ''}
        class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/60 focus:border-cyan-500"></textarea>
    </div>`;
}

function select(label, id, options) {
  return `
    <div>
      <label class="block text-sm text-slate-300 mb-1.5">${label}</label>
      <select id="${id}" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/60 focus:border-cyan-500">
        ${options.map((o) => `<option value="${o.value}">${o.label}</option>`).join('')}
      </select>
    </div>`;
}

function primaryBtn(text) {
  return `<button type="submit" class="px-5 py-2.5 rounded-lg bg-gradient-to-r from-cyan-500 to-violet-600 text-slate-950 font-semibold text-sm hover:opacity-90 transition">${text}</button>`;
}

function table(headers, rows) {
  if (!rows.length) return `<p class="text-slate-500 text-sm py-8 text-center">No records found.</p>`;
  return `
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead>
          <tr class="text-left text-slate-400 border-b border-slate-800">
            ${headers.map((h) => `<th class="py-2.5 px-3 font-medium">${h}</th>`).join('')}
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-800/70">${rows.join('')}</tbody>
      </table>
    </div>`;
}

// ---------- Overview ----------
async function renderOverview() {
  document.getElementById('content').innerHTML = card(`
    <h3 class="text-lg font-semibold mb-1">Welcome, ${CURRENT_USER.name.split(' ')[0]}</h3>
    <p class="text-slate-400 text-sm">Role: ${ROLE_LABELS[CURRENT_USER.role]}${CURRENT_USER.department ? ' &middot; ' + CURRENT_USER.department : ''}</p>
    <p class="text-slate-500 text-sm mt-4">Use the sidebar to manage your workflows.</p>
  `);
}

// ---------- Admin: Add User ----------
function optionList(values, placeholder) {
  return [{ value: '', label: placeholder }].concat(values.map((v) => ({ value: v, label: v })));
}

async function renderAddUser() {
  document.getElementById('content').innerHTML = card(`
    <form id="add-user-form" class="grid grid-cols-1 md:grid-cols-2 gap-4">
      ${input('Name', 'name')}
      ${input('SPR No / Staff No.', 'register_no')}
      ${input('Email', 'email', 'email')}
      ${select('Role', 'role', [
        { value: 'student', label: 'Student' },
        { value: 'faculty_advisor', label: 'Faculty Advisor' },
        { value: 'class_coordinator', label: 'Class Coordinator' },
        { value: 'hod', label: 'HOD' },
        { value: 'coordinator', label: 'Counselling Coordinator' },
        { value: 'admin', label: 'Admin' }
      ])}
      ${select('Department', 'department', optionList(DEPARTMENTS, 'Select department'))}
      <div id="student-fields" class="hidden md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
        ${select('Year', 'year', optionList(YEARS, 'Select year'))}
        ${select('Section', 'section', optionList(SECTIONS, 'Select section'))}
      </div>
      <div class="md:col-span-2 flex items-center justify-between pt-2">
        <p class="text-xs text-slate-500">Default password: <span class="text-slate-300">Welcome@123</span></p>
        ${primaryBtn('Create User')}
      </div>
    </form>
  `);

  const roleSel = document.getElementById('role');
  const studentFields = document.getElementById('student-fields');
  const syncStudentFields = () => {
    const isStudent = roleSel.value === 'student';
    studentFields.classList.toggle('hidden', !isStudent);
    if (!isStudent) {
      document.getElementById('year').value = '';
      document.getElementById('section').value = '';
    }
  };
  roleSel.addEventListener('change', syncStudentFields);
  syncStudentFields();

  document.getElementById('add-user-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const isStudent = val('role') === 'student';
    const body = {
      name: val('name'), email: val('email'), role: val('role'),
      department: val('department'), register_no: val('register_no'),
      // Year & Section are sent only for students; staff => NULL server-side.
      year: isStudent ? val('year') : null,
      section: isStudent ? val('section') : null
    };
    try {
      await api.post('/api/admin/users', body);
      toast('User created successfully');
      e.target.reset();
      syncStudentFields();
    } catch (err) { toast(err.message, true); }
  });
}

function val(id) { return document.getElementById(id).value.trim(); }

// ---------- Admin: Bulk Upload ----------
async function renderBulkUpload() {
  document.getElementById('content').innerHTML = card(`
    <p class="text-sm text-slate-400 mb-4">
      Upload a <code class="text-cyan-300">.xlsx</code>, <code class="text-cyan-300">.xls</code>, or <code class="text-cyan-300">.csv</code> file with columns:
      <span class="text-slate-300">name, email, role, department, register_no (SPR/Staff No), year, section</span>
      (<span class="text-slate-400">year &amp; section apply to students only</span>).
      All new users get the default password <span class="text-slate-300">Welcome@123</span>.
    </p>
    <div id="drop-zone" class="border-2 border-dashed border-slate-700 rounded-xl p-10 text-center cursor-pointer hover:border-cyan-500/60 hover:bg-slate-900/40 transition">
      <p class="text-slate-300 font-medium">Drag & drop your file here</p>
      <p class="text-slate-500 text-sm mt-1">or click to browse</p>
      <input id="file-input" type="file" accept=".xlsx,.xls,.csv" class="hidden" />
    </div>
    <div id="upload-result" class="mt-6"></div>
  `);

  const dropZone = document.getElementById('drop-zone');
  const fileInput = document.getElementById('file-input');

  dropZone.addEventListener('click', () => fileInput.click());
  dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add('border-cyan-500'); });
  dropZone.addEventListener('dragleave', () => dropZone.classList.remove('border-cyan-500'));
  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('border-cyan-500');
    if (e.dataTransfer.files.length) uploadFile(e.dataTransfer.files[0]);
  });
  fileInput.addEventListener('change', () => {
    if (fileInput.files.length) uploadFile(fileInput.files[0]);
  });

  async function uploadFile(file) {
    const formData = new FormData();
    formData.append('file', file);
    document.getElementById('upload-result').innerHTML = `<p class="text-slate-500 text-sm">Uploading & processing...</p>`;
    try {
      const result = await api.post('/api/admin/users/bulk', formData, true);
      document.getElementById('upload-result').innerHTML = `
        <div class="bg-slate-950/60 border border-slate-800 rounded-lg p-4 text-sm">
          <p class="text-emerald-400 font-medium">Inserted: ${result.inserted} &middot; Skipped: ${result.skipped}</p>
          ${result.errors.length ? `<ul class="mt-2 text-rose-400 list-disc list-inside space-y-0.5">${result.errors.map((e) => `<li>${e}</li>`).join('')}</ul>` : ''}
        </div>`;
      toast(`Bulk upload complete: ${result.inserted} inserted`);
    } catch (err) {
      document.getElementById('upload-result').innerHTML = `<p class="text-rose-400 text-sm">${err.message}</p>`;
    }
  }
}

// ---------- Admin: All Users ----------
async function renderAllUsers() {
  const { users } = await api.get('/api/admin/users');
  const rows = users.map((u) => `
    <tr>
      <td class="py-2.5 px-3">${u.name}</td>
      <td class="py-2.5 px-3 text-slate-400">${u.email}</td>
      <td class="py-2.5 px-3">${ROLE_LABELS[u.role] || u.role}</td>
      <td class="py-2.5 px-3 text-slate-400">${u.department || '-'}</td>
      <td class="py-2.5 px-3 text-slate-400">${u.register_no || '-'}</td>
      <td class="py-2.5 px-3 text-slate-400">${u.year || '-'}</td>
      <td class="py-2.5 px-3 text-slate-400">${u.section || '-'}</td>
    </tr>`);
  document.getElementById('content').innerHTML = card(table(['Name', 'Email', 'Role', 'Department', 'SPR/Staff No.', 'Year', 'Section'], rows));
}

// ---------- Coordinator: Compose ----------
async function renderCompose() {
  document.getElementById('content').innerHTML = card(`
    <form id="compose-form" class="space-y-4 max-w-xl">
      ${select('Type', 'type', [{ value: 'task', label: 'Task' }, { value: 'message', label: 'Message' }])}
      ${select('Target Audience', 'target_role', [
        { value: 'hod', label: 'HOD' },
        { value: 'faculty_advisor', label: 'Faculty Advisor' },
        { value: 'student', label: 'Student' },
        { value: 'class_coordinator', label: 'Class Coordinator' },
        { value: 'all', label: 'Everyone' }
      ])}
      ${input('Title', 'title')}
      ${textarea('Body / Instructions', 'body', false)}
      ${input('Due Date (for tasks)', 'due_date', 'date', false)}
      <div>${primaryBtn('Send')}</div>
    </form>
  `);

  document.getElementById('compose-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await api.post('/api/messages', {
        type: val('type'), target_role: val('target_role'), title: val('title'),
        body: val('body'), due_date: val('due_date')
      });
      toast('Sent successfully');
      e.target.reset();
    } catch (err) { toast(err.message, true); }
  });
}

async function renderSent() {
  const { items } = await api.get('/api/messages/sent');
  const rows = items.map((m) => `
    <tr>
      <td class="py-2.5 px-3">${m.type === 'task' ? '📌 Task' : '💬 Message'}</td>
      <td class="py-2.5 px-3">${m.title}</td>
      <td class="py-2.5 px-3 text-slate-400">${ROLE_LABELS[m.target_role] || m.target_role}</td>
      <td class="py-2.5 px-3 text-slate-400">${fmtDate(m.created_at)}</td>
    </tr>`);
  document.getElementById('content').innerHTML = card(table(['Type', 'Title', 'Audience', 'Sent'], rows));
}

// ---------- Inbox (HOD / FA / Student / CC) ----------
async function renderInbox() {
  const { items } = await api.get('/api/messages/inbox');
  const rows = items.map((m) => `
    <tr class="${m.is_read ? '' : 'bg-cyan-500/5'}">
      <td class="py-2.5 px-3">${m.type === 'task' ? '📌 Task' : '💬 Message'}</td>
      <td class="py-2.5 px-3">
        <p class="font-medium">${m.title}</p>
        ${m.body ? `<p class="text-slate-500 text-xs mt-0.5">${m.body}</p>` : ''}
      </td>
      <td class="py-2.5 px-3 text-slate-400">${m.sender_name}</td>
      <td class="py-2.5 px-3 text-slate-400">${fmtDate(m.created_at)}</td>
      <td class="py-2.5 px-3">
        ${m.is_read ? '<span class="text-xs text-slate-500">Read</span>' : `<button data-id="${m.id}" class="mark-read text-xs text-cyan-400 hover:underline">Mark read</button>`}
      </td>
    </tr>`);
  document.getElementById('content').innerHTML = card(table(['Type', 'Title', 'From', 'Received', ''], rows));

  document.querySelectorAll('.mark-read').forEach((btn) => {
    btn.addEventListener('click', async () => {
      await api.post(`/api/messages/${btn.dataset.id}/read`);
      renderInbox();
    });
  });
}

// ---------- Student: OD ----------
async function renderApplyOd() {
  document.getElementById('content').innerHTML = card(`
    <form id="od-form" class="space-y-4 max-w-xl">
      ${input('Event Name', 'event_name')}
      <div class="grid grid-cols-2 gap-4">
        ${input('From', 'event_from', 'date')}
        ${input('To', 'event_to', 'date')}
      </div>
      ${textarea('Reason', 'reason', false)}
      <div>${primaryBtn('Submit OD Request')}</div>
    </form>
  `);

  document.getElementById('od-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await api.post('/api/od', {
        event_name: val('event_name'), event_from: val('event_from'),
        event_to: val('event_to'), reason: val('reason')
      });
      toast('OD request submitted for approval');
      e.target.reset();
    } catch (err) { toast(err.message, true); }
  });
}

async function renderMyOd() {
  const { items } = await api.get('/api/od/mine');
  const rows = items.map((o) => `
    <tr>
      <td class="py-2.5 px-3">${o.event_name}</td>
      <td class="py-2.5 px-3 text-slate-400">${o.event_from} &rarr; ${o.event_to}</td>
      <td class="py-2.5 px-3">${badgeForStatus(o.status)}</td>
      <td class="py-2.5 px-3 text-slate-400">${o.advisor_comment || '-'}</td>
      <td class="py-2.5 px-3">
        ${o.status === 'pending_proof'
          ? `<input type="file" accept=".pdf,.png,.jpg,.jpeg" data-id="${o.id}" class="cert-input text-xs" />`
          : (o.certificate_path ? `<a href="${o.certificate_path}" target="_blank" class="text-xs text-cyan-400 hover:underline">View Certificate</a>` : '-')}
      </td>
    </tr>`);
  document.getElementById('content').innerHTML = card(table(['Event', 'Dates', 'Status', 'Advisor Comment', 'Certificate'], rows));

  document.querySelectorAll('.cert-input').forEach((inp) => {
    inp.addEventListener('change', async () => {
      if (!inp.files.length) return;
      const formData = new FormData();
      formData.append('certificate', inp.files[0]);
      try {
        await api.post(`/api/od/${inp.dataset.id}/certificate`, formData, true);
        toast('Certificate uploaded, OD marked completed');
        renderMyOd();
      } catch (err) { toast(err.message, true); }
    });
  });
}

// ---------- Student: Leave ----------
async function renderApplyLeave() {
  document.getElementById('content').innerHTML = card(`
    <form id="leave-form" class="space-y-4 max-w-xl">
      <div class="grid grid-cols-2 gap-4">
        ${input('From', 'from_date', 'date')}
        ${input('To', 'to_date', 'date')}
      </div>
      ${textarea('Reason', 'reason')}
      <div>${primaryBtn('Submit Leave Application')}</div>
    </form>
  `);

  document.getElementById('leave-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await api.post('/api/leave', { from_date: val('from_date'), to_date: val('to_date'), reason: val('reason') });
      toast('Leave application submitted');
      e.target.reset();
    } catch (err) { toast(err.message, true); }
  });
}

async function renderMyLeave() {
  const { items } = await api.get('/api/leave/mine');
  const rows = items.map((l) => `
    <tr>
      <td class="py-2.5 px-3 text-slate-400">${l.from_date} &rarr; ${l.to_date}</td>
      <td class="py-2.5 px-3">${l.reason}</td>
      <td class="py-2.5 px-3">Advisor: ${badgeForStatus(l.fa_status)}</td>
      <td class="py-2.5 px-3">Coordinator: ${badgeForStatus(l.cc_status)}</td>
    </tr>`);
  document.getElementById('content').innerHTML = card(table(['Dates', 'Reason', 'Advisor', 'Coordinator'], rows));
}

// ---------- Faculty Advisor: OD Queue ----------
async function renderOdQueue() {
  const { items } = await api.get('/api/od/advisor-queue');
  const rows = items.map((o) => `
    <tr>
      <td class="py-2.5 px-3">${o.student_name} <span class="text-slate-500 text-xs">${o.register_no || ''}</span></td>
      <td class="py-2.5 px-3">${o.event_name}</td>
      <td class="py-2.5 px-3 text-slate-400">${o.event_from} &rarr; ${o.event_to}</td>
      <td class="py-2.5 px-3">${badgeForStatus(o.status)}</td>
      <td class="py-2.5 px-3">
        ${o.status === 'pending' ? `
          <div class="flex gap-2">
            <button data-id="${o.id}" data-decision="approve" class="od-decision px-2.5 py-1 rounded bg-emerald-600/20 text-emerald-300 text-xs hover:bg-emerald-600/30">Approve</button>
            <button data-id="${o.id}" data-decision="reject" class="od-decision px-2.5 py-1 rounded bg-rose-600/20 text-rose-300 text-xs hover:bg-rose-600/30">Reject</button>
          </div>` : (o.certificate_path ? `<a href="${o.certificate_path}" target="_blank" class="text-xs text-cyan-400 hover:underline">Certificate</a>` : '-')}
      </td>
    </tr>`);
  document.getElementById('content').innerHTML = card(table(['Student', 'Event', 'Dates', 'Status', 'Action'], rows));

  document.querySelectorAll('.od-decision').forEach((btn) => {
    btn.addEventListener('click', async () => {
      try {
        await api.post(`/api/od/${btn.dataset.id}/decision`, { decision: btn.dataset.decision });
        toast(`OD request ${btn.dataset.decision}d`);
        renderOdQueue();
      } catch (err) { toast(err.message, true); }
    });
  });
}

// ---------- Faculty Advisor: Leave Queue ----------
async function renderLeaveFaQueue() {
  const { items } = await api.get('/api/leave/advisor-queue');
  const rows = items.map((l) => `
    <tr>
      <td class="py-2.5 px-3">${l.student_name} <span class="text-slate-500 text-xs">${l.register_no || ''}</span></td>
      <td class="py-2.5 px-3 text-slate-400">${l.from_date} &rarr; ${l.to_date}</td>
      <td class="py-2.5 px-3">${l.reason}</td>
      <td class="py-2.5 px-3">${badgeForStatus(l.fa_status)}</td>
      <td class="py-2.5 px-3">
        ${l.fa_status === 'pending' ? `
          <div class="flex gap-2">
            <button data-id="${l.id}" data-decision="approve" class="leave-decision px-2.5 py-1 rounded bg-emerald-600/20 text-emerald-300 text-xs hover:bg-emerald-600/30">Approve</button>
            <button data-id="${l.id}" data-decision="reject" class="leave-decision px-2.5 py-1 rounded bg-rose-600/20 text-rose-300 text-xs hover:bg-rose-600/30">Reject</button>
          </div>` : '-'}
      </td>
    </tr>`);
  document.getElementById('content').innerHTML = card(table(['Student', 'Dates', 'Reason', 'Status', 'Action'], rows));

  document.querySelectorAll('.leave-decision').forEach((btn) => {
    btn.addEventListener('click', async () => {
      try {
        await api.post(`/api/leave/${btn.dataset.id}/advisor-decision`, { decision: btn.dataset.decision });
        toast(`Leave request ${btn.dataset.decision}d`);
        renderLeaveFaQueue();
      } catch (err) { toast(err.message, true); }
    });
  });
}

// ---------- Class Coordinator: Leave Records ----------
async function renderLeaveCcQueue() {
  const { items } = await api.get('/api/leave/coordinator-queue');
  const rows = items.map((l) => `
    <tr>
      <td class="py-2.5 px-3">${l.student_name} <span class="text-slate-500 text-xs">${l.register_no || ''}</span></td>
      <td class="py-2.5 px-3 text-slate-400">${l.from_date} &rarr; ${l.to_date}</td>
      <td class="py-2.5 px-3">${l.reason}</td>
      <td class="py-2.5 px-3">Advisor: ${badgeForStatus(l.fa_status)}</td>
      <td class="py-2.5 px-3">
        ${l.cc_status === 'pending'
          ? `<button data-id="${l.id}" class="ack-btn px-2.5 py-1 rounded bg-cyan-600/20 text-cyan-300 text-xs hover:bg-cyan-600/30">Acknowledge</button>`
          : badgeForStatus(l.cc_status)}
      </td>
    </tr>`);
  document.getElementById('content').innerHTML = card(table(['Student', 'Dates', 'Reason', 'Advisor Status', 'Records'], rows));

  document.querySelectorAll('.ack-btn').forEach((btn) => {
    btn.addEventListener('click', async () => {
      try {
        await api.post(`/api/leave/${btn.dataset.id}/coordinator-ack`, {});
        toast('Acknowledged for records');
        renderLeaveCcQueue();
      } catch (err) { toast(err.message, true); }
    });
  });
}

// ---------- Student allocation mapping (FA & CC share one implementation) ----------
function filterSelect(id, label, values) {
  return `
    <div>
      <label class="block text-sm text-slate-300 mb-1.5">${label}</label>
      <select id="${id}" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/60 focus:border-cyan-500">
        <option value="">All</option>
        ${values.map((v) => `<option value="${v}">${v}</option>`).join('')}
      </select>`
    + `</div>`;
}

async function renderMapping(config) {
  document.getElementById('content').innerHTML = card(`
    <p class="text-sm text-slate-400 mb-4">${config.blurb}</p>
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
      ${filterSelect('map-dept', 'Department', DEPARTMENTS)}
      ${filterSelect('map-year', 'Year', YEARS)}
      ${filterSelect('map-section', 'Section', SECTIONS)}
      <button id="map-load" class="px-5 py-2.5 rounded-lg border border-slate-700 text-slate-200 font-semibold text-sm hover:bg-slate-900 transition">Load Students</button>
    </div>
    <div id="map-result" class="mt-6"><p class="text-slate-500 text-sm">Choose filters and load students.</p></div>
  `);

  const resultEl = document.getElementById('map-result');

  async function load() {
    const params = new URLSearchParams();
    if (val('map-dept')) params.set('department', val('map-dept'));
    if (val('map-year')) params.set('year', val('map-year'));
    if (val('map-section')) params.set('section', val('map-section'));
    resultEl.innerHTML = `<p class="text-slate-500 text-sm">Loading...</p>`;
    try {
      const { students } = await api.get(`/api/mapping/students?${params.toString()}`);
      if (!students.length) {
        resultEl.innerHTML = `<p class="text-slate-500 text-sm py-6 text-center">No students match these filters.</p>`;
        return;
      }
      const rows = students.map((s) => {
        const mineAlready = s[config.ownerField] === CURRENT_USER.id;
        const otherOwner = s[config.ownerField] && !mineAlready;
        return `
          <tr>
            <td class="py-2.5 px-3">
              <input type="checkbox" class="map-check w-4 h-4 accent-cyan-500" data-id="${s.id}" data-was="${mineAlready ? 1 : 0}" ${mineAlready ? 'checked' : ''} />
            </td>
            <td class="py-2.5 px-3 text-slate-400">${s.register_no || '-'}</td>
            <td class="py-2.5 px-3">${s.name}</td>
            <td class="py-2.5 px-3 text-slate-400">${s.department || '-'}</td>
            <td class="py-2.5 px-3 text-slate-400">${s.year || '-'}</td>
            <td class="py-2.5 px-3 text-slate-400">${s.section || '-'}</td>
            <td class="py-2.5 px-3 text-xs">${mineAlready ? '<span class="text-emerald-400">Assigned to you</span>' : (otherOwner ? '<span class="text-amber-400">Assigned elsewhere</span>' : '<span class="text-slate-500">Unassigned</span>')}</td>
          </tr>`;
      }).join('');

      resultEl.innerHTML = `
        <div class="overflow-x-auto">
          <table class="w-full text-sm">
            <thead>
              <tr class="text-left text-slate-400 border-b border-slate-800">
                <th class="py-2.5 px-3 font-medium"><input type="checkbox" id="map-check-all" class="w-4 h-4 accent-cyan-500" /></th>
                <th class="py-2.5 px-3 font-medium">SPR No</th>
                <th class="py-2.5 px-3 font-medium">Name</th>
                <th class="py-2.5 px-3 font-medium">Department</th>
                <th class="py-2.5 px-3 font-medium">Year</th>
                <th class="py-2.5 px-3 font-medium">Section</th>
                <th class="py-2.5 px-3 font-medium">Current</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/70">${rows}</tbody>
          </table>
        </div>
        <div class="flex justify-end mt-5">
          <button id="map-save" class="px-5 py-2.5 rounded-lg bg-gradient-to-r from-cyan-500 to-violet-600 text-slate-950 font-semibold text-sm hover:opacity-90 transition">Save Mapping</button>
        </div>`;

      document.getElementById('map-check-all').addEventListener('change', (e) => {
        document.querySelectorAll('.map-check').forEach((c) => { c.checked = e.target.checked; });
      });

      document.getElementById('map-save').addEventListener('click', async () => {
        const assign = [];
        const unassign = [];
        document.querySelectorAll('.map-check').forEach((c) => {
          const id = Number(c.dataset.id);
          const was = c.dataset.was === '1';
          if (c.checked) assign.push(id);
          else if (was) unassign.push(id); // was mine, now unchecked -> release
        });
        if (!assign.length && !unassign.length) return toast('No changes to save', true);
        try {
          const res = await api.post(config.endpoint, { assign, unassign });
          toast(`Mapping saved: ${res.assigned} assigned, ${res.unassigned} released`);
          load();
        } catch (err) { toast(err.message, true); }
      });
    } catch (err) {
      resultEl.innerHTML = `<p class="text-rose-400 text-sm">${err.message}</p>`;
    }
  }

  document.getElementById('map-load').addEventListener('click', load);
  ['map-dept', 'map-year', 'map-section'].forEach((id) => {
    document.getElementById(id).addEventListener('change', load);
  });
}

function renderFaMapping() {
  return renderMapping({
    endpoint: '/api/mapping/faculty-advisor',
    ownerField: 'faculty_advisor_id',
    blurb: 'Filter students by department, year, and section, then check the students you want to allocate to yourself as Faculty Advisor.'
  });
}

function renderCcMapping() {
  return renderMapping({
    endpoint: '/api/mapping/class-coordinator',
    ownerField: 'class_coordinator_id',
    blurb: 'Filter students by department, year, and section, then check the students you want to allocate to yourself as Class Coordinator.'
  });
}

// ---------- HOD Mapping: allocate students to any FA or CC ----------
async function renderHodMapping() {
  document.getElementById('content').innerHTML = card(`
    <p class="text-sm text-slate-400 mb-4">Choose an owner (Faculty Advisor or Class Coordinator), filter students by department/year/section, then check the students to allocate to that owner.</p>
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
      <div>
        <label class="block text-sm text-slate-300 mb-1.5">Allocate To</label>
        <select id="hod-owner-type" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-sm">
          <option value="faculty_advisor">Faculty Advisor</option>
          <option value="class_coordinator">Class Coordinator</option>
        </select>
      </div>
      <div>
        <label class="block text-sm text-slate-300 mb-1.5">Owner</label>
        <select id="hod-owner" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-sm"><option value="">Select...</option></select>
      </div>
      ${filterSelect('map-dept', 'Department', DEPARTMENTS)}
      ${filterSelect('map-year', 'Year', YEARS)}
    </div>
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end mt-4">
      ${filterSelect('map-section', 'Section', SECTIONS)}
      <button id="map-load" class="px-5 py-2.5 rounded-lg border border-slate-700 text-slate-200 font-semibold text-sm hover:bg-slate-900 transition">Load Students</button>
    </div>
    <div id="map-result" class="mt-6"><p class="text-slate-500 text-sm">Pick an owner and filters, then load.</p></div>
  `);

  const ownerTypeSel = document.getElementById('hod-owner-type');
  const ownerSel = document.getElementById('hod-owner');
  const resultEl = document.getElementById('map-result');

  async function loadOwners() {
    try {
      const { staff } = await api.get(`/api/mapping/staff?role=${ownerTypeSel.value}`);
      ownerSel.innerHTML = `<option value="">Select...</option>` + staff.map((s) =>
        `<option value="${s.id}">${s.name}${s.department ? ' (' + s.department + ')' : ''}</option>`).join('');
    } catch (err) { toast(err.message, true); }
  }
  ownerTypeSel.addEventListener('change', loadOwners);
  loadOwners();

  async function load() {
    const params = new URLSearchParams();
    if (val('map-dept')) params.set('department', val('map-dept'));
    if (val('map-year')) params.set('year', val('map-year'));
    if (val('map-section')) params.set('section', val('map-section'));
    resultEl.innerHTML = `<p class="text-slate-500 text-sm">Loading...</p>`;
    try {
      const { students } = await api.get(`/api/mapping/students?${params.toString()}`);
      if (!students.length) {
        resultEl.innerHTML = `<p class="text-slate-500 text-sm py-6 text-center">No students match these filters.</p>`;
        return;
      }
      const ownerId = Number(ownerSel.value) || 0;
      const ownerField = ownerTypeSel.value === 'faculty_advisor' ? 'faculty_advisor_id' : 'class_coordinator_id';
      const rows = students.map((s) => {
        const mineAlready = ownerId && s[ownerField] === ownerId;
        const otherOwner = s[ownerField] && !mineAlready;
        return `
          <tr>
            <td class="py-2.5 px-3"><input type="checkbox" class="map-check w-4 h-4 accent-cyan-500" data-id="${s.id}" data-was="${mineAlready ? 1 : 0}" ${mineAlready ? 'checked' : ''} /></td>
            <td class="py-2.5 px-3 text-slate-400">${s.register_no || '-'}</td>
            <td class="py-2.5 px-3">${s.name}</td>
            <td class="py-2.5 px-3 text-slate-400">${s.department || '-'}</td>
            <td class="py-2.5 px-3 text-slate-400">${s.year || '-'}</td>
            <td class="py-2.5 px-3 text-slate-400">${s.section || '-'}</td>
            <td class="py-2.5 px-3 text-xs">${mineAlready ? '<span class="text-emerald-400">Assigned to owner</span>' : (otherOwner ? '<span class="text-amber-400">Assigned elsewhere</span>' : '<span class="text-slate-500">Unassigned</span>')}</td>
          </tr>`;
      }).join('');
      resultEl.innerHTML = `
        <div class="overflow-x-auto">
          <table class="w-full text-sm">
            <thead><tr class="text-left text-slate-400 border-b border-slate-800">
              <th class="py-2.5 px-3 font-medium"><input type="checkbox" id="map-check-all" class="w-4 h-4 accent-cyan-500" /></th>
              <th class="py-2.5 px-3 font-medium">SPR No</th>
              <th class="py-2.5 px-3 font-medium">Name</th>
              <th class="py-2.5 px-3 font-medium">Department</th>
              <th class="py-2.5 px-3 font-medium">Year</th>
              <th class="py-2.5 px-3 font-medium">Section</th>
              <th class="py-2.5 px-3 font-medium">Current</th>
            </tr></thead>
            <tbody class="divide-y divide-slate-800/70">${rows}</tbody>
          </table>
        </div>
        <div class="flex justify-end mt-5">
          <button id="map-save" class="px-5 py-2.5 rounded-lg bg-gradient-to-r from-cyan-500 to-violet-600 text-slate-950 font-semibold text-sm hover:opacity-90 transition">Save Mapping</button>
        </div>`;
      document.getElementById('map-check-all').addEventListener('change', (e) => {
        document.querySelectorAll('.map-check').forEach((c) => { c.checked = e.target.checked; });
      });
      document.getElementById('map-save').addEventListener('click', async () => {
        if (!ownerId) return toast('Pick an owner first', true);
        const assign = [], unassign = [];
        document.querySelectorAll('.map-check').forEach((c) => {
          const id = Number(c.dataset.id);
          const was = c.dataset.was === '1';
          if (c.checked) assign.push(id);
          else if (was) unassign.push(id);
        });
        if (!assign.length && !unassign.length) return toast('No changes to save', true);
        const endpoint = ownerTypeSel.value === 'faculty_advisor'
          ? '/api/mapping/hod/faculty-advisor'
          : '/api/mapping/hod/class-coordinator';
        try {
          const res = await api.post(endpoint, { owner_id: ownerId, assign, unassign });
          toast(`Mapping saved: ${res.assigned} assigned, ${res.unassigned} released`);
          load();
        } catch (err) { toast(err.message, true); }
      });
    } catch (err) {
      resultEl.innerHTML = `<p class="text-rose-400 text-sm">${err.message}</p>`;
    }
  }

  document.getElementById('map-load').addEventListener('click', load);
  ownerSel.addEventListener('change', load);
}

// ---------- Reports (Leave + OD), grouped classwise / advisor-wise / department-wise ----------
async function renderReports() {
  document.getElementById('content').innerHTML = card(`
    <div class="grid grid-cols-1 md:grid-cols-6 gap-4 items-end">
      <div>
        <label class="block text-sm text-slate-300 mb-1.5">Report</label>
        <select id="rep-kind" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-sm">
          <option value="leave">Leave Report</option>
          <option value="od">OD Report</option>
        </select>
      </div>
      <div>
        <label class="block text-sm text-slate-300 mb-1.5">Group By</label>
        <select id="rep-group" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-sm">
          <option value="class">Class (Dept + Year + Section)</option>
          <option value="advisor">Faculty Advisor</option>
          <option value="department">Department</option>
        </select>
      </div>
      ${filterSelect('rep-dept', 'Department', DEPARTMENTS)}
      ${filterSelect('rep-year', 'Year', YEARS)}
      ${filterSelect('rep-section', 'Section', SECTIONS)}
      <div>
        <label class="block text-sm text-slate-300 mb-1.5">From</label>
        <input id="rep-from" type="date" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-sm" />
      </div>
      <div>
        <label class="block text-sm text-slate-300 mb-1.5">To</label>
        <input id="rep-to" type="date" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-sm" />
      </div>
      <div class="md:col-span-3 flex gap-3">
        <button id="rep-run" class="px-5 py-2.5 rounded-lg bg-gradient-to-r from-cyan-500 to-violet-600 text-slate-950 font-semibold text-sm hover:opacity-90 transition">Generate</button>
        <button id="rep-print" class="px-5 py-2.5 rounded-lg border border-slate-700 text-slate-200 font-semibold text-sm hover:bg-slate-900 transition">Print</button>
        <button id="rep-csv" class="px-5 py-2.5 rounded-lg border border-slate-700 text-slate-200 font-semibold text-sm hover:bg-slate-900 transition">Download CSV</button>
      </div>
    </div>
    <div id="rep-out" class="mt-6"><p class="text-slate-500 text-sm">Choose filters and click Generate.</p></div>
  `);

  let lastRows = [];
  let lastKind = 'leave';
  let lastGroup = 'class';

  const LEAVE_COLS = [
    { key: 'from_date', label: 'Date' },
    { key: 'student_name', label: 'Student Name' },
    { key: 'register_no', label: 'SPR No' },
    { key: 'year', label: 'Year' },
    { key: 'department', label: 'Department' },
    { key: 'section', label: 'Section' },
    { key: 'reason', label: 'Reason' }
  ];
  const OD_COLS = [
    { key: 'event_date', label: 'Date' },
    { key: 'student_name', label: 'Student Name' },
    { key: 'register_no', label: 'SPR No' },
    { key: 'year', label: 'Year' },
    { key: 'department', label: 'Department' },
    { key: 'section', label: 'Section' },
    { key: 'event_name', label: 'Event Name' },
    { key: 'detail', label: 'Detail' }
  ];

  function groupKey(row, groupBy) {
    if (groupBy === 'advisor')    return row.faculty_advisor_name || 'Unassigned';
    if (groupBy === 'department') return row.department || 'Unknown';
    // class = dept + year + section
    return `${row.department || 'Unknown'} · ${row.year || '?'} · ${row.section || '?'}`;
  }

  function render(rows, kind, group) {
    lastRows = rows; lastKind = kind; lastGroup = group;
    const cols = kind === 'leave' ? LEAVE_COLS : OD_COLS;
    const out = document.getElementById('rep-out');
    if (!rows.length) { out.innerHTML = `<p class="text-slate-500 text-sm py-6 text-center">No records match these filters.</p>`; return; }

    const groups = {};
    rows.forEach((r) => {
      const k = groupKey(r, group);
      (groups[k] = groups[k] || []).push(r);
    });

    const groupLabel = group === 'advisor' ? 'Faculty Advisor' : (group === 'department' ? 'Department' : 'Class');
    const title = kind === 'leave' ? 'Leave Report' : 'OD Report';

    out.innerHTML = `
      <div id="report-printable" class="space-y-6">
        <div class="print-header">
          <h2 class="text-xl font-bold text-slate-100">${title}</h2>
          <p class="text-slate-400 text-sm">Grouped by ${groupLabel} · ${rows.length} record${rows.length === 1 ? '' : 's'}</p>
        </div>
        ${Object.keys(groups).sort().map((k) => `
          <div class="border border-slate-800 rounded-xl overflow-hidden">
            <div class="bg-slate-900/70 px-4 py-2.5 text-sm font-semibold text-slate-200 border-b border-slate-800">${escapeAttr(k)} <span class="text-slate-500 font-normal">(${groups[k].length})</span></div>
            <div class="overflow-x-auto">
              <table class="w-full text-sm">
                <thead><tr class="text-left text-slate-400 border-b border-slate-800/70">
                  ${cols.map((c) => `<th class="py-2 px-3 font-medium">${c.label}</th>`).join('')}
                </tr></thead>
                <tbody class="divide-y divide-slate-800/70">
                  ${groups[k].map((r) => `<tr>${cols.map((c) => `<td class="py-2 px-3 text-slate-300">${escapeAttr(r[c.key] || '-')}</td>`).join('')}</tr>`).join('')}
                </tbody>
              </table>
            </div>
          </div>`).join('')}
      </div>`;
  }

  function escapeAttr(v) {
    const div = document.createElement('div');
    div.textContent = v == null ? '' : String(v);
    return div.innerHTML;
  }

  document.getElementById('rep-run').addEventListener('click', async () => {
    const kind = document.getElementById('rep-kind').value;
    const group = document.getElementById('rep-group').value;
    const params = new URLSearchParams();
    ['rep-dept', 'rep-year', 'rep-section', 'rep-from', 'rep-to'].forEach((id) => {
      const v = val(id);
      if (!v) return;
      const key = { 'rep-dept': 'department', 'rep-year': 'year', 'rep-section': 'section', 'rep-from': 'from_date', 'rep-to': 'to_date' }[id];
      params.set(key, v);
    });
    try {
      const { rows } = await api.get(`/api/reports/${kind}?${params.toString()}`);
      render(rows, kind, group);
    } catch (err) { toast(err.message, true); }
  });

  document.getElementById('rep-print').addEventListener('click', () => {
    if (!lastRows.length) return toast('Generate a report first', true);
    window.print();
  });

  document.getElementById('rep-csv').addEventListener('click', () => {
    if (!lastRows.length) return toast('Generate a report first', true);
    const cols = lastKind === 'leave' ? LEAVE_COLS : OD_COLS;
    const escapeCsv = (v) => {
      const s = v == null ? '' : String(v);
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const groups = {};
    lastRows.forEach((r) => { const k = groupKey(r, lastGroup); (groups[k] = groups[k] || []).push(r); });
    const lines = [];
    Object.keys(groups).sort().forEach((k) => {
      lines.push(escapeCsv(k));
      lines.push(cols.map((c) => c.label).join(','));
      groups[k].forEach((r) => lines.push(cols.map((c) => escapeCsv(r[c.key])).join(',')));
      lines.push('');
    });
    const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${lastKind}-report-${lastGroup}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  });
}

boot();
