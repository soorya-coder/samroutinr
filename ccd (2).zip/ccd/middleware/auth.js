const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const COOKIE_NAME = 'cma_token';

function parseRoles(user) {
  const csv = user.roles && String(user.roles).trim();
  if (csv) return csv.split(',').map((r) => r.trim()).filter(Boolean);
  return user.role ? [user.role] : [];
}

function issueToken(res, user) {
  const token = jwt.sign(
    { id: user.id, role: user.role, roles: parseRoles(user), name: user.name, email: user.email },
    JWT_SECRET,
    { expiresIn: '8h' }
  );
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: false, // set true when served over HTTPS
    maxAge: 8 * 60 * 60 * 1000
  });
}

function clearToken(res) {
  res.clearCookie(COOKIE_NAME);
}

function requireAuth(req, res, next) {
  const token = req.cookies && req.cookies[COOKIE_NAME];
  if (!token) return res.status(401).json({ error: 'Not authenticated' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Session expired, please log in again' });
  }
}

function requireRole(...allowed) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Not authenticated' });
    // A user may hold multiple roles (comma-separated). Grant access if any role matches.
    const myRoles = Array.isArray(req.user.roles) && req.user.roles.length ? req.user.roles : [req.user.role];
    if (!myRoles.some((r) => allowed.includes(r))) {
      return res.status(403).json({ error: 'Forbidden: insufficient permissions' });
    }
    next();
  };
}

module.exports = { issueToken, clearToken, requireAuth, requireRole, parseRoles, JWT_SECRET, COOKIE_NAME };
