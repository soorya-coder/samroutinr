const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { requireAuth, requireRole } = require('../middleware/auth');
const {
  createOd, listMyOds, listForAdvisor, decideOd,
  uploadProof, uploadCertificate,
  listForHod, listForClassCoordinator
} = require('../controllers/od.controller');

const router = express.Router();

const uploadDir = path.join(__dirname, '..', 'uploads', 'certificates');
fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    // fieldname included so multiple uploads on one request stay distinct on disk
    const scope = req.params.id ? `${req.params.id}` : 'new';
    cb(null, `od-${scope}-${req.user.id}-${file.fieldname}-${Date.now()}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = /\.(pdf|png|jpg|jpeg)$/i.test(file.originalname);
    if (!ok) return cb(new Error('Only PDF, PNG, or JPG files are allowed'));
    cb(null, true);
  }
});

// Multer .fields() for multi-file requests (create OD with flyer; upload proof with cert+photo+prize cert)
const createFields = upload.fields([{ name: 'event_flyer', maxCount: 1 }]);
const proofFields = upload.fields([
  { name: 'certificate', maxCount: 1 },
  { name: 'photo', maxCount: 1 },
  { name: 'prize_certificate', maxCount: 1 }
]);

router.use(requireAuth);

router.post('/', requireRole('student'), createFields, createOd);
router.get('/mine', requireRole('student'), listMyOds);
router.post('/:id/certificate', requireRole('student'), upload.single('certificate'), uploadCertificate);
router.post('/:id/proof', requireRole('student'), proofFields, uploadProof);

router.get('/advisor-queue', requireRole('faculty_advisor'), listForAdvisor);
router.post('/:id/decision', requireRole('faculty_advisor'), decideOd);

router.get('/hod-queue', requireRole('hod'), listForHod);
router.get('/coordinator-queue', requireRole('class_coordinator'), listForClassCoordinator);

module.exports = router;
