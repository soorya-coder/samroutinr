const express = require('express');
const multer = require('multer');
const { requireAuth, requireRole } = require('../middleware/auth');
const { createSingleUser, bulkUploadUsers, listUsers } = require('../controllers/admin.controller');

const router = express.Router();

// Keep the file in memory; xlsx parses straight from the buffer, no temp files to clean up.
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const okExt = /\.(xlsx|xls|csv)$/i.test(file.originalname);
    if (!okExt) return cb(new Error('Only .xlsx, .xls, or .csv files are allowed'));
    cb(null, true);
  }
});

router.use(requireAuth, requireRole('admin'));

router.get('/users', listUsers);
router.post('/users', createSingleUser);
router.post('/users/bulk', upload.single('file'), bulkUploadUsers);

module.exports = router;
