const express = require('express');
const { requireAuth, requireRole } = require('../middleware/auth');
const {
  listStudents,
  saveFacultyAdvisorMapping,
  saveClassCoordinatorMapping,
  hodSaveFa,
  hodSaveCc,
  listStaff,
  listAssigned
} = require('../controllers/mapping.controller');

const router = express.Router();

router.use(requireAuth);

// FA/CC/HOD/admin all browse the student directory by department/year/section.
router.get('/students', requireRole('faculty_advisor', 'class_coordinator', 'hod', 'admin'), listStudents);
router.get('/staff', requireRole('hod', 'admin'), listStaff);
router.get('/assigned', requireRole('hod', 'admin'), listAssigned);

router.post('/faculty-advisor', requireRole('faculty_advisor'), saveFacultyAdvisorMapping);
router.post('/class-coordinator', requireRole('class_coordinator'), saveClassCoordinatorMapping);
router.post('/hod/faculty-advisor', requireRole('hod', 'admin'), hodSaveFa);
router.post('/hod/class-coordinator', requireRole('hod', 'admin'), hodSaveCc);

module.exports = router;
