const express = require('express');
const { requireAuth, requireRole } = require('../middleware/auth');
const {
  createLeave,
  listMyLeaves,
  listForAdvisor,
  listForClassCoordinator,
  advisorDecision,
  classCoordinatorAcknowledge
} = require('../controllers/leave.controller');

const router = express.Router();

router.use(requireAuth);

router.post('/', requireRole('student'), createLeave);
router.get('/mine', requireRole('student'), listMyLeaves);

router.get('/advisor-queue', requireRole('faculty_advisor'), listForAdvisor);
router.post('/:id/advisor-decision', requireRole('faculty_advisor'), advisorDecision);

router.get('/coordinator-queue', requireRole('class_coordinator'), listForClassCoordinator);
router.post('/:id/coordinator-ack', requireRole('class_coordinator'), classCoordinatorAcknowledge);

module.exports = router;
