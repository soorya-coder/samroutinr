const express = require('express');
const { requireAuth, requireRole } = require('../middleware/auth');
const { getSemester, setSemester, reportAttendance } = require('../controllers/attendance.controller');

const router = express.Router();

router.use(requireAuth);

router.get('/semester', requireRole('admin', 'hod', 'faculty_advisor', 'class_coordinator', 'coordinator'), getSemester);
router.post('/semester', requireRole('admin'), setSemester);
router.get('/report', requireRole('admin', 'hod', 'faculty_advisor', 'class_coordinator', 'coordinator'), reportAttendance);

module.exports = router;
