const express = require('express');
const { requireAuth, requireRole } = require('../middleware/auth');
const { leaveReport, odReport } = require('../controllers/reports.controller');

const router = express.Router();

router.use(requireAuth, requireRole('hod', 'admin', 'faculty_advisor', 'class_coordinator', 'coordinator'));

router.get('/leave', leaveReport);
router.get('/od', odReport);

module.exports = router;
