const express = require('express');
const { requireAuth, requireRole } = require('../middleware/auth');
const { createMessage, listInbox, listSent, markRead } = require('../controllers/message.controller');

const router = express.Router();

router.use(requireAuth);

// Only the Counselling Coordinator originates tasks/messages.
router.post('/', requireRole('coordinator'), createMessage);
router.get('/sent', requireRole('coordinator'), listSent);
router.get('/inbox', listInbox);
router.post('/:id/read', markRead);

module.exports = router;
