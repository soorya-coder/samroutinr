const { db } = require('../db/database');

function getSemester(req, res) {
  const row = db.prepare('SELECT semester_start, semester_end FROM semester_settings WHERE id = 1').get();
  res.json({ semester: row || {} });
}

function setSemester(req, res) {
  const { semester_start, semester_end } = req.body || {};
  if (!semester_start || !semester_end) {
    return res.status(400).json({ error: 'semester_start and semester_end are required' });
  }
  if (semester_start > semester_end) {
    return res.status(400).json({ error: 'semester_start must be on or before semester_end' });
  }
  db.prepare(`
    UPDATE semester_settings SET semester_start = ?, semester_end = ?, updated_at = datetime('now') WHERE id = 1
  `).run(semester_start, semester_end);
  res.json({ ok: true });
}

// Count Mon-Fri days between (inclusive) two ISO date strings.
function weekdaysBetween(startISO, endISO) {
  const start = new Date(startISO + 'T00:00:00');
  const end = new Date(endISO + 'T00:00:00');
  let count = 0;
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    const day = d.getDay();
    if (day !== 0 && day !== 6) count++;
  }
  return count;
}

// Expand a date range into an inclusive list of ISO weekday dates within the semester window.
function weekdayDatesInWindow(fromISO, toISO, semStart, semEnd) {
  const from = fromISO < semStart ? semStart : fromISO;
  const to = toISO > semEnd ? semEnd : toISO;
  const out = [];
  if (from > to) return out;
  for (let d = new Date(from + 'T00:00:00'); d <= new Date(to + 'T00:00:00'); d.setDate(d.getDate() + 1)) {
    const day = d.getDay();
    if (day !== 0 && day !== 6) out.push(d.toISOString().slice(0, 10));
  }
  return out;
}

function reportAttendance(req, res) {
  const sem = db.prepare('SELECT semester_start, semester_end FROM semester_settings WHERE id = 1').get();
  if (!sem || !sem.semester_start || !sem.semester_end) {
    return res.status(400).json({ error: 'Set the semester start / end dates first.' });
  }

  const totalDays = weekdaysBetween(sem.semester_start, sem.semester_end);

  const filters = ["role = 'student'"];
  const params = [];
  if (req.query.department) { filters.push('department = ?'); params.push(req.query.department); }
  if (req.query.year)       { filters.push('year = ?');       params.push(req.query.year); }
  if (req.query.section)    { filters.push('section = ?');    params.push(req.query.section); }

  const students = db.prepare(
    `SELECT id, name, register_no, department, year, section FROM users WHERE ${filters.join(' AND ')}`
  ).all(...params);

  const leaveStmt = db.prepare(
    `SELECT from_date, to_date FROM leave_requests WHERE student_id = ? AND fa_status = 'approved'`
  );
  const odStmt = db.prepare(
    `SELECT event_from, event_to FROM od_requests WHERE student_id = ? AND status IN ('pending_proof','completed')`
  );

  const rows = students.map((s) => {
    const absent = new Set();
    for (const lv of leaveStmt.all(s.id)) {
      for (const d of weekdayDatesInWindow(lv.from_date, lv.to_date, sem.semester_start, sem.semester_end)) absent.add(d);
    }
    for (const od of odStmt.all(s.id)) {
      for (const d of weekdayDatesInWindow(od.event_from, od.event_to, sem.semester_start, sem.semester_end)) absent.add(d);
    }
    const absentDays = absent.size;
    const percentage = totalDays > 0 ? Math.round(((totalDays - absentDays) / totalDays) * 1000) / 10 : 0;
    return { ...s, total_days: totalDays, absent_days: absentDays, present_days: totalDays - absentDays, percentage };
  });

  // Sort by lowest attendance first (as required).
  rows.sort((a, b) => a.percentage - b.percentage);
  res.json({ semester: sem, total_days: totalDays, rows });
}

module.exports = { getSemester, setSemester, reportAttendance };
