const { db } = require('../db/database');

// List students matching the given department/year/section filters, annotated
// with their current advisor / coordinator so the UI can pre-check boxes.
function listStudents(req, res) {
  const { department, year, section } = req.query;

  const clauses = ["role = 'student'"];
  const params = [];
  if (department) { clauses.push('department = ?'); params.push(department); }
  if (year)       { clauses.push('year = ?');       params.push(year); }
  if (section)    { clauses.push('section = ?');    params.push(section); }

  const students = db.prepare(`
    SELECT u.id, u.name, u.email, u.register_no, u.department, u.year, u.section,
           fa.faculty_advisor_id, cc.class_coordinator_id
    FROM users u
    LEFT JOIN faculty_advisor_mappings fa ON fa.student_id = u.id
    LEFT JOIN class_coordinator_mappings cc ON cc.student_id = u.id
    WHERE ${clauses.join(' AND ')}
    ORDER BY u.register_no, u.name
  `).all(...params);

  res.json({ students });
}

// Generic save used by both mapping types. `config` picks the table, the FK
// column, and the mirrored users column that the OD/leave workflow relies on.
function saveMapping(config) {
  return (req, res) => {
    const ownerId = req.user.id;
    const assign = Array.isArray(req.body.assign) ? req.body.assign.map(Number).filter(Boolean) : [];
    const unassign = Array.isArray(req.body.unassign) ? req.body.unassign.map(Number).filter(Boolean) : [];

    const upsert = db.prepare(`
      INSERT INTO ${config.table} (${config.fk}, student_id) VALUES (?, ?)
      ON CONFLICT(student_id) DO UPDATE SET ${config.fk} = excluded.${config.fk}, created_at = datetime('now')
    `);
    const setUserCol = db.prepare(
      `UPDATE users SET ${config.userCol} = ? WHERE id = ? AND role = 'student'`
    );
    const removeMine = db.prepare(
      `DELETE FROM ${config.table} WHERE student_id = ? AND ${config.fk} = ?`
    );
    const clearUserCol = db.prepare(
      `UPDATE users SET ${config.userCol} = NULL WHERE id = ? AND ${config.userCol} = ?`
    );

    db.exec('BEGIN');
    try {
      for (const studentId of assign) {
        upsert.run(ownerId, studentId);
        setUserCol.run(ownerId, studentId);
      }
      for (const studentId of unassign) {
        removeMine.run(studentId, ownerId);
        clearUserCol.run(studentId, ownerId);
      }
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      return res.status(400).json({ error: err.message });
    }

    res.json({ ok: true, assigned: assign.length, unassigned: unassign.length });
  };
}

const saveFacultyAdvisorMapping = saveMapping({
  table: 'faculty_advisor_mappings',
  fk: 'faculty_advisor_id',
  userCol: 'faculty_advisor_id'
});

const saveClassCoordinatorMapping = saveMapping({
  table: 'class_coordinator_mappings',
  fk: 'class_coordinator_id',
  userCol: 'class_coordinator_id'
});

// --- HOD variants: an HOD picks the target owner (any FA / CC) explicitly ---
function saveHodMapping(config) {
  return (req, res) => {
    const ownerId = Number(req.body.owner_id);
    if (!ownerId) return res.status(400).json({ error: 'owner_id is required' });

    const owner = db.prepare('SELECT id, role FROM users WHERE id = ?').get(ownerId);
    if (!owner || owner.role !== config.expectedRole) {
      return res.status(400).json({ error: `Selected owner is not a ${config.expectedRole.replace('_', ' ')}` });
    }

    const assign = Array.isArray(req.body.assign) ? req.body.assign.map(Number).filter(Boolean) : [];
    const unassign = Array.isArray(req.body.unassign) ? req.body.unassign.map(Number).filter(Boolean) : [];

    const upsert = db.prepare(`
      INSERT INTO ${config.table} (${config.fk}, student_id) VALUES (?, ?)
      ON CONFLICT(student_id) DO UPDATE SET ${config.fk} = excluded.${config.fk}, created_at = datetime('now')
    `);
    const setUserCol = db.prepare(
      `UPDATE users SET ${config.userCol} = ? WHERE id = ? AND role = 'student'`
    );
    const removeFor = db.prepare(
      `DELETE FROM ${config.table} WHERE student_id = ? AND ${config.fk} = ?`
    );
    const clearUserCol = db.prepare(
      `UPDATE users SET ${config.userCol} = NULL WHERE id = ? AND ${config.userCol} = ?`
    );

    db.exec('BEGIN');
    try {
      for (const studentId of assign) {
        upsert.run(ownerId, studentId);
        setUserCol.run(ownerId, studentId);
      }
      for (const studentId of unassign) {
        removeFor.run(studentId, ownerId);
        clearUserCol.run(studentId, ownerId);
      }
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      return res.status(400).json({ error: err.message });
    }

    res.json({ ok: true, assigned: assign.length, unassigned: unassign.length });
  };
}

const hodSaveFa = saveHodMapping({
  table: 'faculty_advisor_mappings', fk: 'faculty_advisor_id',
  userCol: 'faculty_advisor_id', expectedRole: 'faculty_advisor'
});

const hodSaveCc = saveHodMapping({
  table: 'class_coordinator_mappings', fk: 'class_coordinator_id',
  userCol: 'class_coordinator_id', expectedRole: 'class_coordinator'
});

// Lists all users of a given role for HOD's owner dropdown, optionally filtered by dept.
// Matches both the primary `role` column and the multi-role CSV `roles` list.
function listStaff(req, res) {
  const role = req.query.role;
  const dept = req.query.department;
  if (!['faculty_advisor', 'class_coordinator'].includes(role)) {
    return res.status(400).json({ error: 'role must be faculty_advisor or class_coordinator' });
  }
  const clauses = ["(role = ? OR roles LIKE ?)"];
  const params = [role, `%${role}%`];
  if (dept) { clauses.push('department = ?'); params.push(dept); }
  const staff = db.prepare(
    `SELECT id, name, email, department, role, roles FROM users WHERE ${clauses.join(' AND ')} ORDER BY name`
  ).all(...params);
  res.json({ staff });
}

// Students currently allocated to a given owner (FA or CC). Used by the HOD's Refresh button.
function listAssigned(req, res) {
  const ownerId = Number(req.query.owner_id);
  const role = req.query.role;
  if (!ownerId || !['faculty_advisor', 'class_coordinator'].includes(role)) {
    return res.status(400).json({ error: 'owner_id and valid role are required' });
  }
  const table = role === 'faculty_advisor' ? 'faculty_advisor_mappings' : 'class_coordinator_mappings';
  const fk = role === 'faculty_advisor' ? 'faculty_advisor_id' : 'class_coordinator_id';
  const students = db.prepare(`
    SELECT u.id, u.name, u.email, u.register_no, u.department, u.year, u.section
    FROM ${table} m JOIN users u ON u.id = m.student_id
    WHERE m.${fk} = ?
    ORDER BY u.department, u.year, u.section, u.register_no
  `).all(ownerId);
  res.json({ students });
}

module.exports = {
  listStudents,
  saveFacultyAdvisorMapping,
  saveClassCoordinatorMapping,
  hodSaveFa,
  hodSaveCc,
  listStaff,
  listAssigned
};
