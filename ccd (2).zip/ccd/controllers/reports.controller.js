const { db } = require('../db/database');

// Common filter builder: department / year / section / faculty_advisor_id / from-to date.
// `dateCol` is 'l.from_date' for leave or 'o.event_from' for OD.
function buildFilters(query, dateCol, roleScope) {
  const clauses = [];
  const params = [];
  if (query.department)        { clauses.push('s.department = ?');       params.push(query.department); }
  if (query.year)              { clauses.push('s.year = ?');             params.push(query.year); }
  if (query.section)           { clauses.push('s.section = ?');          params.push(query.section); }
  if (query.faculty_advisor_id){ clauses.push('s.faculty_advisor_id = ?'); params.push(Number(query.faculty_advisor_id)); }
  if (query.from_date)         { clauses.push(`${dateCol} >= ?`);        params.push(query.from_date); }
  if (query.to_date)           { clauses.push(`${dateCol} <= ?`);        params.push(query.to_date); }

  // Role-scoped visibility (admin/hod see all → roleScope null; others see a slice).
  if (roleScope) {
    clauses.push(roleScope.clause);
    if (roleScope.value !== null && roleScope.value !== undefined) params.push(roleScope.value);
  }
  return { where: clauses.length ? 'WHERE ' + clauses.join(' AND ') : '', params };
}

function scopeFor(user) {
  const roles = Array.isArray(user.roles) && user.roles.length ? user.roles : [user.role];
  // Broadest role wins (admin > hod > coordinator > fa/cc) so multi-role users see the widest slice they qualify for.
  if (roles.includes('admin') || roles.includes('hod')) return null;
  if (roles.includes('coordinator')) {
    // Counselling Coordinator sees their whole department.
    const { db } = require('../db/database');
    const me = db.prepare('SELECT department FROM users WHERE id = ?').get(user.id);
    return me && me.department
      ? { clause: 's.department = ?', value: me.department }
      : { clause: '0 = 1', value: null };
  }
  if (roles.includes('faculty_advisor')) return { clause: 's.faculty_advisor_id = ?', value: user.id };
  if (roles.includes('class_coordinator')) return { clause: 's.class_coordinator_id = ?', value: user.id };
  return { clause: '0 = 1', value: null };
}

function leaveReport(req, res) {
  const scope = scopeFor(req.user);
  const { where, params } = buildFilters(req.query, 'l.from_date', scope);
  const rows = db.prepare(`
    SELECT l.id,
           l.from_date, l.to_date, l.reason, l.leave_type,
           l.fa_status, l.cc_status,
           s.id AS student_id, s.name AS student_name, s.register_no,
           s.year, s.department, s.section,
           fa.name AS faculty_advisor_name
    FROM leave_requests l
    JOIN users s ON s.id = l.student_id
    LEFT JOIN users fa ON fa.id = s.faculty_advisor_id
    ${where}
    ORDER BY s.department, s.year, s.section, l.from_date DESC
  `).all(...params);
  res.json({ rows });
}

function odReport(req, res) {
  const scope = scopeFor(req.user);
  const { where, params } = buildFilters(req.query, 'o.event_from', scope);
  const rows = db.prepare(`
    SELECT o.id,
           o.event_from AS event_date, o.event_to, o.event_name,
           o.organizing_institution, o.reason AS detail, o.status,
           s.id AS student_id, s.name AS student_name, s.register_no,
           s.year, s.department, s.section,
           fa.name AS faculty_advisor_name
    FROM od_requests o
    JOIN users s ON s.id = o.student_id
    LEFT JOIN users fa ON fa.id = s.faculty_advisor_id
    ${where}
    ORDER BY s.department, s.year, s.section, o.event_from DESC
  `).all(...params);
  res.json({ rows });
}

module.exports = { leaveReport, odReport };
