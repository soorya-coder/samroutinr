const { db } = require('../db/database');

function createLeave(req, res) {
  const { from_date, to_date, reason, leave_type } = req.body;
  const student = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);

  if (!student.faculty_advisor_id || !student.class_coordinator_id) {
    return res.status(400).json({ error: 'Faculty Advisor and/or Class Coordinator not assigned to your account. Contact the Admin.' });
  }
  if (!from_date || !to_date || !reason) {
    return res.status(400).json({ error: 'from_date, to_date, and reason are required' });
  }

  const result = db.prepare(`
    INSERT INTO leave_requests (student_id, faculty_advisor_id, class_coordinator_id, from_date, to_date, reason, leave_type)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(student.id, student.faculty_advisor_id, student.class_coordinator_id, from_date, to_date, reason, leave_type || null);

  res.status(201).json({ ok: true, id: result.lastInsertRowid });
}

function listMyLeaves(req, res) {
  const rows = db.prepare(
    `SELECT * FROM leave_requests WHERE student_id = ? ORDER BY created_at DESC`
  ).all(req.user.id);
  res.json({ items: rows });
}

function listForAdvisor(req, res) {
  const rows = db.prepare(`
    SELECT l.*, u.name AS student_name, u.register_no
    FROM leave_requests l
    JOIN users u ON u.id = l.student_id
    WHERE l.faculty_advisor_id = ?
    ORDER BY l.created_at DESC
  `).all(req.user.id);
  res.json({ items: rows });
}

function listForClassCoordinator(req, res) {
  const rows = db.prepare(`
    SELECT l.*, u.name AS student_name, u.register_no
    FROM leave_requests l
    JOIN users u ON u.id = l.student_id
    WHERE l.class_coordinator_id = ?
    ORDER BY l.created_at DESC
  `).all(req.user.id);
  res.json({ items: rows });
}

function advisorDecision(req, res) {
  const leaveId = Number(req.params.id);
  const { decision, comment } = req.body; // 'approve' | 'reject'
  const leave = db.prepare('SELECT * FROM leave_requests WHERE id = ?').get(leaveId);

  if (!leave) return res.status(404).json({ error: 'Leave request not found' });
  if (leave.faculty_advisor_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
  if (!['approve', 'reject'].includes(decision)) return res.status(400).json({ error: 'decision must be approve or reject' });

  db.prepare(
    `UPDATE leave_requests SET fa_status = ?, fa_comment = ?, updated_at = datetime('now') WHERE id = ?`
  ).run(decision === 'approve' ? 'approved' : 'rejected', comment || null, leaveId);

  res.json({ ok: true });
}

// Class Coordinator has a view/records role, not veto power — they acknowledge for their records.
function classCoordinatorAcknowledge(req, res) {
  const leaveId = Number(req.params.id);
  const { comment } = req.body;
  const leave = db.prepare('SELECT * FROM leave_requests WHERE id = ?').get(leaveId);

  if (!leave) return res.status(404).json({ error: 'Leave request not found' });
  if (leave.class_coordinator_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });

  db.prepare(
    `UPDATE leave_requests SET cc_status = 'acknowledged', cc_comment = ?, updated_at = datetime('now') WHERE id = ?`
  ).run(comment || null, leaveId);

  res.json({ ok: true });
}

module.exports = {
  createLeave,
  listMyLeaves,
  listForAdvisor,
  listForClassCoordinator,
  advisorDecision,
  classCoordinatorAcknowledge
};
