const { db } = require('../db/database');

// Resolve a matching HOD for the student's department (any user with role/roles including 'hod').
function findHodForDept(department) {
  if (!department) return null;
  const row = db.prepare(
    `SELECT id FROM users WHERE department = ? AND (role = 'hod' OR roles LIKE '%hod%') LIMIT 1`
  ).get(department);
  return row ? row.id : null;
}

function truthy(v) { return v === true || v === 1 || v === '1' || v === 'true' || v === 'on'; }

function createOd(req, res) {
  // Multer with .fields() populates req.body (text) and req.files (map).
  const body = req.body || {};
  const files = req.files || {};
  const {
    event_name, event_from, event_to, event_date,
    organizing_institution, city, description, reason
  } = body;

  const student = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  const from = event_from || event_date;
  const to = event_to || event_date;

  if (!student.faculty_advisor_id) {
    return res.status(400).json({ error: 'No Faculty Advisor is assigned to your account. Contact the Admin.' });
  }
  if (!event_name || !from || !to) {
    return res.status(400).json({ error: 'event_name and event date(s) are required' });
  }

  const isOnline = truthy(body.is_online);
  const needOd = truthy(body.need_od);
  // Internal or online events skip the approval workflow — recorded for information only.
  const startStatus = needOd ? 'pending' : 'completed';
  const infoAck = needOd ? 'pending' : 'acknowledged';

  const flyerFile = files.event_flyer && files.event_flyer[0];
  const flyerPath = flyerFile ? `/uploads/certificates/${flyerFile.filename}` : null;

  const hodId = findHodForDept(student.department);
  const ccId = student.class_coordinator_id || null;

  const result = db.prepare(`
    INSERT INTO od_requests (
      student_id, faculty_advisor_id, class_coordinator_id, hod_id,
      event_name, event_from, event_to,
      organizing_institution, city, reason,
      is_online, need_od, event_flyer_path,
      status, hod_status, cc_status
    ) VALUES (?, ?, ?, ?,  ?, ?, ?,  ?, ?, ?,  ?, ?, ?,  ?, ?, ?)
  `).run(
    student.id, student.faculty_advisor_id, ccId, hodId,
    event_name, from, to,
    organizing_institution || null, city || null, description || reason || null,
    isOnline ? 1 : 0, needOd ? 1 : 0, flyerPath,
    startStatus, infoAck, infoAck
  );

  res.status(201).json({ ok: true, id: result.lastInsertRowid, need_od: needOd, status: startStatus });
}

function listMyOds(req, res) {
  const rows = db.prepare(
    `SELECT * FROM od_requests WHERE student_id = ? ORDER BY created_at DESC`
  ).all(req.user.id);
  res.json({ items: rows });
}

function listForAdvisor(req, res) {
  const rows = db.prepare(`
    SELECT o.*, u.name AS student_name, u.register_no
    FROM od_requests o
    JOIN users u ON u.id = o.student_id
    WHERE o.faculty_advisor_id = ?
    ORDER BY o.created_at DESC
  `).all(req.user.id);
  res.json({ items: rows });
}

function decideOd(req, res) {
  const odId = Number(req.params.id);
  const { decision, comment } = req.body;
  const od = db.prepare('SELECT * FROM od_requests WHERE id = ?').get(odId);

  if (!od) return res.status(404).json({ error: 'OD request not found' });
  if (od.faculty_advisor_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
  if (od.status !== 'pending') return res.status(400).json({ error: 'This request has already been decided' });
  if (!['approve', 'reject'].includes(decision)) return res.status(400).json({ error: 'decision must be approve or reject' });

  const newStatus = decision === 'approve' ? 'pending_proof' : 'rejected';
  db.prepare(
    `UPDATE od_requests SET status = ?, advisor_comment = ?, updated_at = datetime('now') WHERE id = ?`
  ).run(newStatus, comment || null, odId);

  res.json({ ok: true, status: newStatus });
}

// --------- Proof upload: certificate + photo + optional prize section ---------
function uploadProof(req, res) {
  const odId = Number(req.params.id);
  const od = db.prepare('SELECT * FROM od_requests WHERE id = ?').get(odId);
  if (!od) return res.status(404).json({ error: 'OD request not found' });
  if (od.student_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
  if (od.status !== 'pending_proof' && od.status !== 'completed') {
    return res.status(400).json({ error: 'Proof can only be uploaded after the OD is approved' });
  }

  const body = req.body || {};
  const files = req.files || {};
  const hasPrize = truthy(body.has_prize);
  const updates = [];
  const params = [];

  const takeFile = (field, col, targetVar) => {
    const f = files[field] && files[field][0];
    if (f) {
      const path = `/uploads/certificates/${f.filename}`;
      updates.push(`${col} = ?`);
      params.push(path);
      return path;
    }
    return null;
  };
  const certPath = takeFile('certificate', 'certificate_path');
  takeFile('photo', 'photo_path');
  takeFile('prize_certificate', 'prize_certificate_path');

  if (certPath) {
    updates.push(`certificate_uploaded_at = datetime('now')`);
    updates.push(`status = 'completed'`);
  }
  updates.push('has_prize = ?'); params.push(hasPrize ? 1 : 0);
  if (hasPrize) {
    updates.push('prize_name = ?');   params.push(body.prize_name || null);
    updates.push('prize_amount = ?'); params.push(body.prize_amount || null);
  } else {
    updates.push('prize_name = NULL, prize_amount = NULL, prize_certificate_path = NULL');
  }
  updates.push(`updated_at = datetime('now')`);

  db.prepare(`UPDATE od_requests SET ${updates.join(', ')} WHERE id = ?`).run(...params, odId);
  const fresh = db.prepare('SELECT * FROM od_requests WHERE id = ?').get(odId);
  res.json({ ok: true, od: fresh });
}

// Backward-compatible single-cert endpoint (still used by main-app dashboard's inline upload).
function uploadCertificate(req, res) {
  const odId = Number(req.params.id);
  const od = db.prepare('SELECT * FROM od_requests WHERE id = ?').get(odId);
  if (!od) return res.status(404).json({ error: 'OD request not found' });
  if (od.student_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
  if (od.status !== 'pending_proof') {
    return res.status(400).json({ error: 'Certificate can only be uploaded for an approved OD awaiting proof' });
  }
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  const relativePath = `/uploads/certificates/${req.file.filename}`;
  db.prepare(`
    UPDATE od_requests
    SET certificate_path = ?, certificate_uploaded_at = datetime('now'), status = 'completed', updated_at = datetime('now')
    WHERE id = ?
  `).run(relativePath, odId);

  res.json({ ok: true, status: 'completed', certificate_path: relativePath });
}

// HOD / CC information queue (for their department / assigned students).
function listForHod(req, res) {
  const rows = db.prepare(`
    SELECT o.*, u.name AS student_name, u.register_no, u.department, u.year, u.section
    FROM od_requests o JOIN users u ON u.id = o.student_id
    WHERE o.hod_id = ? OR u.department = (SELECT department FROM users WHERE id = ?)
    ORDER BY o.created_at DESC
  `).all(req.user.id, req.user.id);
  res.json({ items: rows });
}

function listForClassCoordinator(req, res) {
  const rows = db.prepare(`
    SELECT o.*, u.name AS student_name, u.register_no, u.department, u.year, u.section
    FROM od_requests o JOIN users u ON u.id = o.student_id
    WHERE o.class_coordinator_id = ?
    ORDER BY o.created_at DESC
  `).all(req.user.id);
  res.json({ items: rows });
}

module.exports = { createOd, listMyOds, listForAdvisor, decideOd, uploadProof, uploadCertificate, listForHod, listForClassCoordinator };
