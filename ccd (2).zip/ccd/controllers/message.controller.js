const { db } = require('../db/database');

const VALID_TARGETS = ['hod', 'faculty_advisor', 'student', 'class_coordinator', 'all'];

function createMessage(req, res) {
  const { type, title, body, target_role, department, due_date } = req.body;

  if (!title || !target_role || !VALID_TARGETS.includes(target_role)) {
    return res.status(400).json({ error: 'title and a valid target_role are required' });
  }
  if (!['task', 'message'].includes(type)) {
    return res.status(400).json({ error: 'type must be "task" or "message"' });
  }

  const result = db.prepare(
    `INSERT INTO messages (sender_id, type, title, body, target_role, department, due_date)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(req.user.id, type, title, body || null, target_role, department || null, due_date || null);

  res.status(201).json({ ok: true, id: result.lastInsertRowid });
}

// Returns items addressed to the caller's role (or "all"), newest first,
// annotated with whether the caller has read each one.
function listInbox(req, res) {
  const { role, id } = req.user;

  const rows = db.prepare(`
    SELECT m.*, u.name AS sender_name, u.role AS sender_role,
           EXISTS(SELECT 1 FROM message_reads r WHERE r.message_id = m.id AND r.user_id = ?) AS is_read
    FROM messages m
    JOIN users u ON u.id = m.sender_id
    WHERE m.target_role = ? OR m.target_role = 'all'
    ORDER BY m.created_at DESC
  `).all(id, role);

  res.json({ items: rows.map((r) => ({ ...r, is_read: !!r.is_read })) });
}

function listSent(req, res) {
  const rows = db.prepare(
    `SELECT * FROM messages WHERE sender_id = ? ORDER BY created_at DESC`
  ).all(req.user.id);
  res.json({ items: rows });
}

function markRead(req, res) {
  const messageId = Number(req.params.id);
  const message = db.prepare('SELECT * FROM messages WHERE id = ?').get(messageId);
  if (!message) return res.status(404).json({ error: 'Not found' });
  if (message.target_role !== req.user.role && message.target_role !== 'all') {
    return res.status(403).json({ error: 'Forbidden' });
  }
  db.prepare(
    `INSERT INTO message_reads (message_id, user_id) VALUES (?, ?)
     ON CONFLICT(message_id, user_id) DO NOTHING`
  ).run(messageId, req.user.id);
  res.json({ ok: true });
}

module.exports = { createMessage, listInbox, listSent, markRead };
