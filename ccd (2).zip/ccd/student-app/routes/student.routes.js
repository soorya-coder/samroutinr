const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { requireAuth, requireRole } = require('../../middleware/auth');
const {
  applyOd, myOdRequests, uploadProof,
  applyLeave, myLeaveRequests,
  inbox, markInboxRead,
  overview
} = require('../controllers/student.controller');

const router = express.Router();

const uploadDir = path.join(__dirname, '..', '..', 'uploads', 'certificates');
fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const scope = req.params.id || 'new';
    cb(null, `od-${scope}-${req.user.id}-${file.fieldname}-${Date.now()}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = /\.(pdf|png|jpg|jpeg)$/i.test(file.originalname);
    if (!ok) return cb(new Error('Only PDF, PNG, or JPG files are allowed'));
    cb(null, true);
  }
});

router.use(requireAuth, requireRole('student'));

router.get('/overview', overview);

const applyOdFields = upload.fields([{ name: 'event_flyer', maxCount: 1 }]);
const proofFields = upload.fields([
  { name: 'certificate', maxCount: 1 },
  { name: 'photo', maxCount: 1 },
  { name: 'prize_certificate', maxCount: 1 }
]);

router.post('/apply-od', applyOdFields, applyOd);
router.get('/my-requests', myOdRequests);
router.post('/upload-proof/:id', proofFields, uploadProof);

router.post('/apply-leave', applyLeave);
router.get('/my-leaves', myLeaveRequests);

router.get('/inbox', inbox);
router.post('/inbox/:id/read', markInboxRead);

module.exports = router;
