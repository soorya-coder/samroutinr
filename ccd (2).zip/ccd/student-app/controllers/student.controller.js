const { db } = require('../../db/database');

const truthy = (v) => v === true || v === 1 || v === '1' || v === 'true' || v === 'on';
function findHodForDept(department) {
  if (!department) return null;
  const row = db.prepare(
    `SELECT id FROM users WHERE department = ? AND (role = 'hod' OR roles LIKE '%hod%') LIMIT 1`
  ).get(department);
  return row ? row.id : null;
}

// ---------------------------------------------------------------------------
// On-Duty (OD) — Step 1: prior approval / info-only submission
// ---------------------------------------------------------------------------

function applyOd(req, res) {
  const body = req.body || {};
  const files = req.files || {};
  const {
    event_name, event_date, organizing_institution, city, description
  } = body;

  const student = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!student.faculty_advisor_id) {
    return res.status(400).json({ error: 'No Faculty Advisor is assigned to your account. Contact the Admin.' });
  }
  if (!event_name || !event_date) {
    return res.status(400).json({ error: 'event_name and event_date are required' });
  }

  const isOnline = truthy(body.is_online);
  const needOd = truthy(body.need_od);
  const startStatus = needOd ? 'pending' : 'completed';
  const infoAck = needOd ? 'pending' : 'acknowledged';

  const flyer = files.event_flyer && files.event_flyer[0];
  const flyerPath = flyer ? `/uploads/certificates/${flyer.filename}` : null;

  const result = db.prepare(`
    INSERT INTO od_requests (
      student_id, faculty_advisor_id, class_coordinator_id, hod_id,
      event_name, event_from, event_to,
      organizing_institution, city, reason,
      is_online, need_od, event_flyer_path,
      status, hod_status, cc_status
    ) VALUES (?, ?, ?, ?,  ?, ?, ?,  ?, ?, ?,  ?, ?, ?,  ?, ?, ?)
  `).run(
    student.id, student.faculty_advisor_id, student.class_coordinator_id, findHodForDept(student.department),
    event_name, event_date, event_date,
    organizing_institution || null, city || null, description || null,
    isOnline ? 1 : 0, needOd ? 1 : 0, flyerPath,
    startStatus, infoAck, infoAck
  );

  res.status(201).json({ ok: true, id: result.lastInsertRowid, status: startStatus, need_od: needOd });
}

function myOdRequests(req, res) {
  const rows = db.prepare(
    `SELECT * FROM od_requests WHERE student_id = ? ORDER BY created_at DESC`
  ).all(req.user.id);
  res.json({ items: rows });
}

// Proof upload: certificate (required to complete), photo (optional), prize section (optional)
function uploadProof(req, res) {
  const odId = Number(req.params.id);
  const od = db.prepare('SELECT * FROM od_requests WHERE id = ?').get(odId);
  if (!od) return res.status(404).json({ error: 'OD request not found' });
  if (od.student_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
  if (od.status !== 'pending_proof' && od.status !== 'completed') {
    return res.status(400).json({ error: 'Proof can only be uploaded after the OD is approved' });
  }

  const body = req.body || {};
  const files = req.files || {};
  const hasPrize = truthy(body.has_prize);
  const updates = [];
  const params = [];
  const setFile = (field, col) => {
    const f = files[field] && files[field][0];
    if (f) { updates.push(`${col} = ?`); params.push(`/uploads/certificates/${f.filename}`); return true; }
    return false;
  };
  const gotCert = setFile('certificate', 'certificate_path');
  setFile('photo', 'photo_path');
  setFile('prize_certificate', 'prize_certificate_path');
  if (gotCert) {
    updates.push(`certificate_uploaded_at = datetime('now')`);
    updates.push(`status = 'completed'`);
  }
  updates.push('has_prize = ?'); params.push(hasPrize ? 1 : 0);
  if (hasPrize) {
    updates.push('prize_name = ?');   params.push(body.prize_name || null);
    updates.push('prize_amount = ?'); params.push(body.prize_amount || null);
  } else {
    updates.push('prize_name = NULL, prize_amount = NULL, prize_certificate_path = NULL');
  }
  updates.push(`updated_at = datetime('now')`);

  db.prepare(`UPDATE od_requests SET ${updates.join(', ')} WHERE id = ?`).run(...params, odId);
  const fresh = db.prepare('SELECT * FROM od_requests WHERE id = ?').get(odId);
  res.json({ ok: true, od: fresh });
}

// ---------------------------------------------------------------------------
// Leave applications
// ---------------------------------------------------------------------------

function applyLeave(req, res) {
  const { leave_type, from_date, to_date, reason } = req.body;
  const student = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);

  if (!student.faculty_advisor_id || !student.class_coordinator_id) {
    return res.status(400).json({ error: 'Faculty Advisor and/or Class Coordinator not assigned to your account. Contact the Admin.' });
  }
  if (!from_date || !to_date || !reason) {
    return res.status(400).json({ error: 'from_date, to_date, and reason are required' });
  }

  const result = db.prepare(`
    INSERT INTO leave_requests (student_id, faculty_advisor_id, class_coordinator_id, from_date, to_date, reason, leave_type)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(student.id, student.faculty_advisor_id, student.class_coordinator_id, from_date, to_date, reason, leave_type || null);

  res.status(201).json({ ok: true, id: result.lastInsertRowid });
}

function myLeaveRequests(req, res) {
  const rows = db.prepare(
    `SELECT * FROM leave_requests WHERE student_id = ? ORDER BY created_at DESC`
  ).all(req.user.id);
  res.json({ items: rows });
}

// ---------------------------------------------------------------------------
// Inbox — tasks/messages targeted at students
// ---------------------------------------------------------------------------

function inbox(req, res) {
  const rows = db.prepare(`
    SELECT m.*, u.name AS sender_name, u.role AS sender_role,
           EXISTS(SELECT 1 FROM message_reads r WHERE r.message_id = m.id AND r.user_id = ?) AS is_read
    FROM messages m
    JOIN users u ON u.id = m.sender_id
    WHERE m.target_role = 'student' OR m.target_role = 'all'
    ORDER BY m.created_at DESC
  `).all(req.user.id);
  res.json({ items: rows.map((r) => ({ ...r, is_read: !!r.is_read })) });
}

function markInboxRead(req, res) {
  const messageId = Number(req.params.id);
  const message = db.prepare('SELECT * FROM messages WHERE id = ?').get(messageId);
  if (!message) return res.status(404).json({ error: 'Not found' });
  if (message.target_role !== 'student' && message.target_role !== 'all') {
    return res.status(403).json({ error: 'Forbidden' });
  }
  db.prepare(
    `INSERT INTO message_reads (message_id, user_id) VALUES (?, ?)
     ON CONFLICT(message_id, user_id) DO NOTHING`
  ).run(messageId, req.user.id);
  res.json({ ok: true });
}

// ---------------------------------------------------------------------------
// Dashboard overview
// ---------------------------------------------------------------------------

function overview(req, res) {
  const studentId = req.user.id;

  const approvedOdCount = db.prepare(
    `SELECT COUNT(*) AS c FROM od_requests WHERE student_id = ? AND status = 'completed'`
  ).get(studentId).c;

  const pendingLeaveCount = db.prepare(
    `SELECT COUNT(*) AS c FROM leave_requests WHERE student_id = ? AND fa_status = 'pending'`
  ).get(studentId).c;

  const unreadCount = db.prepare(`
    SELECT COUNT(*) AS c FROM messages m
    WHERE (m.target_role = 'student' OR m.target_role = 'all')
      AND NOT EXISTS (SELECT 1 FROM message_reads r WHERE r.message_id = m.id AND r.user_id = ?)
  `).get(studentId).c;

  const odActivity = db.prepare(`
    SELECT 'od' AS kind, id, event_name AS title, status, updated_at
    FROM od_requests WHERE student_id = ?
  `).all(studentId);

  const leaveActivity = db.prepare(`
    SELECT 'leave' AS kind, id, ('Leave ' || from_date || ' to ' || to_date) AS title,
           (fa_status || '/' || cc_status) AS status, updated_at
    FROM leave_requests WHERE student_id = ?
  `).all(studentId);

  const recentActivity = [...odActivity, ...leaveActivity]
    .sort((a, b) => (a.updated_at < b.updated_at ? 1 : -1))
    .slice(0, 8);

  res.json({ approvedOdCount, pendingLeaveCount, unreadCount, recentActivity });
}

module.exports = {
  applyOd, myOdRequests, uploadProof,
  applyLeave, myLeaveRequests,
  inbox, markInboxRead,
  overview
};
