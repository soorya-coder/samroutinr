const KIND_ICON = { od: '📅', leave: '✈️' };

async function loadOverview() {
  try {
    const data = await api.get('/api/student/overview');
    document.getElementById('stat-approved-od').textContent = data.approvedOdCount;
    document.getElementById('stat-pending-leave').textContent = data.pendingLeaveCount;
    document.getElementById('stat-unread').textContent = data.unreadCount;

    const feed = document.getElementById('activity-feed');
    if (!data.recentActivity.length) {
      feed.innerHTML = `<p class="text-slate-500 text-sm">No activity yet. Apply for an OD or leave to get started.</p>`;
      return;
    }
    feed.innerHTML = data.recentActivity.map((a) => `
      <div class="flex items-start gap-3 py-2 border-b border-slate-800/70 last:border-0">
        <span class="text-lg">${KIND_ICON[a.kind] || '•'}</span>
        <div class="flex-1">
          <p class="text-sm text-slate-200">${escapeHtml(a.title)}</p>
          <p class="text-xs text-slate-500">${fmtDate(a.updated_at)} &middot; ${escapeHtml(a.status)}</p>
        </div>
      </div>`).join('');
  } catch (err) {
    toast(err.message, true);
  }
}

initLayout().then((user) => { if (user) loadOverview(); });
