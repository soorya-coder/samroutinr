const api = {
  async request(method, url, body, isForm = false) {
    const opts = { method, credentials: 'include' };
    if (body) {
      if (isForm) {
        opts.body = body;
      } else {
        opts.headers = { 'Content-Type': 'application/json' };
        opts.body = JSON.stringify(body);
      }
    }
    const res = await fetch(url, opts);
    let data = null;
    try { data = await res.json(); } catch (_) { /* no body */ }
    if (!res.ok) throw new Error((data && data.error) || `Request failed (${res.status})`);
    return data;
  },
  get(url) { return this.request('GET', url); },
  post(url, body, isForm) { return this.request('POST', url, body, isForm); }
};

function toast(message, isError = false) {
  const box = document.getElementById('toast-container');
  if (!box) { alert(message); return; }
  const el = document.createElement('div');
  el.className = `px-4 py-3 rounded-lg shadow-lg text-sm font-medium mb-2 border ${
    isError
      ? 'bg-rose-950/90 border-rose-700 text-rose-200'
      : 'bg-emerald-950/90 border-emerald-700 text-emerald-200'
  }`;
  el.textContent = message;
  box.appendChild(el);
  setTimeout(() => el.remove(), 4000);
}

// OD status -> { label, classes } per spec: Pending Prior Approval (yellow), Rejected (red),
// Approved - Pending Proof (blue), Completed (green).
const OD_STATUS_MAP = {
  pending: { label: 'Pending Prior Approval', classes: 'bg-amber-500/15 text-amber-300 border-amber-500/30' },
  rejected: { label: 'Rejected', classes: 'bg-rose-500/15 text-rose-300 border-rose-500/30' },
  pending_proof: { label: 'Approved - Pending Proof', classes: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30' },
  completed: { label: 'Completed', classes: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' }
};

function odStatusBadge(status) {
  const s = OD_STATUS_MAP[status] || { label: status, classes: 'bg-slate-500/15 text-slate-300 border-slate-500/30' };
  return `<span class="text-xs px-2.5 py-1 rounded-full border whitespace-nowrap ${s.classes}">${s.label}</span>`;
}

const LEAVE_STATUS_MAP = {
  pending: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
  approved: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
  acknowledged: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
  rejected: 'bg-rose-500/15 text-rose-300 border-rose-500/30'
};

function leaveStatusBadge(status) {
  const cls = LEAVE_STATUS_MAP[status] || 'bg-slate-500/15 text-slate-300 border-slate-500/30';
  return `<span class="text-xs px-2.5 py-1 rounded-full border whitespace-nowrap ${cls}">${status}</span>`;
}

function fmtDate(d) {
  if (!d) return '-';
  return new Date(d).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
}

function fmtDateOnly(d) {
  if (!d) return '-';
  return new Date(d).toLocaleDateString(undefined, { dateStyle: 'medium' });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}
