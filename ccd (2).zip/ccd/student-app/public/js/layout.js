async function initLayout() {
  try {
    const { user } = await api.get('/api/auth/me');
    const nameEl = document.getElementById('user-name');
    const avatarEl = document.getElementById('avatar');
    const regEl = document.getElementById('user-reg');
    if (nameEl) nameEl.textContent = user.name;
    if (avatarEl) avatarEl.textContent = user.name.charAt(0).toUpperCase();
    if (regEl) regEl.textContent = user.register_no ? `${user.register_no} · ${user.department || ''}` : (user.department || '');

    const activePage = document.body.dataset.page;
    document.querySelectorAll('.nav-link').forEach((a) => {
      a.classList.toggle('active', a.dataset.key === activePage);
    });

    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', async () => {
        await api.post('/api/auth/logout');
        window.location.href = 'index.html';
      });
    }

    return user;
  } catch (err) {
    window.location.href = 'index.html';
    return null;
  }
}
