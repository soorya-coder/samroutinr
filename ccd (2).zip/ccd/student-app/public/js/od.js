let activeUploadOdId = null;

async function loadOdRequests() {
  const table = document.getElementById('od-table');
  try {
    const { items } = await api.get('/api/student/my-requests');
    if (!items.length) {
      table.innerHTML = `<p class="text-slate-500 text-sm py-8 text-center">No OD requests yet.</p>`;
      return;
    }
    table.innerHTML = `
      <table class="w-full text-sm">
        <thead>
          <tr class="text-left text-slate-400 border-b border-slate-800">
            <th class="py-2.5 px-3 font-medium">Event Name</th>
            <th class="py-2.5 px-3 font-medium">Date</th>
            <th class="py-2.5 px-3 font-medium">Status</th>
            <th class="py-2.5 px-3 font-medium">Advisor Comment</th>
            <th class="py-2.5 px-3 font-medium">Action</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-800/70">
          ${items.map((o) => `
            <tr>
              <td class="py-2.5 px-3">
                <p class="font-medium">${escapeHtml(o.event_name)}</p>
                ${o.organizing_institution ? `<p class="text-xs text-slate-500">${escapeHtml(o.organizing_institution)}</p>` : ''}
              </td>
              <td class="py-2.5 px-3 text-slate-400">${fmtDateOnly(o.event_from)}</td>
              <td class="py-2.5 px-3">${odStatusBadge(o.status)}</td>
              <td class="py-2.5 px-3 text-slate-400">${o.advisor_comment ? escapeHtml(o.advisor_comment) : '-'}</td>
              <td class="py-2.5 px-3">
                ${o.status === 'pending_proof'
                  ? `<button data-id="${o.id}" class="upload-cert-btn px-3 py-1.5 rounded-lg bg-cyan-600/20 text-cyan-300 text-xs font-medium hover:bg-cyan-600/30">Upload Certificate</button>`
                  : (o.certificate_path ? `<a href="${o.certificate_path}" target="_blank" class="text-xs text-cyan-400 hover:underline">View Certificate</a>` : '-')}
              </td>
            </tr>`).join('')}
        </tbody>
      </table>`;

    document.querySelectorAll('.upload-cert-btn').forEach((btn) => {
      btn.addEventListener('click', () => openUploadModal(btn.dataset.id));
    });
  } catch (err) {
    table.innerHTML = `<p class="text-rose-400 text-sm">${err.message}</p>`;
  }
}

function openUploadModal(odId) {
  activeUploadOdId = odId;
  document.getElementById('upload-modal').classList.remove('hidden');
  document.getElementById('cert-file-input').value = '';
  document.getElementById('selected-file-name').textContent = '';
}

function closeUploadModal() {
  activeUploadOdId = null;
  document.getElementById('upload-modal').classList.add('hidden');
}

function wireUploadModal() {
  const dropZone = document.getElementById('drop-zone');
  const fileInput = document.getElementById('cert-file-input');
  const nameLabel = document.getElementById('selected-file-name');

  dropZone.addEventListener('click', () => fileInput.click());
  dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add('border-cyan-500'); });
  dropZone.addEventListener('dragleave', () => dropZone.classList.remove('border-cyan-500'));
  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('border-cyan-500');
    if (e.dataTransfer.files.length) {
      fileInput.files = e.dataTransfer.files;
      nameLabel.textContent = e.dataTransfer.files[0].name;
    }
  });
  fileInput.addEventListener('change', () => {
    if (fileInput.files.length) nameLabel.textContent = fileInput.files[0].name;
  });

  document.getElementById('close-modal-btn').addEventListener('click', closeUploadModal);
  document.getElementById('cancel-upload-btn').addEventListener('click', closeUploadModal);

  document.getElementById('confirm-upload-btn').addEventListener('click', async () => {
    if (!fileInput.files.length) return toast('Please select a file first', true);
    const formData = new FormData();
    formData.append('certificate', fileInput.files[0]);
    try {
      await api.post(`/api/student/upload-proof/${activeUploadOdId}`, formData, true);
      toast('Certificate uploaded — OD marked as completed');
      closeUploadModal();
      loadOdRequests();
    } catch (err) {
      toast(err.message, true);
    }
  });
}

document.getElementById('od-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const body = {
    event_name: document.getElementById('event_name').value.trim(),
    organizing_institution: document.getElementById('organizing_institution').value.trim(),
    event_date: document.getElementById('event_date').value,
    description: document.getElementById('description').value.trim()
  };
  try {
    await api.post('/api/student/apply-od', body);
    toast('OD request submitted for approval');
    e.target.reset();
    loadOdRequests();
  } catch (err) {
    toast(err.message, true);
  }
});

wireUploadModal();
initLayout().then((user) => { if (user) loadOdRequests(); });
