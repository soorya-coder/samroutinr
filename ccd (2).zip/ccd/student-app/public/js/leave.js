async function loadLeaveHistory() {
  const table = document.getElementById('leave-table');
  try {
    const { items } = await api.get('/api/student/my-leaves');
    if (!items.length) {
      table.innerHTML = `<p class="text-slate-500 text-sm py-8 text-center">No leave applications yet.</p>`;
      return;
    }
    table.innerHTML = `
      <table class="w-full text-sm">
        <thead>
          <tr class="text-left text-slate-400 border-b border-slate-800">
            <th class="py-2.5 px-3 font-medium">Type</th>
            <th class="py-2.5 px-3 font-medium">Dates</th>
            <th class="py-2.5 px-3 font-medium">Reason</th>
            <th class="py-2.5 px-3 font-medium">Advisor</th>
            <th class="py-2.5 px-3 font-medium">Coordinator</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-800/70">
          ${items.map((l) => `
            <tr>
              <td class="py-2.5 px-3 text-slate-300">${escapeHtml(l.leave_type || '-')}</td>
              <td class="py-2.5 px-3 text-slate-400">${fmtDateOnly(l.from_date)} &rarr; ${fmtDateOnly(l.to_date)}</td>
              <td class="py-2.5 px-3">${escapeHtml(l.reason)}</td>
              <td class="py-2.5 px-3">${leaveStatusBadge(l.fa_status)}</td>
              <td class="py-2.5 px-3">${leaveStatusBadge(l.cc_status)}</td>
            </tr>`).join('')}
        </tbody>
      </table>`;
  } catch (err) {
    table.innerHTML = `<p class="text-rose-400 text-sm">${err.message}</p>`;
  }
}

document.getElementById('leave-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const body = {
    leave_type: document.getElementById('leave_type').value,
    from_date: document.getElementById('from_date').value,
    to_date: document.getElementById('to_date').value,
    reason: document.getElementById('reason').value.trim()
  };
  try {
    await api.post('/api/student/apply-leave', body);
    toast('Leave application submitted to your Faculty Advisor and Class Coordinator');
    e.target.reset();
    loadLeaveHistory();
  } catch (err) {
    toast(err.message, true);
  }
});

initLayout().then((user) => { if (user) loadLeaveHistory(); });
