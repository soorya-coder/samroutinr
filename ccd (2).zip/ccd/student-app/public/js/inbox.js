async function loadInbox() {
  const list = document.getElementById('inbox-list');
  try {
    const { items } = await api.get('/api/student/inbox');
    if (!items.length) {
      list.innerHTML = `<p class="text-slate-500 text-sm">No messages or tasks yet.</p>`;
      return;
    }
    list.innerHTML = items.map((m) => `
      <div class="bg-slate-900/60 border ${m.is_read ? 'border-slate-800' : 'border-cyan-500/40'} rounded-xl p-5 flex flex-col gap-2">
        <div class="flex items-center justify-between">
          <span class="text-xs px-2 py-1 rounded-full border ${m.type === 'task' ? 'bg-violet-500/15 text-violet-300 border-violet-500/30' : 'bg-slate-500/15 text-slate-300 border-slate-500/30'}">
            ${m.type === 'task' ? '📌 Task' : '💬 Message'}
          </span>
          ${!m.is_read ? '<span class="w-2 h-2 rounded-full bg-cyan-400"></span>' : ''}
        </div>
        <h4 class="font-semibold text-slate-100">${escapeHtml(m.title)}</h4>
        ${m.body ? `<p class="text-sm text-slate-400">${escapeHtml(m.body)}</p>` : ''}
        <div class="text-xs text-slate-500 mt-1">
          From ${escapeHtml(m.sender_name)} &middot; ${fmtDate(m.created_at)}
          ${m.due_date ? ` &middot; Due ${fmtDateOnly(m.due_date)}` : ''}
        </div>
        <div class="mt-2">
          ${m.is_read
            ? `<span class="text-xs text-emerald-400">${m.type === 'task' ? '✓ Completed' : '✓ Read'}</span>`
            : `<button data-id="${m.id}" class="mark-read-btn px-3 py-1.5 rounded-lg bg-cyan-600/20 text-cyan-300 text-xs font-medium hover:bg-cyan-600/30">
                ${m.type === 'task' ? 'Mark Task Completed' : 'Mark as Read'}
              </button>`}
        </div>
      </div>`).join('');

    document.querySelectorAll('.mark-read-btn').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          await api.post(`/api/student/inbox/${btn.dataset.id}/read`);
          loadInbox();
        } catch (err) {
          toast(err.message, true);
        }
      });
    });
  } catch (err) {
    list.innerHTML = `<p class="text-rose-400 text-sm">${err.message}</p>`;
  }
}

initLayout().then((user) => { if (user) loadInbox(); });
