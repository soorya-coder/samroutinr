"""
=====================================================================
DATABASE CONNECTION — single editable file
=====================================================================
This is the ONLY file you need to edit to change the database backend.

Current backend: SQLite (Python stdlib `sqlite3`)
File location  : shared/db/transport.db

---------------------------------------------------------------------
How to switch to Microsoft SQL Server
---------------------------------------------------------------------
1. Install the driver:        pip install pyodbc
2. Comment out the "SQLite (active)" block below.
3. Uncomment the "MSSQL" block and fill in your connection details.
4. Reseed:                    python -m shared.db.seed

Notes when switching to MSSQL:
- pyodbc returns tuples by default. The helper `_dict_factory` below
  wraps rows so the rest of the codebase keeps working with dict-style
  row access (row["column"]).
- SQLite-only syntax (e.g., `INTEGER PRIMARY KEY AUTOINCREMENT`) may
  need minor schema tweaks; see schema.py.
=====================================================================
"""
import os


# ============================ SQLite (active) ============================
import sqlite3

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "transport.db")


def get_connection():
    """Return a fresh DB connection with dict-like row access."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def db_exists():
    return os.path.exists(DB_PATH)


# ============================ MSSQL (disabled) ===========================
# import pyodbc
#
# MSSQL_CONN_STR = (
#     "DRIVER={ODBC Driver 17 for SQL Server};"
#     "SERVER=your-server.database.windows.net;"
#     "DATABASE=transport;"
#     "UID=your-user;"
#     "PWD=your-password;"
#     "Encrypt=yes;"
#     "TrustServerCertificate=no;"
# )
#
# def _dict_factory(cursor, row):
#     return {col[0]: val for col, val in zip(cursor.description, row)}
#
# def get_connection():
#     conn = pyodbc.connect(MSSQL_CONN_STR)
#     # Wrap rows so existing `row["col"]` access keeps working.
#     conn.row_factory = _dict_factory   # pyodbc supports a callable row_factory
#     return conn
#
# def db_exists():
#     # MSSQL is server-hosted — assume it exists once configured.
#     return True
# =========================================================================
