"""Schema DDL. Plain SQL — no ORM."""

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS school (
    id   INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    lat  REAL NOT NULL,
    lng  REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS school_class (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    name    TEXT NOT NULL,
    teacher TEXT
);

CREATE TABLE IF NOT EXISTS bus (
    id                INTEGER PRIMARY KEY,
    bus_number        TEXT NOT NULL,
    number_plate      TEXT NOT NULL,
    route_name        TEXT NOT NULL,
    starting_location TEXT NOT NULL,
    current_lat       REAL NOT NULL,
    current_lng       REAL NOT NULL,
    departure_status  TEXT NOT NULL,
    driver_name       TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS student (
    id              INTEGER PRIMARY KEY,
    name            TEXT NOT NULL,
    spr_number      TEXT NOT NULL UNIQUE,
    class_id        INTEGER NOT NULL REFERENCES school_class(id),
    bus_id          INTEGER REFERENCES bus(id),
    gender          TEXT NOT NULL,
    boarding_status TEXT NOT NULL,
    pickup_lat      REAL NOT NULL,
    pickup_lng      REAL NOT NULL,
    fees_balance    REAL NOT NULL DEFAULT 0,
    fees_status     TEXT NOT NULL,
    is_present      INTEGER NOT NULL DEFAULT 1,
    section         TEXT,
    dob             TEXT
);

CREATE TABLE IF NOT EXISTS driver_user (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    username  TEXT NOT NULL UNIQUE,
    password  TEXT NOT NULL,
    full_name TEXT,
    bus_id    INTEGER REFERENCES bus(id)
);

CREATE TABLE IF NOT EXISTS alert (
    id          INTEGER PRIMARY KEY,
    message     TEXT NOT NULL,
    description TEXT,
    severity    TEXT NOT NULL,
    timestamp   TEXT NOT NULL,
    bus_id      INTEGER REFERENCES bus(id),
    student_id  INTEGER REFERENCES student(id)
);
"""

DROP_SQL = """
DROP TABLE IF EXISTS alert;
DROP TABLE IF EXISTS driver_user;
DROP TABLE IF EXISTS student;
DROP TABLE IF EXISTS bus;
DROP TABLE IF EXISTS school_class;
DROP TABLE IF EXISTS school;
"""
