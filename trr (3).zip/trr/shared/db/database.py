"""Session helpers + lifecycle. Connection details live in connection.py."""
from contextlib import contextmanager

from shared.db.connection import get_connection, db_exists


@contextmanager
def get_db():
    """Yield a connection with dict-like row access. Auto-closes."""
    conn = get_connection()
    try:
        yield conn
    finally:
        conn.close()


def init_db():
    """Create tables if they don't exist (no data)."""
    from shared.db.schema import SCHEMA_SQL
    with get_connection() as conn:
        conn.executescript(SCHEMA_SQL)
        conn.commit()


def ensure_db_ready():
    """First-run guard: create + seed if the DB doesn't exist yet."""
    if not db_exists():
        from shared.db.seed import seed
        seed()
