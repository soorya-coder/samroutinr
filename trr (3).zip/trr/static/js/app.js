// Unified script: handles search filter, download dropdown (driver pages),
// and the student switcher form (legacy demo).
document.addEventListener('DOMContentLoaded', () => {
  // --- Search filter (any page that includes [data-search-item] rows) ---
  const search = document.getElementById('global-search');
  if (search) {
    search.addEventListener('input', (e) => {
      const q = e.target.value.trim().toLowerCase();
      document.querySelectorAll('[data-search-item]').forEach(el => {
        const hay = (el.dataset.searchText || el.textContent).toLowerCase();
        el.style.display = !q || hay.includes(q) ? '' : 'none';
      });
    });
  }

  // --- Download Report dropdown ---
  const dl = document.querySelector('.dl-wrap');
  if (dl) {
    const btn = dl.querySelector('.btn-dl');
    const menu = dl.querySelector('.dl-menu');
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.classList.toggle('show');
    });
    document.addEventListener('click', () => menu.classList.remove('show'));
  }

  // --- Student switcher (legacy standalone demo) ---
  const sel = document.getElementById('student-select');
  if (sel) {
    sel.addEventListener('change', (e) => e.target.form.submit());
  }
});
