/* =========================================================
   ELECTRO HUB — Core utilities, navbar, cart, wishlist,
                  toast, modal, theme, loader, scroll-top.
   Loaded on every page.
   ========================================================= */

/* ---------- Splash injection (runs at script-evaluation, before DOMContentLoaded) ---------- */
const SPLASH_HTML = `
    <div class="loader-inner">
      <div class="loader-mark-wrap"><div class="loader-mark">Electro Hub</div></div>
      <div class="loader-tag-wrap"><div class="loader-tag">Electronics excellence, guaranteed</div></div>
      <div class="loader-bar"><span></span></div>
    </div>`;
(function injectSplash() {
  if (document.querySelector(".loader")) return;
  const splash = document.createElement("div");
  splash.className = "loader";
  splash.innerHTML = SPLASH_HTML;
  if (document.body) document.body.prepend(splash);
  else document.addEventListener("DOMContentLoaded", () => document.body.prepend(splash));
})();

/* ---------- Storage helpers ---------- */
const STORE = {
  get(key, fallback) {
    try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
    catch { return fallback; }
  },
  set(key, value) { localStorage.setItem(key, JSON.stringify(value)); },
  del(key) { localStorage.removeItem(key); }
};

/* ---------- Merge seller-added products into the in-memory catalogue ---------- */
(function loadSellerProducts() {
  const custom = STORE.get("eh_seller_products", []);
  if (!custom.length || !Array.isArray(window.PRODUCTS)) return;
  custom.forEach(p => {
    if (!window.PRODUCTS.some(x => x.id === p.id)) window.PRODUCTS.push(p);
  });
})();

/* ---------- Currency ---------- */
const money = (n) => "₹" + Number(n).toLocaleString("en-IN", { minimumFractionDigits: 0, maximumFractionDigits: 0 });

/* ---------- Toasts ---------- */
function ensureToastStack() {
  let s = document.querySelector(".toast-stack");
  if (!s) {
    s = document.createElement("div");
    s.className = "toast-stack";
    document.body.appendChild(s);
  }
  return s;
}
function toast(msg, type = "success") {
  const s = ensureToastStack();
  const t = document.createElement("div");
  t.className = `toast ${type}`;
  t.textContent = msg;
  s.appendChild(t);
  setTimeout(() => { t.style.opacity = "0"; t.style.transform = "translateX(20px)"; }, 2400);
  setTimeout(() => t.remove(), 3000);
}

/* ---------- Cart ---------- */
const CART_KEY = "eh_cart";
const WISH_KEY = "eh_wishlist";

function getCart() { return STORE.get(CART_KEY, []); }
function saveCart(c) { STORE.set(CART_KEY, c); updateBadges(); }
function addToCart(productId, qty = 1) {
  const cart = getCart();
  const found = cart.find(i => i.id === productId);
  if (found) found.qty += qty; else cart.push({ id: productId, qty });
  saveCart(cart);
  toast("Added to your cart");
}
function removeFromCart(productId) {
  saveCart(getCart().filter(i => i.id !== productId));
  toast("Removed from cart");
}
function setQty(productId, qty) {
  const cart = getCart();
  const item = cart.find(i => i.id === productId);
  if (!item) return;
  item.qty = Math.max(1, Number(qty) || 1);
  saveCart(cart);
}
function clearCart() { saveCart([]); }
function cartCount() { return getCart().reduce((s, i) => s + i.qty, 0); }

/* ---------- Installation & configuration services ---------- */
function getService(product) {
  if (!product || !product.service) return null;
  if (typeof product.service === "string") return (window.SERVICES || {})[product.service] || null;
  return product.service;
}
function toggleCartService(productId) {
  const cart = getCart();
  const item = cart.find(i => i.id === productId);
  if (!item) return false;
  item.addPaidService = !item.addPaidService;
  saveCart(cart);
  return !!item.addPaidService;
}
/* Returns enriched cart lines, with resolved product + service. */
function cartLines() {
  return getCart().map(c => {
    const product = (window.PRODUCTS || []).find(p => p.id === c.id);
    if (!product) return null;
    const service = getService(product);
    return { ...c, product, service };
  }).filter(Boolean);
}
/* Centralised order totals — used by cart, checkout, payment. */
function cartTotals() {
  const items = cartLines();
  let productSubtotal = 0;
  let servicesSubtotal = 0;
  const services = [];
  for (const it of items) {
    productSubtotal += it.product.price * it.qty;
    if (!it.service) continue;
    if (it.service.free) {
      services.push({ ...it.service, qty: it.qty, parent: it.product.name, productId: it.id, lineTotal: 0 });
    } else if (it.addPaidService) {
      servicesSubtotal += it.service.price * it.qty;
      services.push({ ...it.service, qty: it.qty, parent: it.product.name, productId: it.id, lineTotal: it.service.price * it.qty });
    }
  }
  const merchandise = productSubtotal + servicesSubtotal;
  const shipping = merchandise >= 4000 ? 0 : 199;
  const tax = Math.round(merchandise * 0.18);
  return {
    items, services,
    productSubtotal, servicesSubtotal, merchandise,
    shipping, tax,
    total: merchandise + shipping + tax
  };
}

/* ---------- Wishlist ---------- */
function getWishlist() { return STORE.get(WISH_KEY, []); }
function saveWishlist(w) { STORE.set(WISH_KEY, w); updateBadges(); }
function toggleWishlist(productId) {
  const w = getWishlist();
  const i = w.indexOf(productId);
  if (i >= 0) { w.splice(i, 1); toast("Removed from wishlist"); }
  else { w.push(productId); toast("Saved to wishlist"); }
  saveWishlist(w);
  return w.includes(productId);
}
function inWishlist(productId) { return getWishlist().includes(productId); }

/* ---------- Badges ---------- */
function updateBadges() {
  const c = cartCount();
  const w = getWishlist().length;
  document.querySelectorAll("[data-cart-badge]").forEach(el => {
    el.textContent = c;
    el.style.display = c > 0 ? "flex" : "none";
  });
  document.querySelectorAll("[data-wish-badge]").forEach(el => {
    el.textContent = w;
    el.style.display = w > 0 ? "flex" : "none";
  });
}

/* ---------- Auth (very lightweight, demo only) ---------- */
const AUTH_KEY = "eh_auth";
function getAuth() { return STORE.get(AUTH_KEY, null); }
function setAuth(user) { STORE.set(AUTH_KEY, user); }
function logout() { STORE.del(AUTH_KEY); location.href = "index.html"; }
window.logout = logout;

/* ---------- Orders ---------- */
const ORDERS_KEY = "eh_orders";
function getOrders() { return STORE.get(ORDERS_KEY, []); }
function saveOrder(order) {
  const all = getOrders();
  all.unshift(order);
  STORE.set(ORDERS_KEY, all);
}

/* ---------- Service bookings (installation & configuration) ---------- */
const BOOKINGS_KEY = "eh_service_bookings";
function getServiceBookings() { return STORE.get(BOOKINGS_KEY, []); }
function saveServiceBooking(b) {
  const all = getServiceBookings();
  all.unshift(b);
  STORE.set(BOOKINGS_KEY, all);
}

/* Build the next N working days as pill data. */
function nextBookingDates(count) {
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  const days   = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  const out = [];
  const today = new Date();
  let added = 0;
  let offset = 1;
  while (added < count && offset < 30) {
    const d = new Date(today);
    d.setDate(today.getDate() + offset);
    // skip Sundays for installation visits
    if (d.getDay() !== 0) {
      out.push({
        iso: d.toISOString().split("T")[0],
        day: days[d.getDay()],
        num: d.getDate(),
        month: months[d.getMonth()]
      });
      added++;
    }
    offset++;
  }
  return out;
}

/* Open the installation / configuration booking modal.
   opts = { orderId?, serviceKey?, serviceName?, productName?, prefill? } */
function openServiceBooking(opts = {}) {
  const user = getAuth() || {};
  const checkout = STORE.get("eh_checkout", null) || {};
  const prefill = opts.prefill || {};

  const defaultName = prefill.name || user.name || checkout.cName || "";
  const defaultPhone = prefill.phone || user.phone || checkout.cPhone || "";
  const defaultAddress = prefill.address ||
    (checkout.cAddr ? `${checkout.cAddr}, ${checkout.cCity || ""}${checkout.cState ? ', ' + checkout.cState : ''} ${checkout.cPostal || ""}, ${checkout.cCountry || ''}`.replace(/\s+,/g, ',').trim() : "");
  const defaultOrderId = prefill.orderId || opts.orderId || "";

  const serviceName = opts.serviceName || "Installation & configuration";
  const serviceKey  = opts.serviceKey  || "";
  const productName = opts.productName || "";

  let modal = document.getElementById("svcBookingModal");
  if (!modal) {
    modal = document.createElement("div");
    modal.id = "svcBookingModal";
    modal.className = "modal-scrim";
    document.body.appendChild(modal);
  }
  modal.dataset.serviceKey  = serviceKey;
  modal.dataset.serviceName = serviceName;
  modal.dataset.productName = productName;

  const dates = nextBookingDates(7);
  const slots = ["09:00 – 11:00", "11:00 – 13:00", "14:00 – 16:00", "16:00 – 18:00"];

  modal.innerHTML = `
    <div class="modal booking-modal">
      <button class="close" onclick="EH.closeServiceBooking();">×</button>
      <div class="booking-head">
        <span class="eyebrow">By appointment, installed</span>
        <h2>Schedule your ${serviceName.toLowerCase()}</h2>
        ${productName ? `<p class="for-product">For your <strong>${productName}</strong></p>` : `<p class="for-product">Quietly arranged — we'll come to you.</p>`}
      </div>
      <form class="booking-form" onsubmit="event.preventDefault(); EH.submitServiceBooking();" novalidate>

        <div class="form-row">
          <div class="field">
            <label>Full name</label>
            <input id="sbName" value="${escapeAttr(defaultName)}" autocomplete="name" required>
            <div class="err">Please enter your name.</div>
          </div>
          <div class="field">
            <label>Mobile number</label>
            <input id="sbPhone" type="tel" value="${escapeAttr(defaultPhone)}" autocomplete="tel" required placeholder="+91 98XXX XXXXX">
            <div class="err">Enter a valid mobile number.</div>
          </div>
        </div>

        <div class="field">
          <label>Order ID</label>
          <input id="sbOrderId" value="${escapeAttr(defaultOrderId)}" placeholder="EH-XXXXXX-XXXX" required style="font-family: var(--serif); letter-spacing: 0.06em;">
          <div class="err">Please enter your order ID (shown on your invoice).</div>
        </div>

        <div class="field">
          <label>Service address</label>
          <textarea id="sbAddress" rows="3" required placeholder="House / flat, street, area, city, postal code">${escapeAttr(defaultAddress)}</textarea>
          <div class="err">Please enter the address where you would like the visit.</div>
        </div>

        <div class="field">
          <label>Preferred date</label>
          <div class="date-pills" id="sbDates">
            ${dates.map((d, i) => `
              <button type="button" class="date-pill${i === 0 ? ' active' : ''}" data-date="${d.iso}">
                <span class="day">${d.day}</span>
                <span class="num">${d.num}</span>
                <span class="month">${d.month}</span>
              </button>
            `).join("")}
          </div>
        </div>

        <div class="field">
          <label>Preferred time slot</label>
          <div class="slot-pills" id="sbSlots">
            ${slots.map((s, i) => `
              <button type="button" class="slot-pill${i === 0 ? ' active' : ''}" data-slot="${s}">${s}</button>
            `).join("")}
          </div>
        </div>

        <div class="field">
          <label>Special instructions (optional)</label>
          <textarea id="sbNotes" rows="2" placeholder="Lift access, doorman name, anything we should know…"></textarea>
        </div>

        <div class="booking-foot">
          <button type="button" class="btn btn-ghost" onclick="EH.closeServiceBooking();">Cancel</button>
          <button type="submit" class="btn btn-gold">Confirm appointment</button>
        </div>
      </form>
    </div>
  `;

  // Pill selection
  modal.querySelectorAll("#sbDates .date-pill").forEach(p => {
    p.addEventListener("click", () => {
      modal.querySelectorAll("#sbDates .date-pill").forEach(x => x.classList.remove("active"));
      p.classList.add("active");
    });
  });
  modal.querySelectorAll("#sbSlots .slot-pill").forEach(p => {
    p.addEventListener("click", () => {
      modal.querySelectorAll("#sbSlots .slot-pill").forEach(x => x.classList.remove("active"));
      p.classList.add("active");
    });
  });

  modal.classList.add("open");
  modal.onclick = (e) => { if (e.target === modal) closeServiceBooking(); };
  setTimeout(() => modal.querySelector("#sbName")?.focus({ preventScroll: true }), 80);
}

function closeServiceBooking() {
  const modal = document.getElementById("svcBookingModal");
  if (modal) modal.classList.remove("open");
}

function submitServiceBooking() {
  const modal = document.getElementById("svcBookingModal");
  if (!modal) return;
  const rules = {
    sbName:    { test: v => v.trim().length >= 2, msg: "name" },
    sbPhone:   { test: v => /^[+\d][\d\s\-()]{6,}$/.test(v.trim()), msg: "mobile" },
    sbOrderId: { test: v => v.trim().length >= 4, msg: "order ID" },
    sbAddress: { test: v => v.trim().length >= 8, msg: "address" }
  };
  let ok = true;
  for (const [id, rule] of Object.entries(rules)) {
    const el = document.getElementById(id);
    if (!el) continue;
    const wrap = el.closest(".field");
    const valid = rule.test(el.value);
    wrap.classList.toggle("invalid", !valid);
    if (!valid) ok = false;
  }
  if (!ok) {
    toast("Please complete the highlighted fields.", "error");
    return;
  }
  const booking = {
    id: "SV-" + Date.now().toString(36).toUpperCase().substring(0, 8) + Math.random().toString(36).substring(2, 5).toUpperCase(),
    createdAt: new Date().toISOString(),
    serviceKey:  modal.dataset.serviceKey,
    serviceName: modal.dataset.serviceName,
    productName: modal.dataset.productName,
    name:    document.getElementById("sbName").value.trim(),
    phone:   document.getElementById("sbPhone").value.trim(),
    orderId: document.getElementById("sbOrderId").value.trim().toUpperCase(),
    address: document.getElementById("sbAddress").value.trim(),
    date:    modal.querySelector("#sbDates .date-pill.active")?.dataset.date || "",
    slot:    modal.querySelector("#sbSlots .slot-pill.active")?.dataset.slot || "",
    notes:   document.getElementById("sbNotes").value.trim(),
    status:  "Pending confirmation"
  };
  saveServiceBooking(booking);

  // Friendly date for display
  const niceDate = booking.date ? new Date(booking.date).toLocaleDateString("en-IN", { weekday: "long", year: "numeric", month: "long", day: "numeric" }) : "";

  modal.querySelector(".booking-modal").innerHTML = `
    <button class="close" onclick="EH.closeServiceBooking();">×</button>
    <div class="booking-success">
      <div class="ring">✓</div>
      <span class="cursive">By appointment, installed</span>
      <h2>Your visit is booked.</h2>
      <p class="muted">Reference <strong>${booking.id}</strong> — we'll send a confirmation to <strong>${booking.phone}</strong> within 24 hours.</p>
      <div class="booking-summary">
        <div><span class="label">Service</span><span class="val">${booking.serviceName}</span></div>
        ${booking.productName ? `<div><span class="label">For</span><span class="val">${booking.productName}</span></div>` : ''}
        <div><span class="label">Order</span><span class="val">${booking.orderId}</span></div>
        <div><span class="label">Customer</span><span class="val">${booking.name}</span></div>
        <div><span class="label">Mobile</span><span class="val">${booking.phone}</span></div>
        <div><span class="label">Date</span><span class="val">${niceDate || booking.date}</span></div>
        <div><span class="label">Time</span><span class="val">${booking.slot}</span></div>
        <div><span class="label">Address</span><span class="val" style="text-align: right; max-width: 60%;">${booking.address}</span></div>
      </div>
      <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
        <button class="btn btn-ghost" onclick="window.print();">Print confirmation</button>
        <button class="btn btn-gold" onclick="EH.closeServiceBooking();">Done</button>
      </div>
    </div>
  `;
  toast("Visit booked. Check your dashboard for details.");
}

/* small helper for safe attribute interpolation */
function escapeAttr(s) {
  return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");
}

/* ---------- Theme ---------- */
function applyTheme(t) {
  document.documentElement.setAttribute("data-theme", t);
  STORE.set("eh_theme", t);
  const btn = document.querySelector("[data-theme-toggle]");
  if (btn) btn.innerHTML = t === "dark" ? sunIcon() : moonIcon();
}
function toggleTheme() {
  const t = (STORE.get("eh_theme", "light") === "light") ? "dark" : "light";
  applyTheme(t);
}
window.toggleTheme = toggleTheme;

/* ---------- Icons (inline SVG strings) ---------- */
function svg(d, w = 18) {
  return `<svg width="${w}" height="${w}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
}
const cartIcon  = () => svg('<path d="M6 6h15l-1.5 9h-12z"/><circle cx="9" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/><path d="M6 6l-1-3H2"/>');
const heartIcon = () => svg('<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 1 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>');
const userIcon  = () => svg('<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>');
const searchIcon = () => svg('<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>');
const moonIcon  = () => svg('<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>');
const sunIcon   = () => svg('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/>');
const menuIcon  = () => svg('<line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>');
const arrowUp   = () => svg('<line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/>');

/* ---------- Navbar render ---------- */
function renderNavbar(active = "") {
  const user = getAuth();
  const userHref = user ? (user.role === "seller" ? "seller-dashboard.html" : user.role === "admin" ? "admin-dashboard.html" : "customer-dashboard.html") : "login.html";

  return `
  <header class="navbar" id="navbar">
    <div class="container nav-inner">
      <a href="index.html" class="brand">Electro <span class="accent">Hub</span><span class="tag">Electronics excellence, guaranteed</span></a>
      <nav class="nav-links">
        <a href="index.html" class="${active === 'home' ? 'active' : ''}">Home</a>
        <div class="has-mega">
          <a href="products.html" class="${active === 'shop' ? 'active' : ''}">Shop</a>
          <div class="mega">
            <div class="container mega-grid">
              <div class="mega-col">
                <h5>Audio</h5>
                <a href="products.html?cat=audio">Headphones</a>
                <a href="products.html?cat=audio">Earbuds</a>
                <a href="products.html?cat=audio">Speakers</a>
              </div>
              <div class="mega-col">
                <h5>Wearables</h5>
                <a href="products.html?cat=wearables">Smart watches</a>
                <a href="products.html?cat=wearables">Field watches</a>
                <a href="products.html?cat=wearables">Bands</a>
              </div>
              <div class="mega-col">
                <h5>Computing</h5>
                <a href="products.html?cat=computing">Laptops</a>
                <a href="products.html?cat=computing">Tablets</a>
                <a href="products.html?cat=computing">Accessories</a>
              </div>
              <div class="mega-col">
                <h5>Imaging & Home</h5>
                <a href="products.html?cat=imaging">Cameras</a>
                <a href="products.html?cat=mobile">Phones</a>
                <a href="products.html?cat=appliances">Refrigerators</a>
                <a href="products.html?cat=appliances">Washing machines</a>
                <a href="products.html?cat=appliances">Air conditioners</a>
                <a href="products.html?cat=appliances">All appliances</a>
              </div>
              <div class="mega-feature">
                <h5>Installation</h5>
                <h4>By appointment, installed</h4>
                <p>Free installation on home appliances. Setup on premium electronics.</p>
                <a href="index.html#services" class="mega-feature-link">Explore services →</a>
              </div>
            </div>
          </div>
        </div>
        <a href="offers.html" class="${active === 'offers' ? 'active' : ''}">Offers</a>
        <a href="compare.html" class="${active === 'compare' ? 'active' : ''}">Compare</a>
        <a href="faq.html" class="${active === 'faq' ? 'active' : ''}">FAQ</a>
        <a href="contact.html" class="${active === 'contact' ? 'active' : ''}">Contact</a>
      </nav>
      <div class="nav-actions">
        <button class="icon-btn" data-search-toggle aria-label="Search">${searchIcon()}</button>
        <a class="icon-btn" href="wishlist.html" aria-label="Wishlist">${heartIcon()}<span class="badge" data-wish-badge style="display:none;">0</span></a>
        <a class="icon-btn" href="cart.html" aria-label="Cart">${cartIcon()}<span class="badge" data-cart-badge style="display:none;">0</span></a>
        <a class="icon-btn" href="${userHref}" aria-label="Account">${userIcon()}</a>
        <button class="icon-btn" data-theme-toggle aria-label="Theme">${moonIcon()}</button>
        <button class="icon-btn hamburger" data-drawer-toggle aria-label="Menu">${menuIcon()}</button>
      </div>
    </div>
  </header>

  <div class="scrim" data-drawer-scrim></div>
  <aside class="drawer" data-drawer>
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
      <span class="brand">Electro <span class="accent">Hub</span></span>
      <button class="icon-btn" data-drawer-close aria-label="Close">${svg('<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>')}</button>
    </div>
    <a href="index.html">Home</a>
    <a href="products.html">Shop</a>
    <a href="offers.html">Offers</a>
    <a href="compare.html">Compare</a>
    <a href="faq.html">FAQ</a>
    <a href="contact.html">Contact</a>
    <a href="${userHref}">${user ? 'Dashboard' : 'Sign in'}</a>
  </aside>

  <div class="modal-scrim" data-search-modal>
    <div class="modal" style="max-width:680px; padding: 40px;">
      <button class="close" data-search-close>×</button>
      <span class="eyebrow">Find</span>
      <h2 style="margin:8px 0 18px;">What are you looking for?</h2>
      <div class="search-bar" style="width:100%;">
        ${searchIcon()}
        <input id="globalSearch" type="text" placeholder="Search for headphones, watches, cameras…" autofocus />
      </div>
      <div id="searchResults" style="margin-top:24px; max-height:50vh; overflow:auto;"></div>
    </div>
  </div>
  `;
}

function renderFooter() {
  return `
  <footer class="footer">
    <div class="container">
      <div class="footer-grid">
        <div>
          <span class="brand">Electro <span class="accent">Hub</span></span>
          <p class="muted" style="margin-top:16px;">A small circle of well-made electronics, hand-picked and considered. From our atelier in Bangalore, with a showroom in Chennai.</p>
          <p class="cursive" style="margin-top:14px;">Electronics excellence, guaranteed.</p>
        </div>
        <div>
          <h4>Shop</h4>
          <ul>
            <li><a href="products.html?cat=audio">Audio</a></li>
            <li><a href="products.html?cat=wearables">Wearables</a></li>
            <li><a href="products.html?cat=computing">Computing</a></li>
            <li><a href="products.html?cat=mobile">Mobile</a></li>
            <li><a href="products.html?cat=imaging">Imaging</a></li>
            <li><a href="products.html?cat=appliances">Home Appliances</a></li>
            <li><a href="offers.html">Offers &amp; deals</a></li>
          </ul>
        </div>
        <div>
          <h4>Help &amp; Service</h4>
          <ul>
            <li><a href="contact.html">Contact us</a></li>
            <li><a href="faq.html">FAQ</a></li>
            <li><a href="orders.html">Track your order</a></li>
            <li><a href="faq.html">Shipping &amp; Returns</a></li>
            <li><a href="index.html#services">Installation &amp; setup</a></li>
            <li><a href="compare.html">Compare products</a></li>
          </ul>
        </div>
        <div>
          <h4>Your Account</h4>
          <ul>
            <li><a href="login.html">Sign in</a></li>
            <li><a href="register.html">Create account</a></li>
            <li><a href="customer-dashboard.html">My dashboard</a></li>
            <li><a href="wishlist.html">Wishlist</a></li>
            <li><a href="cart.html">Cart</a></li>
            <li><a href="register.html">Become a seller</a></li>
          </ul>
        </div>
        <div>
          <h4>Stay in touch</h4>
          <p class="muted" style="font-size:0.88rem;">A monthly note on new pieces — promise, no spam.</p>
          <form class="newsletter" onsubmit="event.preventDefault(); toast('Subscribed — thank you.');">
            <input type="email" placeholder="Your email" required />
            <button>Join</button>
          </form>
          <p class="muted" style="font-size:0.82rem; margin-top:18px; line-height: 1.7;">
            <strong style="color: var(--ivory); font-weight: 500;">Electro Hub Atelier</strong><br>
            8 Lavelle Road, Bangalore 560001<br>
            <a href="tel:+918041120123">+91 80 4112 0123</a><br>
            <a href="mailto:contact@electrohub.example">contact@electrohub.example</a>
          </p>
        </div>
      </div>
      <div class="footer-bottom">
        <span>© ${new Date().getFullYear()} Electro Hub — All rights reserved.</span>
        <span>
          <a href="faq.html">Privacy</a> ·
          <a href="faq.html">Terms</a> ·
          <a href="faq.html">Cookies</a> ·
          <a href="contact.html">Support</a>
        </span>
      </div>
    </div>
  </footer>
  `;
}

/* ---------- Search modal ---------- */
function initSearch() {
  const modal = document.querySelector("[data-search-modal]");
  const open = () => modal.classList.add("open");
  const close = () => modal.classList.remove("open");
  document.querySelector("[data-search-toggle]")?.addEventListener("click", open);
  document.querySelector("[data-search-close]")?.addEventListener("click", close);
  modal?.addEventListener("click", (e) => { if (e.target === modal) close(); });

  const input = document.getElementById("globalSearch");
  const results = document.getElementById("searchResults");
  input?.addEventListener("input", () => {
    const q = input.value.trim().toLowerCase();
    if (!q) { results.innerHTML = ""; return; }
    const list = (window.PRODUCTS || [])
      .filter(p => (p.name + " " + p.brand + " " + p.cat).toLowerCase().includes(q))
      .slice(0, 6);
    if (!list.length) { results.innerHTML = `<p class="muted">No results for "${q}".</p>`; return; }
    results.innerHTML = list.map(p => `
      <a href="product.html?id=${p.id}" style="display:flex; gap:14px; padding:10px 0; border-bottom:1px solid var(--line); align-items:center;">
        <img src="${p.images[0]}" alt="" style="width:54px; height:54px; object-fit:cover; border-radius:4px;">
        <div style="flex:1;">
          <div style="font-family:var(--serif); font-size:1rem;">${p.name}</div>
          <div class="muted" style="font-size:0.8rem; text-transform:uppercase; letter-spacing:0.16em;">${p.cat}</div>
        </div>
        <div style="font-family:var(--serif); color:var(--gold-dark);">${money(p.price)}</div>
      </a>
    `).join("");
  });
}

/* ---------- Drawer ---------- */
function initDrawer() {
  const drawer = document.querySelector("[data-drawer]");
  const scrim = document.querySelector("[data-drawer-scrim]");
  const open = () => { drawer?.classList.add("open"); scrim?.classList.add("open"); };
  const close = () => { drawer?.classList.remove("open"); scrim?.classList.remove("open"); };
  document.querySelector("[data-drawer-toggle]")?.addEventListener("click", open);
  document.querySelector("[data-drawer-close]")?.addEventListener("click", close);
  scrim?.addEventListener("click", close);
}

/* ---------- Sticky navbar shadow ---------- */
function initStickyShadow() {
  const nav = document.getElementById("navbar");
  if (!nav) return;
  const apply = () => nav.classList.toggle("scrolled", window.scrollY > 8);
  apply(); window.addEventListener("scroll", apply, { passive: true });
}

/* ---------- Scroll-to-top ---------- */
function initScrollTop() {
  const btn = document.createElement("button");
  btn.className = "scroll-top";
  btn.innerHTML = arrowUp();
  btn.setAttribute("aria-label", "Back to top");
  btn.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
  document.body.appendChild(btn);
  window.addEventListener("scroll", () => {
    btn.classList.toggle("show", window.scrollY > 480);
  }, { passive: true });
}

/* ---------- Loader — same timing on every page ---------- */
const SPLASH_MS = 1500;
function initLoader() {
  // Upgrade any legacy/static loader to the new wrap-based markup
  const loader = document.querySelector(".loader");
  if (!loader) return;
  if (!loader.querySelector(".loader-mark-wrap")) {
    loader.innerHTML = SPLASH_HTML;
  }
  const start = performance.now();
  const hide = () => {
    const elapsed = performance.now() - start;
    const remaining = Math.max(0, SPLASH_MS - elapsed);
    setTimeout(() => {
      loader.classList.add("hide");
      setTimeout(() => loader.remove(), 700);
    }, remaining);
  };
  if (document.readyState === "complete") hide();
  else window.addEventListener("load", hide);
}

/* ---------- Custom cursor ---------- */
function initCursor() {
  if (window.matchMedia("(hover: none), (pointer: coarse)").matches) return;
  if (document.querySelector(".cursor-dot")) return;
  const dot = document.createElement("div");
  dot.className = "cursor-dot";
  dot.innerHTML = `<span class="cursor-glyph"></span>`;
  const ring = document.createElement("div");
  ring.className = "cursor-ring";
  document.body.append(ring, dot);
  document.documentElement.classList.add("has-custom-cursor");

  let mx = window.innerWidth / 2, my = window.innerHeight / 2;
  let rx = mx, ry = my;
  let active = false;

  window.addEventListener("mousemove", (e) => {
    mx = e.clientX; my = e.clientY;
    if (!active) {
      dot.style.opacity = "1"; ring.style.opacity = "1"; active = true;
    }
  });
  window.addEventListener("mouseleave", () => {
    dot.style.opacity = "0"; ring.style.opacity = "0"; active = false;
  });
  document.addEventListener("mousedown", () => { ring.classList.add("click"); dot.classList.add("click"); });
  document.addEventListener("mouseup",   () => { ring.classList.remove("click"); dot.classList.remove("click"); });

  function tick() {
    rx += (mx - rx) * 0.18;
    ry += (my - ry) * 0.18;
    dot.style.transform  = `translate(${mx - 4}px, ${my - 4}px)`;
    ring.style.transform = `translate(${rx - 18}px, ${ry - 18}px)`;
    requestAnimationFrame(tick);
  }
  tick();

  // Hover state — change cursor icon depending on target
  function setState(target) {
    const isLink = target.closest("a, button, .product-card, .cat-card, .offer-card, [data-thumb], [data-pdt], [data-qvt], [data-tab], .pay-method, .acc-trigger, .icon-btn, .toggle, .copy");
    const isText = target.closest("input[type='text'], input[type='email'], input[type='tel'], input[type='password'], input[type='number'], input:not([type]), textarea");
    const isImg  = target.closest(".product-media img, .pd-gallery .main, .qv-media");
    dot.classList.toggle("on-link", !!isLink && !isImg);
    dot.classList.toggle("on-text", !!isText);
    dot.classList.toggle("on-image", !!isImg);
    ring.classList.toggle("on-link", !!isLink && !isImg);
    ring.classList.toggle("on-text", !!isText);
    ring.classList.toggle("on-image", !!isImg);

    const glyph = dot.querySelector(".cursor-glyph");
    if (isImg)       glyph.textContent = "+";
    else if (isLink) glyph.textContent = "↗";
    else if (isText) glyph.textContent = "|";
    else             glyph.textContent = "";
  }
  document.addEventListener("mouseover", (e) => setState(e.target));
}

/* ---------- Carousel ---------- */
function initCarousels() {
  document.querySelectorAll("[data-carousel]").forEach(carousel => {
    const track = carousel.querySelector("[data-carousel-track]");
    const slides = [...track.children];
    const prev = carousel.querySelector("[data-carousel-prev]");
    const next = carousel.querySelector("[data-carousel-next]");
    const dotsWrap = carousel.querySelector("[data-carousel-dots]");
    if (!slides.length) return;

    let index = 0;
    let autoplay = true;
    let timer = null;
    const interval = Number(carousel.dataset.interval || 5000);

    function visibleCount() {
      const w = carousel.clientWidth;
      if (w < 600) return 1;
      if (w < 960) return 2;
      return 3;
    }
    function maxIndex() { return Math.max(0, slides.length - visibleCount()); }

    function go(i, animate = true) {
      index = Math.max(0, Math.min(maxIndex(), i));
      const slideW = slides[0].getBoundingClientRect().width;
      const gap = parseFloat(getComputedStyle(track).gap) || 0;
      track.style.transition = animate ? "transform var(--t-slow)" : "none";
      track.style.transform = `translateX(${-(slideW + gap) * index}px)`;
      if (dotsWrap) {
        dotsWrap.querySelectorAll("button").forEach((d, di) => d.classList.toggle("active", di === index));
      }
    }
    function start() {
      stop();
      if (!autoplay) return;
      timer = setInterval(() => {
        if (index >= maxIndex()) go(0); else go(index + 1);
      }, interval);
    }
    function stop() { if (timer) clearInterval(timer); timer = null; }

    prev?.addEventListener("click", () => { go(index - 1); start(); });
    next?.addEventListener("click", () => { go(index + 1); start(); });
    carousel.addEventListener("mouseenter", stop);
    carousel.addEventListener("mouseleave", start);

    // Dots
    if (dotsWrap) {
      dotsWrap.innerHTML = "";
      for (let i = 0; i <= maxIndex(); i++) {
        const b = document.createElement("button");
        if (i === 0) b.classList.add("active");
        b.addEventListener("click", () => { go(i); start(); });
        dotsWrap.appendChild(b);
      }
    }

    let resizeTimer;
    window.addEventListener("resize", () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => go(index, false), 100);
    });

    go(0, false);
    start();
  });
}

/* ---------- Theme toggle ---------- */
function initTheme() {
  const saved = STORE.get("eh_theme", "light");
  applyTheme(saved);
  document.querySelector("[data-theme-toggle]")?.addEventListener("click", toggleTheme);
}

/* ---------- Mount layout ---------- */
function mountLayout(active = "") {
  const navHolder = document.getElementById("nav-holder");
  const footerHolder = document.getElementById("footer-holder");
  if (navHolder) navHolder.innerHTML = renderNavbar(active);
  if (footerHolder) footerHolder.innerHTML = renderFooter();
  updateBadges();
  initStickyShadow();
  initDrawer();
  initSearch();
  initTheme();
}

/* ---------- Product card markup ---------- */
function productCardHTML(p) {
  const wished = inWishlist(p.id);
  const oldPriceHTML = p.old > 0 ? `<span class="old">${money(p.old)}</span>` : "";
  const badgeHTML = p.badge ? `<span class="badge-tag">${p.badge}</span>` : "";
  const svc = getService(p);
  const serviceHTML = svc
    ? `<div class="service-tag ${svc.free ? 'free' : 'paid'}">${svc.free ? '✓' : '+'} ${svc.short}</div>`
    : "";
  return `
  <article class="product-card" data-product-id="${p.id}">
    <div class="product-media">
      ${badgeHTML}
      <img src="${p.images[0]}" alt="${p.name}" data-main />
      <button class="wish ${wished ? 'active' : ''}" data-wish>${heartIcon()}</button>
      <button class="quick" data-quick>Quick View</button>
    </div>
    <div class="thumbs">
      ${p.images.map((src, i) => `
        <button data-thumb="${i}" class="${i === 0 ? 'active' : ''}"><img src="${src}" alt="view ${i+1}"></button>
      `).join("")}
    </div>
    <div class="product-info">
      <div class="cat-label">${p.brand} · ${p.cat}</div>
      <h3><a href="product.html?id=${p.id}">${p.name}</a></h3>
      <div class="price">${money(p.price)} ${oldPriceHTML}</div>
      <div class="rating">★★★★★ <span class="count">${p.rating} · ${p.reviews} reviews</span></div>
      ${serviceHTML}
    </div>
  </article>
  `;
}

/* ---------- Bind product card interactivity ---------- */
function bindProductCards(scope = document) {
  scope.querySelectorAll(".product-card").forEach(card => {
    const id = card.dataset.productId;
    const product = (window.PRODUCTS || []).find(p => p.id === id);
    if (!product) return;
    const mainImg = card.querySelector("[data-main]");
    card.querySelectorAll("[data-thumb]").forEach(btn => {
      btn.addEventListener("mouseenter", () => activate(btn));
      btn.addEventListener("click", () => activate(btn));
    });
    function activate(btn) {
      const i = Number(btn.dataset.thumb);
      mainImg.style.opacity = "0";
      setTimeout(() => {
        mainImg.src = product.images[i];
        mainImg.style.opacity = "1";
      }, 200);
      card.querySelectorAll("[data-thumb]").forEach(b => b.classList.toggle("active", b === btn));
    }
    card.querySelector("[data-wish]")?.addEventListener("click", (e) => {
      e.preventDefault();
      const wished = toggleWishlist(id);
      e.currentTarget.classList.toggle("active", wished);
    });
    card.querySelector("[data-quick]")?.addEventListener("click", () => openQuickView(product));
  });
}

/* ---------- Quick view modal ---------- */
function openQuickView(p) {
  let modal = document.getElementById("quickModal");
  if (!modal) {
    modal = document.createElement("div");
    modal.id = "quickModal";
    modal.className = "modal-scrim";
    document.body.appendChild(modal);
  }
  modal.innerHTML = `
    <div class="modal">
      <button class="close" onclick="document.getElementById('quickModal').classList.remove('open');">×</button>
      <div class="quickview">
        <div class="qv-media"><img src="${p.images[0]}" id="qvMain" alt=""></div>
        <div class="qv-body">
          <span class="eyebrow">${p.brand}</span>
          <h2 style="margin:8px 0 8px;">${p.name}</h2>
          <div class="price" style="font-family:var(--serif); font-size:1.4rem; color:var(--gold-dark);">${money(p.price)}</div>
          <p class="muted" style="margin:18px 0;">${p.desc}</p>
          <div class="pd-thumbs" style="margin-bottom:24px;">
            ${p.images.map((src, i) => `<button data-qvt="${i}" class="${i===0?'active':''}"><img src="${src}" alt=""></button>`).join("")}
          </div>
          <div style="display:flex; gap:10px;">
            <a href="product.html?id=${p.id}" class="btn btn-block">View details</a>
            <button class="btn btn-gold" onclick="addToCart('${p.id}',1); document.getElementById('quickModal').classList.remove('open');">Add to cart</button>
          </div>
        </div>
      </div>
    </div>
  `;
  modal.classList.add("open");
  modal.addEventListener("click", (e) => { if (e.target === modal) modal.classList.remove("open"); });
  modal.querySelectorAll("[data-qvt]").forEach(b => {
    b.addEventListener("click", () => {
      const i = Number(b.dataset.qvt);
      const img = modal.querySelector("#qvMain");
      img.style.opacity = "0";
      setTimeout(() => { img.src = p.images[i]; img.style.opacity = "1"; }, 200);
      modal.querySelectorAll("[data-qvt]").forEach(x => x.classList.toggle("active", x === b));
    });
  });
}

/* ---------- Initialise on every page ---------- */
document.addEventListener("DOMContentLoaded", () => {
  initLoader();
  initScrollTop();
  initCursor();
  initCarousels();
});

/* Expose */
window.EH = {
  STORE, money, toast,
  getCart, addToCart, removeFromCart, setQty, clearCart, cartCount,
  getWishlist, toggleWishlist, inWishlist,
  getService, toggleCartService, cartLines, cartTotals,
  getAuth, setAuth, logout,
  getOrders, saveOrder,
  getServiceBookings, saveServiceBooking,
  openServiceBooking, closeServiceBooking, submitServiceBooking,
  applyTheme, toggleTheme,
  mountLayout, productCardHTML, bindProductCards, openQuickView,
  updateBadges
};
