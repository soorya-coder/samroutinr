const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');
const { init } = require('./db/database');

init();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(cookieParser());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/student', express.static(path.join(__dirname, 'student-app', 'public')));

app.use('/api/auth', require('./routes/auth.routes'));
app.use('/api/admin', require('./routes/admin.routes'));
app.use('/api/messages', require('./routes/message.routes'));
app.use('/api/od', require('./routes/od.routes'));
app.use('/api/leave', require('./routes/leave.routes'));
app.use('/api/student', require('./student-app/routes/student.routes'));

// Multer / other thrown errors land here as regular Error objects.
app.use((err, req, res, next) => {
  if (err) {
    console.error(err);
    return res.status(400).json({ error: err.message || 'Unexpected error' });
  }
  next();
});

app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/') || req.path.startsWith('/student') || req.path.startsWith('/uploads')) return next();
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`College Management App running at http://localhost:${PORT}`);
});
