const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { requireAuth, requireRole } = require('../../middleware/auth');
const {
  applyOd, myOdRequests, uploadProof,
  applyLeave, myLeaveRequests,
  inbox, markInboxRead,
  overview
} = require('../controllers/student.controller');

const router = express.Router();

const uploadDir = path.join(__dirname, '..', '..', 'uploads', 'certificates');
fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `od-${req.params.id}-${req.user.id}-${Date.now()}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = /\.(pdf|png|jpg|jpeg)$/i.test(file.originalname);
    if (!ok) return cb(new Error('Only PDF, PNG, or JPG files are allowed'));
    cb(null, true);
  }
});

router.use(requireAuth, requireRole('student'));

router.get('/overview', overview);

router.post('/apply-od', applyOd);
router.get('/my-requests', myOdRequests);
router.post('/upload-proof/:id', upload.single('certificate'), uploadProof);

router.post('/apply-leave', applyLeave);
router.get('/my-leaves', myLeaveRequests);

router.get('/inbox', inbox);
router.post('/inbox/:id/read', markInboxRead);

module.exports = router;
