const { db } = require('../../db/database');

// ---------------------------------------------------------------------------
// On-Duty (OD) — Step 1: prior approval request
// ---------------------------------------------------------------------------

function applyOd(req, res) {
  const { event_name, organizing_institution, event_date, description } = req.body;
  const student = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);

  if (!student.faculty_advisor_id) {
    return res.status(400).json({ error: 'No Faculty Advisor is assigned to your account. Contact the Admin.' });
  }
  if (!event_name || !event_date) {
    return res.status(400).json({ error: 'event_name and event_date are required' });
  }

  const result = db.prepare(`
    INSERT INTO od_requests (student_id, faculty_advisor_id, event_name, event_from, event_to, organizing_institution, reason)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(student.id, student.faculty_advisor_id, event_name, event_date, event_date, organizing_institution || null, description || null);

  res.status(201).json({ ok: true, id: result.lastInsertRowid });
}

// My OD requests (tracking table)
function myOdRequests(req, res) {
  const rows = db.prepare(
    `SELECT * FROM od_requests WHERE student_id = ? ORDER BY created_at DESC`
  ).all(req.user.id);
  res.json({ items: rows });
}

// Step 2: post-event certificate upload
function uploadProof(req, res) {
  const odId = Number(req.params.id);
  const od = db.prepare('SELECT * FROM od_requests WHERE id = ?').get(odId);

  if (!od) return res.status(404).json({ error: 'OD request not found' });
  if (od.student_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
  if (od.status !== 'pending_proof') {
    return res.status(400).json({ error: 'Certificate can only be uploaded for an approved OD awaiting proof' });
  }
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  const relativePath = `/uploads/certificates/${req.file.filename}`;
  db.prepare(`
    UPDATE od_requests
    SET certificate_path = ?, certificate_uploaded_at = datetime('now'), status = 'completed', updated_at = datetime('now')
    WHERE id = ?
  `).run(relativePath, odId);

  res.json({ ok: true, status: 'completed', certificate_path: relativePath });
}

// ---------------------------------------------------------------------------
// Leave applications
// ---------------------------------------------------------------------------

function applyLeave(req, res) {
  const { leave_type, from_date, to_date, reason } = req.body;
  const student = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);

  if (!student.faculty_advisor_id || !student.class_coordinator_id) {
    return res.status(400).json({ error: 'Faculty Advisor and/or Class Coordinator not assigned to your account. Contact the Admin.' });
  }
  if (!from_date || !to_date || !reason) {
    return res.status(400).json({ error: 'from_date, to_date, and reason are required' });
  }

  const result = db.prepare(`
    INSERT INTO leave_requests (student_id, faculty_advisor_id, class_coordinator_id, from_date, to_date, reason, leave_type)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(student.id, student.faculty_advisor_id, student.class_coordinator_id, from_date, to_date, reason, leave_type || null);

  res.status(201).json({ ok: true, id: result.lastInsertRowid });
}

function myLeaveRequests(req, res) {
  const rows = db.prepare(
    `SELECT * FROM leave_requests WHERE student_id = ? ORDER BY created_at DESC`
  ).all(req.user.id);
  res.json({ items: rows });
}

// ---------------------------------------------------------------------------
// Inbox — tasks/messages targeted at students
// ---------------------------------------------------------------------------

function inbox(req, res) {
  const rows = db.prepare(`
    SELECT m.*, u.name AS sender_name, u.role AS sender_role,
           EXISTS(SELECT 1 FROM message_reads r WHERE r.message_id = m.id AND r.user_id = ?) AS is_read
    FROM messages m
    JOIN users u ON u.id = m.sender_id
    WHERE m.target_role = 'student' OR m.target_role = 'all'
    ORDER BY m.created_at DESC
  `).all(req.user.id);
  res.json({ items: rows.map((r) => ({ ...r, is_read: !!r.is_read })) });
}

function markInboxRead(req, res) {
  const messageId = Number(req.params.id);
  const message = db.prepare('SELECT * FROM messages WHERE id = ?').get(messageId);
  if (!message) return res.status(404).json({ error: 'Not found' });
  if (message.target_role !== 'student' && message.target_role !== 'all') {
    return res.status(403).json({ error: 'Forbidden' });
  }
  db.prepare(
    `INSERT INTO message_reads (message_id, user_id) VALUES (?, ?)
     ON CONFLICT(message_id, user_id) DO NOTHING`
  ).run(messageId, req.user.id);
  res.json({ ok: true });
}

// ---------------------------------------------------------------------------
// Dashboard overview
// ---------------------------------------------------------------------------

function overview(req, res) {
  const studentId = req.user.id;

  const approvedOdCount = db.prepare(
    `SELECT COUNT(*) AS c FROM od_requests WHERE student_id = ? AND status = 'completed'`
  ).get(studentId).c;

  const pendingLeaveCount = db.prepare(
    `SELECT COUNT(*) AS c FROM leave_requests WHERE student_id = ? AND fa_status = 'pending'`
  ).get(studentId).c;

  const unreadCount = db.prepare(`
    SELECT COUNT(*) AS c FROM messages m
    WHERE (m.target_role = 'student' OR m.target_role = 'all')
      AND NOT EXISTS (SELECT 1 FROM message_reads r WHERE r.message_id = m.id AND r.user_id = ?)
  `).get(studentId).c;

  const odActivity = db.prepare(`
    SELECT 'od' AS kind, id, event_name AS title, status, updated_at
    FROM od_requests WHERE student_id = ?
  `).all(studentId);

  const leaveActivity = db.prepare(`
    SELECT 'leave' AS kind, id, ('Leave ' || from_date || ' to ' || to_date) AS title,
           (fa_status || '/' || cc_status) AS status, updated_at
    FROM leave_requests WHERE student_id = ?
  `).all(studentId);

  const recentActivity = [...odActivity, ...leaveActivity]
    .sort((a, b) => (a.updated_at < b.updated_at ? 1 : -1))
    .slice(0, 8);

  res.json({ approvedOdCount, pendingLeaveCount, unreadCount, recentActivity });
}

module.exports = {
  applyOd, myOdRequests, uploadProof,
  applyLeave, myLeaveRequests,
  inbox, markInboxRead,
  overview
};
