const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { requireAuth, requireRole } = require('../middleware/auth');
const { createOd, listMyOds, listForAdvisor, decideOd, uploadCertificate } = require('../controllers/od.controller');

const router = express.Router();

const uploadDir = path.join(__dirname, '..', 'uploads', 'certificates');
fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `od-${req.params.id}-${req.user.id}-${Date.now()}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = /\.(pdf|png|jpg|jpeg)$/i.test(file.originalname);
    if (!ok) return cb(new Error('Only PDF, PNG, or JPG files are allowed'));
    cb(null, true);
  }
});

router.use(requireAuth);

router.post('/', requireRole('student'), createOd);
router.get('/mine', requireRole('student'), listMyOds);
router.post('/:id/certificate', requireRole('student'), upload.single('certificate'), uploadCertificate);

router.get('/advisor-queue', requireRole('faculty_advisor'), listForAdvisor);
router.post('/:id/decision', requireRole('faculty_advisor'), decideOd);

module.exports = router;
