const path = require('path');
const bcrypt = require('bcryptjs');
const { DatabaseSync } = require('node:sqlite');

const DB_PATH = path.join(__dirname, 'college.db');
const db = new DatabaseSync(DB_PATH);

db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');

const ROLES = [
  'admin',
  'coordinator', // Counselling Coordinator
  'hod',
  'class_coordinator',
  'faculty_advisor',
  'student'
];

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  name                TEXT NOT NULL,
  email               TEXT NOT NULL UNIQUE,
  password_hash       TEXT NOT NULL,
  role                TEXT NOT NULL CHECK (role IN ('admin','coordinator','hod','class_coordinator','faculty_advisor','student')),
  department          TEXT,
  register_no         TEXT UNIQUE,
  faculty_advisor_id  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  class_coordinator_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  must_reset_password INTEGER NOT NULL DEFAULT 1,
  created_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS messages (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  sender_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type          TEXT NOT NULL CHECK (type IN ('task','message')) DEFAULT 'message',
  title         TEXT NOT NULL,
  body          TEXT,
  target_role   TEXT NOT NULL CHECK (target_role IN ('hod','faculty_advisor','student','class_coordinator','all')),
  department    TEXT,
  due_date      TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS message_reads (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  message_id  INTEGER NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  read_at     TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(message_id, user_id)
);

CREATE TABLE IF NOT EXISTS od_requests (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  faculty_advisor_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  event_name          TEXT NOT NULL,
  event_from          TEXT NOT NULL,
  event_to            TEXT NOT NULL,
  reason              TEXT,
  status              TEXT NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending','rejected','pending_proof','completed')),
  advisor_comment     TEXT,
  certificate_path    TEXT,
  certificate_uploaded_at TEXT,
  created_at          TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS leave_requests (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id            INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  faculty_advisor_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_coordinator_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  from_date             TEXT NOT NULL,
  to_date               TEXT NOT NULL,
  reason                TEXT NOT NULL,
  fa_status             TEXT NOT NULL DEFAULT 'pending' CHECK (fa_status IN ('pending','approved','rejected')),
  fa_comment            TEXT,
  cc_status             TEXT NOT NULL DEFAULT 'pending' CHECK (cc_status IN ('pending','acknowledged')),
  cc_comment            TEXT,
  created_at            TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at            TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_od_student ON od_requests(student_id);
CREATE INDEX IF NOT EXISTS idx_od_advisor ON od_requests(faculty_advisor_id);
CREATE INDEX IF NOT EXISTS idx_leave_student ON leave_requests(student_id);
CREATE INDEX IF NOT EXISTS idx_leave_advisor ON leave_requests(faculty_advisor_id);
CREATE INDEX IF NOT EXISTS idx_leave_cc ON leave_requests(class_coordinator_id);
CREATE INDEX IF NOT EXISTS idx_messages_role ON messages(target_role);
`;

function migrate() {
  const odCols = db.prepare("PRAGMA table_info(od_requests)").all().map((c) => c.name);
  if (!odCols.includes('organizing_institution')) {
    db.exec('ALTER TABLE od_requests ADD COLUMN organizing_institution TEXT');
  }
  const leaveCols = db.prepare("PRAGMA table_info(leave_requests)").all().map((c) => c.name);
  if (!leaveCols.includes('leave_type')) {
    db.exec('ALTER TABLE leave_requests ADD COLUMN leave_type TEXT');
  }
}

function init() {
  db.exec(SCHEMA);
  migrate();
  seedAdmin();
}

function seedAdmin() {
  const existing = db.prepare('SELECT id FROM users WHERE role = ? LIMIT 1').get('admin');
  if (existing) return;

  const passwordHash = bcrypt.hashSync('Admin@123', 10);
  db.prepare(
    `INSERT INTO users (name, email, password_hash, role, must_reset_password)
     VALUES (?, ?, ?, 'admin', 0)`
  ).run('System Admin', 'admin@college.edu', passwordHash);

  console.log('Seeded default admin -> email: admin@college.edu / password: Admin@123');
}

module.exports = { db, init, ROLES };
