const bcrypt = require('bcryptjs');
const xlsx = require('xlsx');
const { db, ROLES } = require('../db/database');

const DEFAULT_PASSWORD = 'Welcome@123';

function normalizeRole(role) {
  if (!role) return null;
  const r = String(role).trim().toLowerCase().replace(/\s+/g, '_');
  return ROLES.includes(r) ? r : null;
}

// Resolve a "Faculty Advisor" / "Class Coordinator" cell that may contain
// an email or a register/staff ID into a users.id, for linking students.
function resolveUserRef(ref) {
  if (!ref) return null;
  const value = String(ref).trim();
  if (!value) return null;
  const row = db.prepare('SELECT id FROM users WHERE email = ? OR register_no = ?').get(value, value);
  return row ? row.id : null;
}

const insertUserStmt = db.prepare(`
  INSERT INTO users (name, email, password_hash, role, department, register_no, faculty_advisor_id, class_coordinator_id)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?)
`);

function insertUser(u) {
  return insertUserStmt.run(
    u.name, u.email, u.password_hash, u.role,
    u.department, u.register_no, u.faculty_advisor_id, u.class_coordinator_id
  );
}

function createSingleUser(req, res) {
  const { name, email, role, department, register_no, faculty_advisor_email, class_coordinator_email, password } = req.body;

  const normalizedRole = normalizeRole(role);
  if (!name || !email || !normalizedRole) {
    return res.status(400).json({ error: 'name, email, and a valid role are required' });
  }

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email.trim().toLowerCase());
  if (existing) return res.status(409).json({ error: 'A user with this email already exists' });

  const passwordHash = bcrypt.hashSync(password || DEFAULT_PASSWORD, 10);

  try {
    const result = insertUser({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      password_hash: passwordHash,
      role: normalizedRole,
      department: department || null,
      register_no: register_no || null,
      faculty_advisor_id: resolveUserRef(faculty_advisor_email),
      class_coordinator_id: resolveUserRef(class_coordinator_email)
    });
    res.status(201).json({ ok: true, id: result.lastInsertRowid, defaultPassword: password ? undefined : DEFAULT_PASSWORD });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

// Bulk insert via uploaded .xlsx/.csv. Expected columns (case-insensitive):
// name, email, role, department, register_no, faculty_advisor_email, class_coordinator_email
function bulkUploadUsers(req, res) {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  let rows;
  try {
    const workbook = xlsx.read(req.file.buffer, { type: 'buffer' });
    const firstSheet = workbook.SheetNames[0];
    rows = xlsx.utils.sheet_to_json(workbook.Sheets[firstSheet], { defval: '' });
  } catch (err) {
    return res.status(400).json({ error: 'Could not parse the uploaded file. Please upload a valid .xlsx or .csv file.' });
  }

  if (!rows.length) return res.status(400).json({ error: 'The uploaded file has no data rows' });

  const results = { inserted: 0, skipped: 0, errors: [] };

  const insertMany = (records) => {
    db.exec('BEGIN');
    try {
      records.forEach((raw, index) => processRow(raw, index));
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  };

  function processRow(raw, index) {
      const rowNum = index + 2; // account for header row
      const get = (...keys) => {
        for (const k of keys) {
          const foundKey = Object.keys(raw).find((rk) => rk.trim().toLowerCase() === k);
          if (foundKey && String(raw[foundKey]).trim() !== '') return String(raw[foundKey]).trim();
        }
        return '';
      };

      const name = get('name', 'full name', 'fullname');
      const email = get('email', 'email address').toLowerCase();
      const role = normalizeRole(get('role'));
      const department = get('department', 'dept') || null;
      const register_no = get('register_no', 'register no', 'registerno', 'roll no') || null;
      const faAdvisorEmail = get('faculty_advisor_email', 'faculty advisor', 'faculty_advisor');
      const ccEmail = get('class_coordinator_email', 'class coordinator', 'class_coordinator');

      if (!name || !email || !role) {
        results.skipped++;
        results.errors.push(`Row ${rowNum}: missing required field(s) (name/email/role)`);
        return;
      }

      const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
      if (existing) {
        results.skipped++;
        results.errors.push(`Row ${rowNum}: email "${email}" already exists`);
        return;
      }

      const passwordHash = bcrypt.hashSync(DEFAULT_PASSWORD, 10);

      try {
        insertUser({
          name,
          email,
          password_hash: passwordHash,
          role,
          department,
          register_no,
          faculty_advisor_id: resolveUserRef(faAdvisorEmail),
          class_coordinator_id: resolveUserRef(ccEmail)
        });
        results.inserted++;
      } catch (err) {
        results.skipped++;
        results.errors.push(`Row ${rowNum}: ${err.message}`);
      }
  }

  insertMany(rows);

  res.json({ ok: true, defaultPassword: DEFAULT_PASSWORD, ...results });
}

function listUsers(req, res) {
  const users = db.prepare(
    `SELECT id, name, email, role, department, register_no, created_at FROM users ORDER BY created_at DESC`
  ).all();
  res.json({ users });
}

module.exports = { createSingleUser, bulkUploadUsers, listUsers };
