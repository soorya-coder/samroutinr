const { db } = require('../db/database');

function createOd(req, res) {
  const { event_name, event_from, event_to, event_date, organizing_institution, reason } = req.body;
  const student = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);

  // Accept either an explicit from/to range, or a single event_date (used by the student portal's simpler form).
  const from = event_from || event_date;
  const to = event_to || event_date;

  if (!student.faculty_advisor_id) {
    return res.status(400).json({ error: 'No Faculty Advisor is assigned to your account. Contact the Admin.' });
  }
  if (!event_name || !from || !to) {
    return res.status(400).json({ error: 'event_name and event date(s) are required' });
  }

  const result = db.prepare(`
    INSERT INTO od_requests (student_id, faculty_advisor_id, event_name, event_from, event_to, organizing_institution, reason)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(student.id, student.faculty_advisor_id, event_name, from, to, organizing_institution || null, reason || null);

  res.status(201).json({ ok: true, id: result.lastInsertRowid });
}

function listMyOds(req, res) {
  const rows = db.prepare(
    `SELECT * FROM od_requests WHERE student_id = ? ORDER BY created_at DESC`
  ).all(req.user.id);
  res.json({ items: rows });
}

// Faculty Advisor's queue: requests they must approve/reject, plus ones awaiting proof.
function listForAdvisor(req, res) {
  const rows = db.prepare(`
    SELECT o.*, u.name AS student_name, u.register_no
    FROM od_requests o
    JOIN users u ON u.id = o.student_id
    WHERE o.faculty_advisor_id = ?
    ORDER BY o.created_at DESC
  `).all(req.user.id);
  res.json({ items: rows });
}

function decideOd(req, res) {
  const odId = Number(req.params.id);
  const { decision, comment } = req.body; // decision: 'approve' | 'reject'
  const od = db.prepare('SELECT * FROM od_requests WHERE id = ?').get(odId);

  if (!od) return res.status(404).json({ error: 'OD request not found' });
  if (od.faculty_advisor_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
  if (od.status !== 'pending') return res.status(400).json({ error: 'This request has already been decided' });
  if (!['approve', 'reject'].includes(decision)) return res.status(400).json({ error: 'decision must be approve or reject' });

  const newStatus = decision === 'approve' ? 'pending_proof' : 'rejected';
  db.prepare(
    `UPDATE od_requests SET status = ?, advisor_comment = ?, updated_at = datetime('now') WHERE id = ?`
  ).run(newStatus, comment || null, odId);

  res.json({ ok: true, status: newStatus });
}

function uploadCertificate(req, res) {
  const odId = Number(req.params.id);
  const od = db.prepare('SELECT * FROM od_requests WHERE id = ?').get(odId);

  if (!od) return res.status(404).json({ error: 'OD request not found' });
  if (od.student_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
  if (od.status !== 'pending_proof') {
    return res.status(400).json({ error: 'Certificate can only be uploaded for an approved OD awaiting proof' });
  }
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  const relativePath = `/uploads/certificates/${req.file.filename}`;
  db.prepare(`
    UPDATE od_requests
    SET certificate_path = ?, certificate_uploaded_at = datetime('now'), status = 'completed', updated_at = datetime('now')
    WHERE id = ?
  `).run(relativePath, odId);

  res.json({ ok: true, status: 'completed', certificate_path: relativePath });
}

module.exports = { createOd, listMyOds, listForAdvisor, decideOd, uploadCertificate };
